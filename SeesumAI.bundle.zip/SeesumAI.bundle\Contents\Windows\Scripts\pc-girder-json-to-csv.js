const fs = require("fs");

const jsonPath = process.argv[2];
const outPath = process.argv[3];

if (!jsonPath || !outPath) {
  console.error("Usage: node pc-girder-json-to-csv.js <input.json> <PC_Girder.csv>");
  process.exit(2);
}

const raw = JSON.parse(fs.readFileSync(jsonPath, "utf8"));
const girders = Array.isArray(raw) ? raw : raw.girders || [];

const headers = [
  "",
  "LOT##NUMBER##GENERAL",
  "L##length##millimeters",
  "H##length##millimeters",
  "B##length##millimeters",
  "A_visible##length##millimeters",
  "B_visible##length##millimeters",
  "C_visible##length##millimeters",
  "D_visible##length##millimeters",
  "A_b##length##millimeters",
  "A_h##length##millimeters",
  "B_b##length##millimeters",
  "B_h##length##millimeters",
  "C_b##length##millimeters",
  "C_h##length##millimeters",
  "D_b##length##millimeters",
  "D_h##length##millimeters",
  "void1_visible##length##millimeters",
  "void1_x##length##millimeters",
  "void1_y##length##millimeters",
  "void1_w##length##millimeters",
  "void1_h##length##millimeters",
  "ledge_A_visible##length##millimeters",
  "ledge_B_visible##length##millimeters",
  "ledge_C_visible##length##millimeters",
  "ledge_D_visible##length##millimeters",
  "ledge_A_length##length##millimeters",
  "ledge_B_length##length##millimeters",
  "ledge_C_length##length##millimeters",
  "ledge_D_length##length##millimeters",
];

const round = (v) => Math.round(Number(v) || 0);
const def50 = (v) => (v === undefined || v === null || Number.isNaN(Number(v)) ? 50 : round(v));
const cleanLot = (lot) => String(lot || "").replace(/^12-?/, "").replace(/-/g, "");

function normalizePoints(points) {
  const pts = (points || [])
    .map((p) => Array.isArray(p) ? { x: Number(p[0]), y: Number(p[1]) } : null)
    .filter(Boolean);
  if (!pts.length) return [];
  const minX = Math.min(...pts.map((p) => p.x));
  const minY = Math.min(...pts.map((p) => p.y));
  return pts.map((p) => ({ x: p.x - minX, y: p.y - minY }));
}

function pointInPoly(x, y, pts) {
  let inside = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const xi = pts[i].x, yi = pts[i].y;
    const xj = pts[j].x, yj = pts[j].y;
    const hit = ((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / ((yj - yi) || 1e-9) + xi);
    if (hit) inside = !inside;
  }
  return inside;
}

function uniqueSorted(values) {
  return [...new Set(values.map(round))].sort((a, b) => a - b);
}

function gridComponents(pts, length, height, wantInside) {
  const xs = uniqueSorted([0, length, ...pts.map((p) => p.x)]).filter((v) => v >= 0 && v <= length);
  const ys = uniqueSorted([0, height, ...pts.map((p) => p.y)]).filter((v) => v >= 0 && v <= height);
  const cells = [];
  for (let ix = 0; ix < xs.length - 1; ix++) {
    for (let iy = 0; iy < ys.length - 1; iy++) {
      const x1 = xs[ix], x2 = xs[ix + 1], y1 = ys[iy], y2 = ys[iy + 1];
      if (x2 <= x1 || y2 <= y1) continue;
      const inside = pointInPoly((x1 + x2) / 2, (y1 + y2) / 2, pts);
      if (inside === wantInside) cells.push({ ix, iy, x1, x2, y1, y2 });
    }
  }
  const key = (c) => `${c.ix},${c.iy}`;
  const byKey = new Map(cells.map((c) => [key(c), c]));
  const seen = new Set();
  const comps = [];
  for (const start of cells) {
    const k0 = key(start);
    if (seen.has(k0)) continue;
    const stack = [start];
    seen.add(k0);
    const comp = [];
    while (stack.length) {
      const c = stack.pop();
      comp.push(c);
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nk = `${c.ix + dx},${c.iy + dy}`;
        if (!seen.has(nk) && byKey.has(nk)) {
          seen.add(nk);
          stack.push(byKey.get(nk));
        }
      }
    }
    comps.push(boundsOfCells(comp));
  }
  return comps;
}

function boundsOfCells(cells) {
  return {
    x: Math.min(...cells.map((c) => c.x1)),
    y: Math.min(...cells.map((c) => c.y1)),
    x2: Math.max(...cells.map((c) => c.x2)),
    y2: Math.max(...cells.map((c) => c.y2)),
  };
}

function detectCornerVoids(emptyComps, length, height) {
  const slots = {
    A: { visible: 0, b: 50, h: 50 },
    B: { visible: 0, b: 50, h: 50 },
    C: { visible: 0, b: 50, h: 50 },
    D: { visible: 0, b: 50, h: 50 },
  };
  for (const c of emptyComps) {
    const w = round(c.x2 - c.x);
    const h = round(c.y2 - c.y);
    if (w <= 0 || h <= 0) continue;
    const touchesLeft = c.x <= 1;
    const touchesRight = c.x2 >= length - 1;
    const touchesBottom = c.y <= 1;
    const touchesTop = c.y2 >= height - 1;
    let key = null;
    if (touchesLeft && touchesTop) key = "A";
    else if (touchesRight && touchesTop) key = "B";
    else if (touchesLeft && touchesBottom) key = "C";
    else if (touchesRight && touchesBottom) key = "D";
    if (key) slots[key] = { visible: 1, b: w, h };
  }
  return slots;
}

function detectGenericVoid(emptyComps, length, height) {
  const inner = emptyComps
    .filter((c) => c.x > 1 && c.x2 < length - 1 && c.y > 1 && c.y2 < height - 1)
    .sort((a, b) => (a.x - b.x) || (b.y2 - a.y2));
  if (!inner.length) return { visible: 0, x: 50, y: 50, w: 50, h: 50 };
  const c = inner[0];
  const h = round(c.y2 - c.y);
  return {
    visible: 1,
    x: round(c.x),
    y: round(height - c.y2),
    w: round(c.x2 - c.x),
    h,
  };
}

function detectLedges(pts, length, height) {
  const slots = {
    A: { visible: 0, length: 50 },
    B: { visible: 0, length: 50 },
    C: { visible: 0, length: 50 },
    D: { visible: 0, length: 50 },
  };
  const xs = uniqueSorted([0, length, ...pts.map((p) => p.x)]).filter((v) => v >= 0 && v <= length);
  const ys = uniqueSorted([0, height, ...pts.map((p) => p.y)]).filter((v) => v >= 0 && v <= height);
  const thin = [];
  const sideStep = { L: 0, R: 0 };
  for (let ix = 0; ix < xs.length - 1; ix++) {
    for (let iy = 0; iy < ys.length - 1; iy++) {
      const x1 = xs[ix], x2 = xs[ix + 1], y1 = ys[iy], y2 = ys[iy + 1];
      if (!pointInPoly((x1 + x2) / 2, (y1 + y2) / 2, pts)) continue;
      const w = x2 - x1, h = y2 - y1;
      if (h > 120 && w <= 120) {
        if (x1 <= 120) sideStep.L = Math.max(sideStep.L, w);
        if (x2 >= length - 120) sideStep.R = Math.max(sideStep.R, w);
      }
      if (h >= 45 && h <= 85 && w > h && w <= Math.min(1000, length * 0.3)) {
        thin.push({ x1, x2, y1, y2, w, h });
      }
    }
  }
  for (const t of thin) {
    const side = t.x1 <= 1 ? "L" : (t.x2 >= length - 1 ? "R" : null);
    if (!side) continue;
    const vertical = t.y1 <= 90 ? "B" : (t.y2 >= height - 90 ? "T" : null);
    if (!vertical) continue;
    const key = side === "L" && vertical === "T" ? "A"
      : side === "R" && vertical === "T" ? "B"
      : side === "L" && vertical === "B" ? "C"
      : "D";
    let len = round(t.w - sideStep[side]);
    if (len <= 0) len = round(t.w);
    if (!slots[key].visible || len > slots[key].length) slots[key] = { visible: 1, length: len };
  }
  return slots;
}

function rowForGirder(g) {
  const pts = normalizePoints(g.profilePoints);
  const xs = pts.map((p) => p.x);
  const ys = pts.map((p) => p.y);
  const length = round(g.lengthMm || (Math.max(...xs) - Math.min(...xs)));
  const height = round(g.heightMm || (Math.max(...ys) - Math.min(...ys)));
  const width = round(g.widthMm || g.extrusionDepthMm || g.parameters?.widthMm || 0);
  const lot = String(g.lotNumber || g.parameters?.lotNumber || g.name || "");

  const emptyComps = pts.length ? gridComponents(pts, length, height, false) : [];
  const corner = detectCornerVoids(emptyComps, length, height);
  const void1 = detectGenericVoid(emptyComps, length, height);
  const ledge = pts.length ? detectLedges(pts, length, height) : {
    A: { visible: 0, length: 50 },
    B: { visible: 0, length: 50 },
    C: { visible: 0, length: 50 },
    D: { visible: 0, length: 50 },
  };

  return [
    lot,
    cleanLot(lot),
    length,
    width,
    height,
    corner.A.visible,
    corner.B.visible,
    corner.C.visible,
    corner.D.visible,
    def50(corner.A.b),
    def50(corner.A.h),
    def50(corner.B.b),
    def50(corner.B.h),
    def50(corner.C.b),
    def50(corner.C.h),
    def50(corner.D.b),
    def50(corner.D.h),
    void1.visible,
    def50(void1.x),
    def50(void1.y),
    def50(void1.w),
    def50(void1.h),
    ledge.A.visible,
    ledge.B.visible,
    ledge.C.visible,
    ledge.D.visible,
    def50(ledge.A.length),
    def50(ledge.B.length),
    def50(ledge.C.length),
    def50(ledge.D.length),
  ];
}

function csvLine(values) {
  return values.map((v) => {
    const s = String(v ?? "");
    return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  }).join(",");
}

const lines = [csvLine(headers), ...girders.map(rowForGirder).map(csvLine)];
fs.writeFileSync(outPath, lines.join("\r\n"), "utf8");
console.log(`Wrote ${girders.length} rows: ${outPath}`);
