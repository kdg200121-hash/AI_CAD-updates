(or (vl-load-com) (princ))

;; ����ġ ���� ���� �߻� �� ������ �� �ڵ鷯 ���� ����
(defun PC_OP_ERR (msg)
  (if (and (boundp 'old-osmode) old-osmode) (setvar "OSMODE" old-osmode))
  (setq *error* old-err)
  (princ (strcat "\n[�˸�] �۾��� �ߴܵǾ����ϴ�: " msg))
  (princ)
)

;; ��ǥ ���� ���ڿ� ����Ʈ ��ȯ ���� �Լ�
(defun Read_Comma_List (str / pos lst)
  (setq lst nil)
  (while (setq pos (vl-string-search "," str))
    (setq lst (append lst (list (substr str 1 pos))))
    (setq str (substr str (+ pos 2)))
  )
  (if (/= str "") (setq lst (append lst (list str))))
  lst
)

(defun Write_Comma_List (lst / str)
  (setq str "")
  (foreach x lst (setq str (if (= str "") x (strcat str "," x))))
  str
)

;; ��Ʈ��ȣ �ڵ� �Ľ�(����) �Լ�

;; ��Ʈ��ȣ ���� �˻�: 00-000-0000 / 00-000-0000-0 ���� ���
(defun Is_Lot_Number_Format (str / tstr)
  (setq tstr (vl-string-trim " \t\n\r" (if str str "")))
  (or
    (and (= (strlen tstr) 11) (wcmatch tstr "##-###-####"))
    (and (= (strlen tstr) 13) (wcmatch tstr "##-###-####-#"))
  )
)
(defun Parse_Lot_Number (str / pos res)
  (setq pos (vl-string-search "-" str))
  (if pos
    (setq res (substr str (+ pos 2)))
    (setq res str)
  )
  (while (setq pos (vl-string-search "-" res))
    (setq res (strcat (substr res 1 pos) (substr res (+ pos 2))))
  )
  res
)

;; ���� ���� ���� �̸� ���� �Լ�
(defun Get-Effective-Name (ent / obj name)
  (setq name (cdr (assoc 2 (entget ent))))
  (if (wcmatch name "`*U*")
    (progn
      (setq obj (vlax-ename->vla-object ent))
      (if (vlax-property-available-p obj 'EffectiveName)
        (setq name (vlax-get-property obj 'EffectiveName))
      )
    )
  )
  name
)

;; ���� ���� ���ü� �� ���� �Լ�
(defun Get-Dynamic-Visibility (ent / obj props prop p-name p-val result)
  (setq result "")
  (if ent
    (progn
      (setq obj (vlax-ename->vla-object ent))
      (if (and obj (vlax-method-applicable-p obj 'GetDynamicBlockProperties))
        (progn
          (setq props (vlax-invoke obj 'GetDynamicBlockProperties))
          (foreach prop props
            (setq p-name (strcase (vlax-get prop 'PropertyName)))
            (if (or (wcmatch p-name "*VISIBILITY*") (wcmatch p-name "*���ü�*"))
              (progn
                (setq p-val (vlax-get prop 'Value))
                (setq result (vl-princ-to-string p-val))
              )
            )
          )
        )
      )
    )
  )
  result
)

;; ���̾�� ������ �����Ͽ� ���ڿ� ���·� ���� ��ȯ�ϴ� �Լ� (������ ����)
(defun Pick-Layer-Color (prompt-str / ent dxf lay col)
  (setq ent (car (entsel prompt-str)))
  (if ent
    (progn
      (setq dxf (entget ent))
      (setq lay (cdr (assoc 8 dxf)))
      (setq col (cdr (assoc 62 dxf)))
      (if (not col) (setq col 256)) 
      (strcat lay ":" (itoa col))
    )
    nil
  )
)

;; ���� ���̾� �̸��� ���� ��ȯ�ϴ� �Լ� (������/�ָ���� ��ũ��Ʈ ����)
(defun Pick-Layer-Only (prompt-str / ent dxf lay)
  (setq ent (car (entsel prompt-str)))
  (if ent
    (progn
      (setq dxf (entget ent))
      (cdr (assoc 8 dxf))
    )
    nil
  )
)

;; ����Ʈ�ڽ� ǥ��� ���� �Լ�
(defun Format-Lay-Col-String (item / pos)
  (if (setq pos (vl-string-search ":" item))
    (strcat (substr item 1 pos) " (����:" (substr item (+ pos 2)) ")")
    item
  )
)

;; ���̾�:���� ���·� ����� ���� ������ ������ ���̾���� ���⵵�� ����
(defun Strip-Layer-Name (item / pos)
  (if (setq pos (vl-string-search ":" item))
    (substr item 1 pos)
    item
  )
)

;; ���� �۷ι� ���� (���� ���� �� ���)
(defun Load_Global_Settings ()
  (if (setq val (getenv "PC_MCTE_x1")) (setq g_x1_off (atof val)) (setq g_x1_off 0.0))
  (if (setq val (getenv "PC_MCTE_y1")) (setq g_y1_off (atof val)) (setq g_y1_off 0.0))
  (if (setq val (getenv "PC_MCTE_x2")) (setq g_x2_off (atof val)) (setq g_x2_off 0.0))
  (if (setq val (getenv "PC_MCTE_y2")) (setq g_y2_off (atof val)) (setq g_y2_off 0.0))
  (if (setq val (getenv "PC_MCTE_sample")) (setq g_sample_name val) (setq g_sample_name "���õ��� ����"))
  (if (setq val (getenv "PC_MCTE_active_mode")) (setq g_active_mode val) (setq g_active_mode "SLAB"))
  (if (setq val (getenv "PC_MCTE_girder_frame_handle")) (setq g_girder_frame_handle val) (setq g_girder_frame_handle ""))
  (if (setq val (getenv "PC_MCTE_girder_frame_label")) (setq g_girder_frame_label val) (setq g_girder_frame_label "���� ������"))
  (if (setq val (getenv "PC_MCTE_girder_con_handle")) (setq g_girder_con_handle val) (setq g_girder_con_handle ""))
  (if (setq val (getenv "PC_MCTE_girder_con_label")) (setq g_girder_con_label val) (setq g_girder_con_label "��ũ��Ʈ ���̾� ������"))
  (if (and (= g_active_mode "GIRDER") (/= g_girder_frame_handle ""))
    (progn
      (setq g_girder_frame_label (strcat "����: " g_girder_frame_handle))
      (setq g_sample_name g_girder_frame_label)
    )
  )
)

(defun Save_Global_Settings ()
  (setenv "PC_MCTE_x1" (rtos g_x1_off 2 6))
  (setenv "PC_MCTE_y1" (rtos g_y1_off 2 6))
  (setenv "PC_MCTE_x2" (rtos g_x2_off 2 6))
  (setenv "PC_MCTE_y2" (rtos g_y2_off 2 6))
  (setenv "PC_MCTE_sample" g_sample_name)
  (setenv "PC_MCTE_active_mode" g_active_mode)
  (setenv "PC_MCTE_girder_frame_handle" g_girder_frame_handle)
  (setenv "PC_MCTE_girder_frame_label" g_girder_frame_label)
  (setenv "PC_MCTE_girder_con_handle" g_girder_con_handle)
  (setenv "PC_MCTE_girder_con_label" g_girder_con_label)
)

;; ��庰 ���� ȯ�溯�� �δ�
(defun Load_Mode_Config (mode / pref val)
  (setq pref (strcat "PC_MCTE_" mode "_"))
  (if (setq val (getenv (strcat pref "op_list"))) (setq g_op_list (Read_Comma_List val)) (setq g_op_list (list "OPENING")))
  
  (if (= mode "DOUBLE")
    (progn
      (if (setq val (getenv (strcat pref "out_con_list"))) (setq g_out_con_list (Read_Comma_List val)) (setq g_out_con_list (list "CONCRETE_OUT:256")))
      (if (setq val (getenv (strcat pref "in_con_list"))) (setq g_in_con_list (Read_Comma_List val)) (setq g_in_con_list (list "CONCRETE_IN:256")))
    )
    (if (setq val (getenv (strcat pref "con_list"))) (setq g_con_list (Read_Comma_List val)) (setq g_con_list (list "CONCRETE")))
  )
  
  (if (setq val (getenv (strcat pref "tg_m16"))) (setq g_tg_m16 val) (setq g_tg_m16 "0"))
  (if (setq val (getenv (strcat pref "m16_blk"))) (setq g_m16_blk val) (setq g_m16_blk "���þȵ�"))

  (if (setq val (getenv (strcat pref "hdr_sep"))) (setq g_hdr_sep val) (setq g_hdr_sep "-"))
  (if (setq val (getenv (strcat pref "hdr_suffix"))) (setq g_hdr_suffix val) (setq g_hdr_suffix ""))
  (if (setq val (getenv (strcat pref "hdr_lot_nm"))) (setq g_hdr_lot_nm val) (setq g_hdr_lot_nm "LOT"))
  (if (setq val (getenv (strcat pref "hdr_blank"))) (setq g_hdr_blank val) (setq g_hdr_blank ""))
  (if (setq val (getenv (strcat pref "rebar_no"))) (setq g_rebar_no val) (setq g_rebar_no "61"))
  (if (= (vl-string-trim " \t\n\r" g_rebar_no) "") (setq g_rebar_no "61"))
  
  (if (setq val (getenv (strcat pref "hdr_out_prefix"))) (setq g_hdr_out_prefix val) (setq g_hdr_out_prefix ""))
  (if (setq val (getenv (strcat pref "hdr_in_prefix"))) (setq g_hdr_in_prefix val) (setq g_hdr_in_prefix ""))
  
  (if (setq val (getenv (strcat pref "hdr_con_pref"))) (setq g_hdr_con_pref val) (setq g_hdr_con_pref ""))
  (if (setq val (getenv (strcat pref "hdr_con_w"))) (setq g_hdr_con_w val) (setq g_hdr_con_w "����"))
  (if (setq val (getenv (strcat pref "hdr_con_h"))) (setq g_hdr_con_h val) (setq g_hdr_con_h "����"))
  
  (if (setq val (getenv (strcat pref "hdr_op_pref"))) (setq g_hdr_op_pref val) (setq g_hdr_op_pref "OP_"))
  (if (setq val (getenv (strcat pref "hdr_op_ox"))) (setq g_hdr_op_ox val) (setq g_hdr_op_ox "������ ����"))
  (if (setq val (getenv (strcat pref "hdr_w"))) (setq g_hdr_w val) (setq g_hdr_w "����"))
  (if (setq val (getenv (strcat pref "hdr_h"))) (setq g_hdr_h val) (setq g_hdr_h "����"))
  (if (setq val (getenv (strcat pref "hdr_x"))) (setq g_hdr_x val) (setq g_hdr_x "X��ǥ"))
  (if (setq val (getenv (strcat pref "hdr_y"))) (setq g_hdr_y val) (setq g_hdr_y "Y��ǥ"))
  
  (if (setq val (getenv (strcat pref "hdr_slv_pref"))) (setq g_hdr_slv_pref val) (setq g_hdr_slv_pref "SL_"))
  (if (setq val (getenv (strcat pref "hdr_slv_ox"))) (setq g_hdr_slv_ox val) (setq g_hdr_slv_ox "������ ����"))
  (if (setq val (getenv (strcat pref "hdr_dia"))) (setq g_hdr_dia val) (setq g_hdr_dia "DIA"))
  (if (setq val (getenv (strcat pref "hdr_sx"))) (setq g_hdr_sx val) (setq g_hdr_sx "X��ǥ"))
  (if (setq val (getenv (strcat pref "hdr_sy"))) (setq g_hdr_sy val) (setq g_hdr_sy "Y��ǥ"))

  (if (setq val (getenv (strcat pref "hdr_m16_pref"))) (setq g_hdr_m16_pref val) (setq g_hdr_m16_pref "M16_"))
  (if (setq val (getenv (strcat pref "hdr_m16_ox"))) (setq g_hdr_m16_ox val) (setq g_hdr_m16_ox "M16 ����"))
  (if (setq val (getenv (strcat pref "hdr_m16_x"))) (setq g_hdr_m16_x val) (setq g_hdr_m16_x "X��ǥ"))
  (if (setq val (getenv (strcat pref "hdr_m16_y"))) (setq g_hdr_m16_y val) (setq g_hdr_m16_y "Y��ǥ"))
)

(defun Save_Mode_Config (mode / pref)
  (setq pref (strcat "PC_MCTE_" mode "_"))
  (setenv (strcat pref "op_list") (Write_Comma_List g_op_list))
  
  (if (= mode "DOUBLE")
    (progn
      (setenv (strcat pref "out_con_list") (Write_Comma_List g_out_con_list))
      (setenv (strcat pref "in_con_list") (Write_Comma_List g_in_con_list))
    )
    (setenv (strcat pref "con_list") (Write_Comma_List g_con_list))
  )
  
  (setenv (strcat pref "tg_m16") g_tg_m16)
  (setenv (strcat pref "m16_blk") g_m16_blk)

  (setenv (strcat pref "hdr_sep") g_hdr_sep)
  (setenv (strcat pref "hdr_suffix") g_hdr_suffix)
  (setenv (strcat pref "hdr_lot_nm") g_hdr_lot_nm)
  (setenv (strcat pref "hdr_blank") g_hdr_blank)
  (setenv (strcat pref "rebar_no") g_rebar_no)
  
  (setenv (strcat pref "hdr_out_prefix") g_hdr_out_prefix)
  (setenv (strcat pref "hdr_in_prefix") g_hdr_in_prefix)
  
  (setenv (strcat pref "hdr_con_pref") g_hdr_con_pref)
  (setenv (strcat pref "hdr_con_w") g_hdr_con_w)
  (setenv (strcat pref "hdr_con_h") g_hdr_con_h)
  
  (setenv (strcat pref "hdr_op_pref") g_hdr_op_pref)
  (setenv (strcat pref "hdr_op_ox") g_hdr_op_ox)
  (setenv (strcat pref "hdr_w") g_hdr_w)
  (setenv (strcat pref "hdr_h") g_hdr_h)
  (setenv (strcat pref "hdr_x") g_hdr_x)
  (setenv (strcat pref "hdr_y") g_hdr_y)
  
  (setenv (strcat pref "hdr_slv_pref") g_hdr_slv_pref)
  (setenv (strcat pref "hdr_slv_ox") g_hdr_slv_ox)
  (setenv (strcat pref "hdr_dia") g_hdr_dia)
  (setenv (strcat pref "hdr_sx") g_hdr_sx)
  (setenv (strcat pref "hdr_sy") g_hdr_sy)

  (setenv (strcat pref "hdr_m16_pref") g_hdr_m16_pref)
  (setenv (strcat pref "hdr_m16_ox") g_hdr_m16_ox)
  (setenv (strcat pref "hdr_m16_x") g_hdr_m16_x)
  (setenv (strcat pref "hdr_m16_y") g_hdr_m16_y)
)

;; ���� DCL ���� â ���� ���� ����
(defun Run_Settings_Dialog (mode / dcl-id s-loop-flag ent idx stat res settings-file f-set)
  (Load_Mode_Config mode)
  (setq settings-file (strcat (getvar "ROAMABLEROOTPREFIX") "Support\\pc_op_settings_tmp.dcl"))
  (setq f-set (open settings-file "w"))
  
  (write-line "pc_op_settings : dialog { key = \"lbl_setting_title\"; label = \"���� ����\";" f-set)
  (write-line "  : row {" f-set)
  (write-line "    : column { width = 50;" f-set)
  (write-line "      : boxed_column { label = \"���� ���� ����\";" f-set)
  (write-line "        : text { label = \"[ ���� ]\"; }" f-set)
  (write-line "        : row {" f-set)
  (write-line "          : column { : edit_box { key = \"txt_sep\"; width = 6; } : text { label = \"���б�ȣ\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_suffix\"; width = 6; } : text { label = \"������\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_lot_nm\"; width = 8; } : text { label = \"LOT(��Ʈ��ȣ)\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_blank\"; width = 6; } : text { label = \"�⺻��(��)\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_rebar_no\"; width = 6; } : text { label = \"�����ٹ�ȣ\"; alignment = centered; } }" f-set)
  (write-line "        }" f-set)
  
  (if (= mode "DOUBLE")
    (progn
      (write-line "        : row {" f-set)
      (write-line "          : column { : edit_box { key = \"txt_out_prefix\"; width = 8; } : text { label = \"���� ���б�ȣ\"; alignment = centered; } }" f-set)
      (write-line "          : column { : edit_box { key = \"txt_in_prefix\"; width = 8; } : text { label = \"���� ���б�ȣ\"; alignment = centered; } }" f-set)
      (write-line "        }" f-set)
    )
  )

  (write-line "        : text { label = \"[ ��ũ��Ʈ ]\"; }" f-set)
  (write-line "        : row {" f-set)
  (write-line "          : column { : edit_box { key = \"txt_con_pref\"; width = 8; } : text { label = \"�Ӹ���\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_con_w\"; width = 6; } : text { label = \"����\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_con_h\"; width = 6; } : text { label = \"����\"; alignment = centered; } }" f-set)
  (write-line "        }" f-set)
  (write-line "        : text { label = \"[ ������ ]\"; }" f-set)
  (write-line "        : row {" f-set)
  (write-line "          : column { : edit_box { key = \"txt_op_pref\"; width = 8; } : text { label = \"�Ӹ���\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_op_ox\"; width = 8; } : text { label = \"O/X\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_w\"; width = 6; } : text { label = \"����\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_h\"; width = 6; } : text { label = \"����\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_x\"; width = 6; } : text { label = \"X��ǥ\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_y\"; width = 6; } : text { label = \"Y��ǥ\"; alignment = centered; } }" f-set)
  (write-line "        }" f-set)
  (write-line "        : text { label = \"[ ������ ]\"; }" f-set)
  (write-line "        : row {" f-set)
  (write-line "          : column { : edit_box { key = \"txt_slv_pref\"; width = 8; } : text { label = \"�Ӹ���\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_slv_ox\"; width = 8; } : text { label = \"O/X\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_dia\"; width = 6; } : text { label = \"DIA\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_sx\"; width = 6; } : text { label = \"X��ǥ\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_sy\"; width = 6; } : text { label = \"Y��ǥ\"; alignment = centered; } }" f-set)
  (write-line "        }" f-set)
  (write-line "        : text { label = \"[ M16 INSERT ]\"; }" f-set)
  (write-line "        : row {" f-set)
  (write-line "          : column { : edit_box { key = \"txt_m16_pref\"; width = 8; } : text { label = \"�Ӹ���\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_m16_ox\"; width = 8; } : text { label = \"O/X\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_m16_x\"; width = 6; } : text { label = \"X��ǥ\"; alignment = centered; } }" f-set)
  (write-line "          : column { : edit_box { key = \"txt_m16_y\"; width = 6; } : text { label = \"Y��ǥ\"; alignment = centered; } }" f-set)
  (write-line "        }" f-set)
  (write-line "      }" f-set)
  (write-line "    }" f-set)
  (write-line "    : column { width = 45;" f-set)
  (write-line "      : boxed_column { label = \"������ ���̾� ���(�߰� �νĿ� / �ڵ��ν� ����)\";" f-set)
  (write-line "        : list_box { key = \"list_op\"; height = 4; width = 43; }" f-set)
  (write-line "        : row {" f-set)
  (write-line "          : button { label = \"������ �߰�\"; key = \"btn_add_op\"; }" f-set)
  (write-line "          : button { label = \"������ ����\"; key = \"btn_del_op\"; }" f-set)
  (write-line "        }" f-set)
  (write-line "      }" f-set)
  
  (if (= mode "DOUBLE")
    (progn
      (write-line "      : boxed_column { label = \"���� ��ũ��Ʈ ���̾� ���\";" f-set)
      (write-line "        : list_box { key = \"list_con_out\"; height = 3; width = 43; }" f-set)
      (write-line "        : row {" f-set)
      (write-line "          : button { label = \"���� �߰�\"; key = \"btn_add_con_out\"; }" f-set)
      (write-line "          : button { label = \"���� ����\"; key = \"btn_del_con_out\"; }" f-set)
      (write-line "        }" f-set)
      (write-line "      }" f-set)
      (write-line "      : boxed_column { label = \"���� ��ũ��Ʈ ���̾� ���\";" f-set)
      (write-line "        : list_box { key = \"list_con_in\"; height = 3; width = 43; }" f-set)
      (write-line "        : row {" f-set)
      (write-line "          : button { label = \"���� �߰�\"; key = \"btn_add_con_in\"; }" f-set)
      (write-line "          : button { label = \"���� ����\"; key = \"btn_del_con_in\"; }" f-set)
      (write-line "        }" f-set)
      (write-line "      }" f-set)
    )
    (progn
      (write-line "      : boxed_column { label = \"��ũ��Ʈ ���̾� ���\";" f-set)
      (write-line "        : list_box { key = \"list_con_slab\"; height = 4; width = 43; }" f-set)
      (write-line "        : row {" f-set)
      (write-line "          : button { label = \"��ũ��Ʈ �߰�\"; key = \"btn_add_con_slab\"; }" f-set)
      (write-line "          : button { label = \"��ũ��Ʈ ����\"; key = \"btn_del_con_slab\"; }" f-set)
      (write-line "        }" f-set)
      (write-line "      }" f-set)
    )
  )
  
  (write-line "      : boxed_column { label = \"�߰� ���\";" f-set)
  (write-line "        : row {" f-set)
  (write-line "          : toggle { label = \"M16 ����\"; key = \"tg_m16\"; is_bold = true; }" f-set)
  (write-line "          : button { label = \"���� ����\"; key = \"btn_pick_m16\"; }" f-set)
  (write-line "        }" f-set)
  (write-line "        : text { key = \"lbl_m16_blk\"; value = \"���þȵ�\"; }" f-set)
  (write-line "      }" f-set)
  (write-line "    }" f-set)
  (write-line "  }" f-set)
  (write-line "  ok_cancel;" f-set)
  (write-line "}" f-set)
  (close f-set)
  
  (setq s-loop-flag t)
  (while s-loop-flag
    (setq dcl-id (load_dialog settings-file))
    (new_dialog "pc_op_settings" dcl-id)
    
    (if (= mode "SLAB")
      (set_tile "lbl_setting_title" "����(������ / �ָ����)")
      (set_tile "lbl_setting_title" "����(������)")
    )
    
    (set_tile "txt_sep" g_hdr_sep)
    (set_tile "txt_suffix" g_hdr_suffix)
    (set_tile "txt_lot_nm" g_hdr_lot_nm)
    (set_tile "txt_blank" g_hdr_blank)
    (set_tile "txt_rebar_no" g_rebar_no)
    
    (if (= mode "DOUBLE")
      (progn
        (set_tile "txt_out_prefix" g_hdr_out_prefix)
        (set_tile "txt_in_prefix" g_hdr_in_prefix)
      )
    )
    
    (set_tile "txt_con_pref" g_hdr_con_pref)
    (set_tile "txt_con_w" g_hdr_con_w)
    (set_tile "txt_con_h" g_hdr_con_h)
    
    (set_tile "txt_op_pref" g_hdr_op_pref)
    (set_tile "txt_op_ox" g_hdr_op_ox)
    (set_tile "txt_w" g_hdr_w)
    (set_tile "txt_h" g_hdr_h)
    (set_tile "txt_x" g_hdr_x)
    (set_tile "txt_y" g_hdr_y)
    
    (set_tile "txt_slv_pref" g_hdr_slv_pref)
    (set_tile "txt_slv_ox" g_hdr_slv_ox)
    (set_tile "txt_dia" g_hdr_dia)
    (set_tile "txt_sx" g_hdr_sx)
    (set_tile "txt_sy" g_hdr_sy)

    (set_tile "txt_m16_pref" g_hdr_m16_pref)
    (set_tile "txt_m16_ox" g_hdr_m16_ox)
    (set_tile "txt_m16_x" g_hdr_m16_x)
    (set_tile "txt_m16_y" g_hdr_m16_y)

    (set_tile "tg_m16" g_tg_m16)
    (set_tile "lbl_m16_blk" g_m16_blk)

    (start_list "list_op") (foreach item g_op_list (add_list (Format-Lay-Col-String item))) (end_list)
    
    (if (= mode "DOUBLE")
      (progn
        (start_list "list_con_out") (foreach item g_out_con_list (add_list (Format-Lay-Col-String item))) (end_list)
        (start_list "list_con_in") (foreach item g_in_con_list (add_list (Format-Lay-Col-String item))) (end_list)
      )
      (progn
        (start_list "list_con_slab") (foreach item g_con_list (add_list item)) (end_list)
      )
    )

    (action_tile "btn_add_op" "(done_dialog 3)")
    (action_tile "btn_add_con_slab" "(done_dialog 4)")
    (action_tile "btn_add_con_out" "(done_dialog 24)")
    (action_tile "btn_add_con_in" "(done_dialog 25)")
    (action_tile "btn_pick_m16" "(done_dialog 7)")
    
    (action_tile "btn_del_op" "(progn (setq idx (atoi (get_tile \"list_op\"))) (if (>= idx 0) (setq g_op_list (vl-remove (nth idx g_op_list) g_op_list))) (done_dialog 5))")
    (action_tile "btn_del_con_slab" "(progn (setq idx (atoi (get_tile \"list_con_slab\"))) (if (>= idx 0) (setq g_con_list (vl-remove (nth idx g_con_list) g_con_list))) (done_dialog 5))")
    (action_tile "btn_del_con_out" "(progn (setq idx (atoi (get_tile \"list_con_out\"))) (if (>= idx 0) (setq g_out_con_list (vl-remove (nth idx g_out_con_list) g_out_con_list))) (done_dialog 5))")
    (action_tile "btn_del_con_in" "(progn (setq idx (atoi (get_tile \"list_con_in\"))) (if (>= idx 0) (setq g_in_con_list (vl-remove (nth idx g_in_con_list) g_in_con_list))) (done_dialog 5))")
    
    (action_tile "accept" (strcat "(progn "
      "(setq g_tg_m16 (get_tile \"tg_m16\") "
      "g_hdr_sep (get_tile \"txt_sep\") "
      "g_hdr_suffix (get_tile \"txt_suffix\") "
      "g_hdr_lot_nm (get_tile \"txt_lot_nm\") "
      "g_hdr_blank (get_tile \"txt_blank\") "
      "g_rebar_no (vl-string-trim \" \\t\\n\\r\" (get_tile \"txt_rebar_no\")) "
      (if (= mode "DOUBLE") "g_hdr_out_prefix (get_tile \"txt_out_prefix\") g_hdr_in_prefix (get_tile \"txt_in_prefix\") " "")
      "g_hdr_con_pref (get_tile \"txt_con_pref\") "
      "g_hdr_con_w (get_tile \"txt_con_w\") "
      "g_hdr_con_h (get_tile \"txt_con_h\") "
      "g_hdr_op_pref (get_tile \"txt_op_pref\") "
      "g_hdr_op_ox (get_tile \"txt_op_ox\") "
      "g_hdr_w (get_tile \"txt_w\") "
      "g_hdr_h (get_tile \"txt_h\") "
      "g_hdr_x (get_tile \"txt_x\") "
      "g_hdr_y (get_tile \"txt_y\") "
      "g_hdr_slv_pref (get_tile \"txt_slv_pref\") "
      "g_hdr_slv_ox (get_tile \"txt_slv_ox\") "
      "g_hdr_dia (get_tile \"txt_dia\") "
      "g_hdr_sx (get_tile \"txt_sx\") "
      "g_hdr_sy (get_tile \"txt_sy\") "
      "g_hdr_m16_pref (get_tile \"txt_m16_pref\") "
      "g_hdr_m16_ox (get_tile \"txt_m16_ox\") "
      "g_hdr_m16_x (get_tile \"txt_m16_x\") "
      "g_hdr_m16_y (get_tile \"txt_m16_y\") "
      ") (if (= g_rebar_no \"\") (setq g_rebar_no \"61\")) (Save_Mode_Config \"" mode "\") (done_dialog 1))"))
    
    (action_tile "cancel" "(done_dialog 0)")
    
    (setq stat (start_dialog))
    (unload_dialog dcl-id)
    
    (cond
      ((= stat 0) (setq s-loop-flag nil))
      ((= stat 1) (setq s-loop-flag nil))
      ((= stat 3) (setq res (Pick-Layer-Color "\n������ ���̾� ��ü Ŭ��: ")) (if res (setq g_op_list (append g_op_list (list res)))))
      ((= stat 4) (setq res (Pick-Layer-Only "\n��ũ��Ʈ ���̾� ��ü Ŭ��: ")) (if res (setq g_con_list (append g_con_list (list res)))))
      ((= stat 24) (setq res (Pick-Layer-Color "\n���� ��ũ��Ʈ ���̾� ��ü Ŭ��: ")) (if res (setq g_out_con_list (append g_out_con_list (list res)))))
      ((= stat 25) (setq res (Pick-Layer-Color "\n���� ��ũ��Ʈ ���̾� ��ü Ŭ��: ")) (if res (setq g_in_con_list (append g_in_con_list (list res)))))
      ((= stat 7) (setq ent (car (entsel "\nM16 INSERT ������ �����ϼ���: "))) (if ent (progn (if (= (cdr (assoc 0 (entget ent))) "INSERT") (setq g_m16_blk (Get-Effective-Name ent)) (alert "������ �ƴմϴ�.")))))
      ((= stat 5))
    )
  )
  (vl-file-delete settings-file)
)


(defun pcg-q (s)
  (strcat "\"" s "\"")
)

(defun pcg-write-lines (path lines / f)
  (setq f (open path "w"))
  (foreach line lines (write-line line f))
  (close f)
)

(defun pcg-split-comma (s / pos out)
  (setq out nil)
  (while (setq pos (vl-string-search "," s))
    (setq out (append out (list (substr s 1 pos))))
    (setq s (substr s (+ pos 2)))
  )
  (append out (list s))
)

;; AutoLISP���� length �ɺ��� ���� �������� �浹�ϴ� ������ ���ϱ� ���� ���� ī����
(defun pcg-list-length (lst / n)
  (setq n 0)
  (while lst
    (setq n (1+ n))
    (setq lst (cdr lst))
  )
  n
)

(defun pcg-col-letter (n / s r)
  (setq s "")
  (while (> n 0)
    (setq r (rem (1- n) 26))
    (setq s (strcat (chr (+ 65 r)) s))
    (setq n (/ (- n r 1) 26))
  )
  s
)

(defun pcg-open-excel (path / xl-app xl-books xl-book xl-sheet f line row col values cell addr rng)
  (vl-load-com)
  (setq xl-app (vlax-get-or-create-object "Excel.Application"))
  (setq xl-books (vlax-get-property xl-app 'Workbooks))
  (setq xl-book (vlax-invoke-method xl-books 'Add))
  (setq xl-sheet (vlax-get-property xl-book 'ActiveSheet))
  (setq f (open path "r"))
  (setq row 1)
  (while (setq line (read-line f))
    (setq values (pcg-split-comma line))
    (setq col 1)
    (foreach cell values
      (setq addr (strcat (pcg-col-letter col) (itoa row)))
      (setq rng (vlax-get-property xl-sheet 'Range addr))
      (vlax-put-property rng 'Value2 cell)
      (setq col (1+ col))
    )
    (setq row (1+ row))
  )
  (close f)
  (vlax-invoke-method (vlax-get-property xl-sheet 'Columns) 'AutoFit)
  (vla-put-visible xl-app :vlax-true)
  (vlax-invoke-method xl-app 'Activate)
  xl-book
)

(defun pcg-js-escape (s / out i ch)
  (setq out "" i 1 s (if s s ""))
  (while (<= i (strlen s))
    (setq ch (substr s i 1))
    (cond
      ((= ch "\\") (setq out (strcat out "\\\\")))
      ((= ch "\"") (setq out (strcat out "\\\"")))
      (t (setq out (strcat out ch)))
    )
    (setq i (1+ i))
  )
  out
)

(defun pcg-js-array (lst / arr x)
  (setq arr "[")
  (if lst
    (foreach x lst
      (setq arr
        (strcat arr
          (if (= arr "[") "" ",")
          "\"" (pcg-js-escape x) "\""
        )
      )
    )
  )
  (strcat arr "]")
)


;; pcg-js-lines ����: �Ŵ� ���� ���� AutoLISP �������� �����Ѵ�.

(defun Run_Girder_Settings_Dialog (/ settings-file f-set dcl-id stat idx res ent ed lay item)
  (Load_Mode_Config "GIRDER")
  (setq settings-file (strcat (getvar "ROAMABLEROOTPREFIX") "Support\\pc_girder_settings_tmp.dcl"))
  (setq f-set (open settings-file "w"))
  (write-line "pc_girder_settings : dialog { label = \"����(�Ŵ�)\";" f-set)
  (write-line "  : column {" f-set)
  (write-line "    : boxed_column { label = \"������ ���̾� ���(�߰� �νĿ� / �ڵ��ν� ����)\";" f-set)
  (write-line "      : list_box { key = \"list_op\"; height = 5; width = 48; }" f-set)
  (write-line "      : row {" f-set)
  (write-line "        : button { label = \"������ �߰�\"; key = \"btn_add_op\"; }" f-set)
  (write-line "        : button { label = \"������ ����\"; key = \"btn_del_op\"; }" f-set)
  (write-line "      }" f-set)
  (write-line "    }" f-set)
  (write-line "    : boxed_column { label = \"��ũ��Ʈ ���̾� ���\";" f-set)
  (write-line "      : list_box { key = \"list_con\"; height = 5; width = 48; }" f-set)
  (write-line "      : text { key = \"lbl_con_sample\"; width = 48; }" f-set)
  (write-line "      : row {" f-set)
  (write-line "        : button { label = \"��ũ��Ʈ �߰�\"; key = \"btn_add_con\"; }" f-set)
  (write-line "        : button { label = \"��ũ��Ʈ ����\"; key = \"btn_del_con\"; }" f-set)
  (write-line "      }" f-set)
  (write-line "    }" f-set)
  (write-line "    : row {" f-set)
  (write-line "      : button { label = \"Ȯ ��\"; key = \"accept\"; is_default = true; }" f-set)
  (write-line "      : button { label = \"�� ��\"; key = \"cancel\"; is_cancel = true; }" f-set)
  (write-line "    }" f-set)
  (write-line "  }" f-set)
  (write-line "}" f-set)
  (close f-set)

  (setq stat 99)
  (while (/= stat 0)
    (setq dcl-id (load_dialog settings-file))
    (new_dialog "pc_girder_settings" dcl-id)

    (start_list "list_op")
    (foreach item g_op_list (add_list (Format-Lay-Col-String item)))
    (end_list)

    (start_list "list_con")
    (foreach item g_con_list (add_list (Format-Lay-Col-String item)))
    (end_list)

    (set_tile "lbl_con_sample" g_girder_con_label)
    (action_tile "btn_add_op" "(done_dialog 3)")
    (action_tile "btn_del_op" "(progn (setq idx (atoi (get_tile \"list_op\"))) (if (>= idx 0) (setq g_op_list (vl-remove (nth idx g_op_list) g_op_list))) (done_dialog 5))")
    (action_tile "btn_add_con" "(done_dialog 4)")
    (action_tile "btn_del_con" "(progn (setq idx (atoi (get_tile \"list_con\"))) (if (>= idx 0) (setq g_con_list (vl-remove (nth idx g_con_list) g_con_list))) (if (= (pcg-list-length g_con_list) 0) (setq g_girder_con_handle \"\" g_girder_con_label \"��ũ��Ʈ ���̾� ������\")) (done_dialog 5))")
    (action_tile "accept" "(progn (Save_Mode_Config \"GIRDER\") (done_dialog 1))")
    (action_tile "cancel" "(done_dialog 0)")

    (setq stat (start_dialog))
    (unload_dialog dcl-id)

    (cond
      ((= stat 1) (setq stat 0))
      ((= stat 3)
        (setq res (Pick-Layer-Color "\n�Ŵ� ������ ���̾� ��ü Ŭ��: "))
        (if res (setq g_op_list (append g_op_list (list res))))
        (Save_Mode_Config "GIRDER")
        (setq stat 99)
      )
      ((= stat 4)
        (setq ent (car (entsel "\n�Ŵ� ��ũ��Ʈ ���̾� ��ü Ŭ��: ")))
        (if ent
          (progn
            (setq ed (entget ent))
            (setq lay (cdr (assoc 8 ed)))
            (setq res (if (cdr (assoc 62 ed)) (strcat lay ":" (itoa (cdr (assoc 62 ed)))) lay))
            (setq g_con_list (append g_con_list (list res)))
            (setq g_girder_con_handle (cdr (assoc 5 ed)))
            (setq g_girder_con_label (strcat "��ũ��Ʈ ����: " (Format-Lay-Col-String res)))
            (Save_Mode_Config "GIRDER")
            (Save_Global_Settings)
          )
        )
        (setq stat 99)
      )
      ((= stat 5)
        (Save_Mode_Config "GIRDER")
        (setq stat 99)
      )
    )
  )
  (vl-file-delete settings-file)
)

(defun Load_Girder_Summary_From_Csv (path / f line row values headers lot opcnt slvcnt status err total-cnt current-idx col-idx hname val)
  (setq g_summary_data nil)
  (setq g_girder_csv_path path)
  (setq total-cnt 0)
  (setq f (open path "r"))
  (if f
    (progn
      (setq line (read-line f))
      (setq headers (if line (pcg-split-comma line) nil))
      (while (setq line (read-line f))
        (if (/= line "") (setq total-cnt (1+ total-cnt)))
      )
      (close f)
    )
  )
  (setq f (open path "r"))
  (if f
    (progn
      (setq line (read-line f))
      (setq headers (if line (pcg-split-comma line) nil))
      (setq current-idx 1)
      (while (setq line (read-line f))
        (if (/= line "")
          (progn
            (princ (strcat "\n[���� ��Ȳ] " (itoa current-idx) " / " (itoa total-cnt) " ���� ���� ��..."))
            (setq values (pcg-split-comma line))
            (setq lot (car values))
            (setq opcnt 0 slvcnt 0 status "����" err "")
            (if (not (Is_Lot_Number_Format lot))
              (setq status "����" err "��Ʈ��ȣ ���� ����")
            )
            (setq col-idx 0)
            (foreach hname headers
              (setq val (nth col-idx values))
              (if (= val "1")
                (progn
                  (if (or
                        (wcmatch (strcase hname) "*VOID*VISIBLE*")
                        (= (strcase hname) "A_VISIBLE##LENGTH##MILLIMETERS")
                        (= (strcase hname) "B_VISIBLE##LENGTH##MILLIMETERS")
                        (= (strcase hname) "C_VISIBLE##LENGTH##MILLIMETERS")
                        (= (strcase hname) "D_VISIBLE##LENGTH##MILLIMETERS")
                      )
                    (setq opcnt (1+ opcnt))
                  )
                  (if (or (wcmatch (strcase hname) "*SLEEVE*VISIBLE*") (wcmatch (strcase hname) "*SLV*VISIBLE*")) (setq slvcnt (1+ slvcnt)))
                )
              )
              (setq col-idx (1+ col-idx))
            )
            (setq row (list lot (itoa opcnt) (itoa slvcnt) "0" status nil nil nil err))
            (setq g_summary_data (append g_summary_data (list row)))
            (setq current-idx (1+ current-idx))
          )
        )
      )
      (close f)
    )
  )
  g_summary_data
)


;; =========================================================
;; �Ŵ� ���� AutoLISP ���� ����
;; - �ܺ� DLL / Node.js ���� DWG ��ü�� ���� ��ĵ�Ѵ�.
;; - �Ŵ� ��忡�� ������ ������ INSERT�̸� ���� EffectiveName ������ ��� �����Ѵ�.
;; - ��ũ��Ʈ ���̾� ����� �Ŵ� �ܸ�/��� �������� �ĺ��� ����Ѵ�.
;; - ������ ���̾� ����� ������� ���Ѵ�.
;; - ������ ��ǥ�� ���� ��� ����, ������� ���� ��Ĵ�� �߽� ������ �����Ѵ�.
;; =========================================================

(defun pcg-join (lst sep / res first)
  ;; CSV�� ���ڿ� ���� �Լ�
  ;; ���� ����� ù ���� ""�� �� �����ڸ� ������ ���ؼ�
  ;; A�� ���� ����� ������� ��ü ����� �� ĭ�� �������� �������.
  ;; first �÷��׸� ����ؼ� �� ���ڿ��� �ϳ��� ���� �����Ѵ�.
  (setq res "")
  (setq first t)
  (foreach x lst
    (if first
      (progn
        (setq res (vl-princ-to-string x))
        (setq first nil)
      )
      (setq res (strcat res sep (vl-princ-to-string x)))
    )
  )
  res
)

(defun pcg-clean-lot-lsp (lot / s)
  (setq s (vl-string-trim " \t\n\r" (if lot lot "")))
  (Parse_Lot_Number s)
)

(defun pcg-ent-bounds (ent / obj minpt maxpt mn mx res ed p)
  (vl-load-com)
  (setq res
    (vl-catch-all-apply
      '(lambda ()
        (setq obj (vlax-ename->vla-object ent))
        (vla-getboundingbox obj 'minpt 'maxpt)
        (setq mn (vlax-safearray->list minpt))
        (setq mx (vlax-safearray->list maxpt))
        (list (car mn) (cadr mn) (car mx) (cadr mx))
      )
    )
  )
  (if (vl-catch-all-error-p res)
    (progn
      (setq ed (entget ent))
      (setq p (cdr (assoc 10 ed)))
      (if p
        (list (car p) (cadr p) (car p) (cadr p))
        nil
      )
    )
    res
  )
)

(defun pcg-box-w (b) (abs (- (nth 2 b) (nth 0 b))))
(defun pcg-box-h (b) (abs (- (nth 3 b) (nth 1 b))))
(defun pcg-box-area (b) (* (pcg-box-w b) (pcg-box-h b)))
(defun pcg-box-cx (b) (/ (+ (nth 0 b) (nth 2 b)) 2.0))
(defun pcg-box-cy (b) (/ (+ (nth 1 b) (nth 3 b)) 2.0))
(defun pcg-box-center (b) (list (pcg-box-cx b) (pcg-box-cy b)))
(defun pcg-box-inside-p (inner outer / c)
  (setq c (pcg-box-center inner))
  (In_Box_P c (nth 0 outer) (nth 1 outer) (nth 2 outer) (nth 3 outer))
)

(defun pcg-lwpoly-pts (ent / ed pts)
  (setq ed (entget ent))
  (setq pts (mapcar 'cdr (vl-remove-if-not '(lambda (x) (= (car x) 10)) ed)))
  pts
)

(defun pcg-lwpoly-closed-p (ent / flags)
  (setq flags (cdr (assoc 70 (entget ent))))
  (and flags (/= 0 (logand flags 1)))
)

(defun pcg-pts-bounds (pts / xs ys)
  (if pts
    (progn
      (setq xs (mapcar 'car pts))
      (setq ys (mapcar 'cadr pts))
      (list (apply 'min xs) (apply 'min ys) (apply 'max xs) (apply 'max ys))
    )
    nil
  )
)

(defun pcg-normalize-pts (pts / b ox oy)
  (setq b (pcg-pts-bounds pts))
  (if b
    (progn
      (setq ox (nth 0 b) oy (nth 1 b))
      (mapcar '(lambda (p) (list (- (car p) ox) (- (cadr p) oy))) pts)
    )
    nil
  )
)

(defun pcg-frame-nodes (/ frame-ent frame-ed frame-name ss i ent ed nodes b base)
  (setq frame-ent (if (and (boundp 'g_girder_frame_handle) (/= g_girder_frame_handle "")) (handent g_girder_frame_handle) nil))
  (setq nodes nil)
  (if frame-ent
    (progn
      (setq frame-ed (entget frame-ent))
      (if (= (cdr (assoc 0 frame-ed)) "INSERT")
        (progn
          (setq frame-name (Get-Effective-Name frame-ent))
          (setq ss (ssget "X" '((0 . "INSERT"))))
          (if ss
            (progn
              (setq i 0)
              (repeat (sslength ss)
                (setq ent (ssname ss i))
                (if (= (strcase (Get-Effective-Name ent)) (strcase frame-name))
                  (progn
                    (setq b (pcg-ent-bounds ent))
                    (if b (progn (setq ed (entget ent)) (setq base (cdr (assoc 10 ed))) (if (not base) (setq base (list (nth 0 b) (nth 1 b) 0.0))) (setq nodes (cons (list ent b base) nodes))))
                  )
                )
                (setq i (1+ i))
              )
            )
          )
        )
        (progn
          (setq b (pcg-ent-bounds frame-ent))
          (if b (setq nodes (list (list frame-ent b (list (nth 0 b) (nth 1 b) 0.0)))))
        )
      )
    )
  )
  (vl-sort nodes
    '(lambda (a b)
      (if (< (abs (- (nth 3 (cadr a)) (nth 3 (cadr b)))) 1000.0)
        (< (nth 0 (cadr a)) (nth 0 (cadr b)))
        (> (nth 3 (cadr a)) (nth 3 (cadr b)))
      )
    )
  )
)

(defun pcg-collect-texts (/ ss i ent ed typ txt pt out)
  (setq out nil)
  (setq ss (ssget "X" '((0 . "TEXT,MTEXT"))))
  (if ss
    (progn
      (setq i 0)
      (repeat (sslength ss)
        (setq ent (ssname ss i))
        (setq ed (entget ent))
        (setq typ (cdr (assoc 0 ed)))
        (setq txt (cdr (assoc 1 ed)))
        (if (= typ "TEXT")
          (if (and (= (cdr (assoc 72 ed)) 0) (= (cdr (assoc 73 ed)) 0))
            (setq pt (cdr (assoc 10 ed)))
            (setq pt (cdr (assoc 11 ed)))
          )
          (setq pt (cdr (assoc 10 ed)))
        )
        (if (and pt txt) (setq out (cons (list pt txt) out)))
        (setq i (1+ i))
      )
    )
  )
  out
)

(defun pcg-collect-con-polys (/ ss i ent pts b out)
  (setq out nil)
  (setq ss (ssget "X" '((0 . "LWPOLYLINE"))))
  (if ss
    (progn
      (setq i 0)
      (repeat (sslength ss)
        (setq ent (ssname ss i))
        (if (and (pcg-lwpoly-closed-p ent) (Check_Layer_Color_Match ent g_con_list t))
          (progn
            (setq pts (pcg-lwpoly-pts ent))
            (setq b (pcg-pts-bounds pts))
            (if (and pts b (> (pcg-list-length pts) 2))
              (setq out (cons (list ent pts b (pcg-box-area b)) out))
            )
          )
        )
        (setq i (1+ i))
      )
    )
  )
  out
)

(defun pcg-collect-op-objects (/ ss i ent ed typ pts b cen rad out)
  (setq out nil)
  (setq ss (ssget "X" '((0 . "LWPOLYLINE,CIRCLE,LINE"))))
  (if ss
    (progn
      (setq i 0)
      (repeat (sslength ss)
        (setq ent (ssname ss i))
        (if (Check_Layer_Color_Match ent g_op_list t)
          (progn
            (setq ed (entget ent))
            (setq typ (cdr (assoc 0 ed)))
            (cond
              ((= typ "LWPOLYLINE")
                (setq pts (pcg-lwpoly-pts ent))
                (setq b (pcg-pts-bounds pts))
                (if (and pts b (> (pcg-list-length pts) 2))
                  (setq out (cons (list "RECT" ent b) out))
                )
              )
              ((= typ "CIRCLE")
                (setq cen (cdr (assoc 10 ed)))
                (setq rad (cdr (assoc 40 ed)))
                (if (and cen rad)
                  (progn
                    (setq b (list (- (car cen) rad) (- (cadr cen) rad) (+ (car cen) rad) (+ (cadr cen) rad)))
                    (setq out (cons (list "CIRCLE" ent b) out))
                  )
                )
              )
              ((= typ "LINE")
                (setq b (pcg-ent-bounds ent))
                (if b
                  (setq out (cons (list "LINE" ent b) out))
                )
              )
            )
          )
        )
        (setq i (1+ i))
      )
    )
  )
  out
)


(defun pcg-collect-all-closed-polys (/ ss i ent pts b out)
  ;; �Ŵ� ���̵� ������: ���̾� ������ �����ϰ� ����/��鵵 ���� ���� ���� ���������� ���̵� �ĺ��� �߰� �����Ѵ�.
  ;; ���� ������ ��鵵 ���� + ���� �������� �ٽ� �ɷ���, ���� �׵θ�/��鵵 �ܰ����� ���̵�� ������ ���� �����Ѵ�.
  (setq out nil)
  (setq ss (ssget "X" '((0 . "LWPOLYLINE"))))
  (if ss
    (progn
      (setq i 0)
      (repeat (sslength ss)
        (setq ent (ssname ss i))
        (if (pcg-lwpoly-closed-p ent)
          (progn
            (setq pts (pcg-lwpoly-pts ent))
            (setq b (pcg-pts-bounds pts))
            (if (and pts b (> (pcg-list-length pts) 2))
              (setq out (cons (list ent pts b (pcg-box-area b)) out))
            )
          )
        )
        (setq i (1+ i))
      )
    )
  )
  out
)

(defun pcg-box-rel-to-plan (b plan-box)
  (list
    (- (nth 0 b) (nth 0 plan-box))
    (- (nth 1 b) (nth 1 plan-box))
    (- (nth 2 b) (nth 0 plan-box))
    (- (nth 3 b) (nth 1 plan-box))
  )
)

(defun pcg-same-entity-p (a b / ha hb)
  (if (and a b)
    (progn
      (setq ha (cdr (assoc 5 (entget a))))
      (setq hb (cdr (assoc 5 (entget b))))
      (and ha hb (equal ha hb))
    )
    nil
  )
)

(defun pcg-inner-closed-boxes-in-plan (plan-ent plan-box closed-objs / out c ent b rel area plan-area cx cy)
  ;; ������ ���̾�� �� ��� ���̵� ����.
  ;; ��鵵 �ܰ��� �ȿ� ����ִ� ���� ���� ���������� ���̵� �ĺ��� ����.
  ;; ��, ��鵵 ��ü�� �ʹ� ū ��ü�� �����Ѵ�.
  (setq out nil)
  (setq plan-area (pcg-box-area plan-box))
  (foreach c closed-objs
    (setq ent (car c))
    (setq b (nth 2 c))
    (setq area (pcg-box-area b))
    (setq cx (pcg-box-cx b) cy (pcg-box-cy b))
    (if (and
          (not (pcg-same-entity-p ent plan-ent))
          (In_Box_P (list cx cy) (nth 0 plan-box) (nth 1 plan-box) (nth 2 plan-box) (nth 3 plan-box))
          (< area (* plan-area 0.80))
          (> (pcg-box-w b) 5.0)
          (> (pcg-box-h b) 5.0)
        )
      (progn
        (setq rel (pcg-box-rel-to-plan b plan-box))
        (if (not (member rel out))
          (setq out (cons rel out))
        )
      )
    )
  )
  out
)

(defun pcg-lot-from-frame (frame-box base texts / fx1 fy1 fx2 fy2 bx by tx1 ty1 tx2 ty2 minx miny maxx maxy lot cnt found)
  (setq fx1 (nth 0 frame-box) fy1 (nth 1 frame-box) fx2 (nth 2 frame-box) fy2 (nth 3 frame-box))
  (if base (setq bx (car base) by (cadr base)) (setq bx fx1 by fy1))
  (setq lot "��Ʈ��ȣ_�̰���" cnt 0 found nil)
  (if (and (boundp 'g_x1_off) (/= g_x1_off 0.0))
    (progn
      (setq tx1 (+ bx g_x1_off) ty1 (+ by g_y1_off) tx2 (+ bx g_x2_off) ty2 (+ by g_y2_off))
      (setq minx (- (min tx1 tx2) 100.0) miny (- (min ty1 ty2) 100.0) maxx (+ (max tx1 tx2) 100.0) maxy (+ (max ty1 ty2) 100.0))
      (foreach tnode texts
        (if (In_Box_P (car tnode) minx miny maxx maxy)
          (progn
            (setq cnt (1+ cnt))
            (setq lot (cadr tnode))
            (if (Is_Lot_Number_Format (cadr tnode)) (setq found (cadr tnode)))
          )
        )
      )
    )
  )
  (if found
    found
    (progn
      (foreach tnode texts
        (if (and (In_Box_P (car tnode) fx1 fy1 fx2 fy2) (Is_Lot_Number_Format (cadr tnode)))
          (setq lot (cadr tnode))
        )
      )
      lot
    )
  )
)

(defun pcg-candidates-in-frame (frame-box con-objs / out c b)
  (setq out nil)
  (foreach c con-objs
    (setq b (nth 2 c))
    (if (pcg-box-inside-p b frame-box)
      (setq out (cons c out))
    )
  )
  out
)

(defun pcg-pick-plan-side (frame-box candidates / midy upper plan side lower others c b bestarea)
  (setq midy (/ (+ (nth 1 frame-box) (nth 3 frame-box)) 2.0))
  (setq upper nil)
  (foreach c candidates
    (setq b (nth 2 c))
    (if (>= (pcg-box-cy b) midy)
      (setq upper (cons c upper))
    )
  )
  (if (not upper) (setq upper candidates))
  (setq plan nil bestarea -1.0)
  (foreach c upper
    (if (> (nth 3 c) bestarea)
      (setq bestarea (nth 3 c) plan c)
    )
  )
  (setq lower nil others nil)
  (foreach c candidates
    (if (not (equal c plan))
      (progn
        (setq others (cons c others))
        (if (< (pcg-box-cy (nth 2 c)) (pcg-box-cy (nth 2 plan)))
          (setq lower (cons c lower))
        )
      )
    )
  )
  (if (not lower) (setq lower others))
  (setq side nil bestarea -1.0)
  (foreach c lower
    (if (> (nth 3 c) bestarea)
      (setq bestarea (nth 3 c) side c)
    )
  )
  (list plan side)
)

(defun pcg-unique-sorted (vals / sorted out lastv)
  (setq sorted (vl-sort vals '<))
  (setq out nil lastv nil)
  (foreach v sorted
    (if (or (not lastv) (> (abs (- v lastv)) 0.0001))
      (progn
        (setq out (append out (list v)))
        (setq lastv v)
      )
    )
  )
  out
)

(defun pcg-point-in-poly (pt pts / x y inside i j pi pj xi yi xj yj hit n)
  (setq x (car pt) y (cadr pt) inside nil n (pcg-list-length pts) i 0 j (1- n))
  (while (< i n)
    (setq pi (nth i pts) pj (nth j pts))
    (setq xi (car pi) yi (cadr pi) xj (car pj) yj (cadr pj))
    (setq hit (and (/= (> yi y) (> yj y))
                   (< x (+ xi (/ (* (- xj xi) (- y yi)) (if (= (- yj yi) 0.0) 1e-9 (- yj yi)))))))
    (if hit (setq inside (not inside)))
    (setq j i i (1+ i))
  )
  inside
)

(defun pcg-grid-cells (pts length height wantInside / xs ys ix iy x1 x2 y1 y2 inside cells)
  (setq xs (pcg-unique-sorted (append (list 0.0 length) (mapcar 'car pts))))
  (setq ys (pcg-unique-sorted (append (list 0.0 height) (mapcar 'cadr pts))))
  (setq cells nil ix 0)
  (while (< ix (1- (pcg-list-length xs)))
    (setq iy 0)
    (while (< iy (1- (pcg-list-length ys)))
      (setq x1 (nth ix xs) x2 (nth (1+ ix) xs) y1 (nth iy ys) y2 (nth (1+ iy) ys))
      (if (and (> x2 x1) (> y2 y1))
        (progn
          (setq inside (pcg-point-in-poly (list (/ (+ x1 x2) 2.0) (/ (+ y1 y2) 2.0)) pts))
          (if (= inside wantInside)
            (setq cells (cons (list ix iy x1 x2 y1 y2) cells))
          )
        )
      )
      (setq iy (1+ iy))
    )
    (setq ix (1+ ix))
  )
  cells
)

(defun pcg-cell-adj-p (a b)
  (or
    (and (= (car a) (car b)) (= (abs (- (cadr a) (cadr b))) 1))
    (and (= (cadr a) (cadr b)) (= (abs (- (car a) (car b))) 1))
  )
)

(defun pcg-grow-component (start cells / stack comp c adj cand res)
  (setq stack (list start))
  (setq cells (vl-remove start cells))
  (setq comp nil)
  (while stack
    (setq c (car stack))
    (setq stack (cdr stack))
    (setq comp (cons c comp))
    (setq adj nil)
    (foreach cand cells
      (if (pcg-cell-adj-p c cand)
        (setq adj (cons cand adj))
      )
    )
    (foreach cand adj
      (setq cells (vl-remove cand cells))
      (setq stack (cons cand stack))
    )
  )
  (list comp cells)
)

(defun pcg-components (cells / comps res)
  (setq comps nil)
  (while cells
    (setq res (pcg-grow-component (car cells) cells))
    (setq comps (cons (car res) comps))
    (setq cells (cadr res))
  )
  comps
)

(defun pcg-cells-bounds (cells / xs1 xs2 ys1 ys2)
  (setq xs1 (mapcar '(lambda (c) (nth 2 c)) cells))
  (setq xs2 (mapcar '(lambda (c) (nth 3 c)) cells))
  (setq ys1 (mapcar '(lambda (c) (nth 4 c)) cells))
  (setq ys2 (mapcar '(lambda (c) (nth 5 c)) cells))
  (list (apply 'min xs1) (apply 'min ys1) (apply 'max xs2) (apply 'max ys2))
)


(defun pcg-box-near-p (a b tol)
  (not
    (or
      (> (nth 0 a) (+ (nth 2 b) tol))
      (> (nth 0 b) (+ (nth 2 a) tol))
      (> (nth 1 a) (+ (nth 3 b) tol))
      (> (nth 1 b) (+ (nth 3 a) tol))
    )
  )
)

(defun pcg-merge-box-list (boxes / xs1 ys1 xs2 ys2)
  (setq xs1 (mapcar 'car boxes))
  (setq ys1 (mapcar 'cadr boxes))
  (setq xs2 (mapcar '(lambda (b) (nth 2 b)) boxes))
  (setq ys2 (mapcar '(lambda (b) (nth 3 b)) boxes))
  (list (apply 'min xs1) (apply 'min ys1) (apply 'max xs2) (apply 'max ys2))
)

(defun pcg-line-box-components (boxes / remaining comps seed comp changed b rest)
  ;; LINE ���� ���� �׷��� �簢�� �������� �ϳ��� ���̵� �ڽ��� ���´�.
  (setq remaining boxes)
  (setq comps nil)
  (while remaining
    (setq seed (car remaining))
    (setq remaining (cdr remaining))
    (setq comp (list seed))
    (setq changed t)
    (while changed
      (setq changed nil)
      (setq rest nil)
      (foreach b remaining
        (if (vl-some '(lambda (c) (pcg-box-near-p b c 5.0)) comp)
          (progn
            (setq comp (cons b comp))
            (setq changed t)
          )
          (setq rest (cons b rest))
        )
      )
      (setq remaining rest)
    )
    (setq comps (cons (pcg-merge-box-list comp) comps))
  )
  comps
)

(defun pcg-opening-boxes-in-plan (plan-box op-objs / out line-boxes line-comps o b rel cx cy)
  (setq out nil)
  (setq line-boxes nil)
  (foreach o op-objs
    (setq b (nth 2 o))
    (if (pcg-box-inside-p b plan-box)
      (progn
        (if (= (car o) "LINE")
          (setq line-boxes (cons b line-boxes))
          (progn
            (setq rel (pcg-box-rel-to-plan b plan-box))
            (setq out (cons rel out))
          )
        )
      )
    )
  )
  (if line-boxes
    (progn
      (setq line-comps (pcg-line-box-components line-boxes))
      (foreach b line-comps
        (if (and (> (pcg-box-w b) 5.0) (> (pcg-box-h b) 5.0))
          (progn
            (setq rel (pcg-box-rel-to-plan b plan-box))
            (setq out (cons rel out))
          )
        )
      )
    )
  )
  out
)

(defun pcg-near-p (a b tol)
  (<= (abs (- a b)) tol)
)

(defun pcg-min-list (lst / m)
  (setq m nil)
  (foreach v lst
    (if (or (not m) (< v m)) (setq m v))
  )
  m
)

(defun pcg-max-list (lst / m)
  (setq m nil)
  (foreach v lst
    (if (or (not m) (> v m)) (setq m v))
  )
  m
)

(defun pcg-detect-corner-from-profile (pts girder-len girder-h / tol topXs botXs leftYs rightYs p x y minTop maxTop minBot maxBot minLeft maxLeft minRight maxRight A B C D ab ah bb bh cb ch db dh)
  ;; ��鵵 �ܰ� �������� ��ü�� ����/Ȩ ������ �� A/B/C/D�� ���� �����Ѵ�.
  ;; grid �� ���� ����� ���� �ۼ� ��Ŀ� ���� ��ġ�� ��찡 �־�, �ܰ��� ������ ���� ���� ������ �߰��Ѵ�.
  (setq tol 1.0)
  (setq topXs nil botXs nil leftYs nil rightYs nil)
  (foreach p pts
    (setq x (car p) y (cadr p))
    (if (pcg-near-p y girder-h tol) (setq topXs (cons x topXs)))
    (if (pcg-near-p y 0.0 tol) (setq botXs (cons x botXs)))
    (if (pcg-near-p x 0.0 tol) (setq leftYs (cons y leftYs)))
    (if (pcg-near-p x girder-len tol) (setq rightYs (cons y rightYs)))
  )

  (setq A (list 0 50 50) B (list 0 50 50) C (list 0 50 50) D (list 0 50 50))

  (setq minTop (pcg-min-list topXs))
  (setq maxTop (pcg-max-list topXs))
  (setq minBot (pcg-min-list botXs))
  (setq maxBot (pcg-max-list botXs))
  (setq minLeft (pcg-min-list leftYs))
  (setq maxLeft (pcg-max-list leftYs))
  (setq minRight (pcg-min-list rightYs))
  (setq maxRight (pcg-max-list rightYs))

  ;; A: �»��. ��ܼ��� x=0���� �������� �ʰ�, �������� �ְ������� �ö��� ������ Ȩ�� �ִٰ� �Ǵ�.
  (if (and minTop maxLeft (> minTop tol) (> (- girder-h maxLeft) tol))
    (progn
      (setq ab (fix (+ 0.5 minTop)))
      (setq ah (fix (+ 0.5 (- girder-h maxLeft))))
      (if (and (> ab 0) (> ah 0)) (setq A (list 1 ab ah)))
    )
  )

  ;; B: ����
  (if (and maxTop maxRight (> (- girder-len maxTop) tol) (> (- girder-h maxRight) tol))
    (progn
      (setq bb (fix (+ 0.5 (- girder-len maxTop))))
      (setq bh (fix (+ 0.5 (- girder-h maxRight))))
      (if (and (> bb 0) (> bh 0)) (setq B (list 1 bb bh)))
    )
  )

  ;; C: ���ϴ�
  (if (and minBot minLeft (> minBot tol) (> minLeft tol))
    (progn
      (setq cb (fix (+ 0.5 minBot)))
      (setq ch (fix (+ 0.5 minLeft)))
      (if (and (> cb 0) (> ch 0)) (setq C (list 1 cb ch)))
    )
  )

  ;; D: ���ϴ�
  (if (and maxBot minRight (> (- girder-len maxBot) tol) (> minRight tol))
    (progn
      (setq db (fix (+ 0.5 (- girder-len maxBot))))
      (setq dh (fix (+ 0.5 minRight)))
      (if (and (> db 0) (> dh 0)) (setq D (list 1 db dh)))
    )
  )

  (list A B C D)
)

(defun pcg-merge-corner-slots (primary fallback / out i a b)
  ;; primary�� ���̸� primary�� ����ϰ�, �� ���̴� ���Ը� fallback���� ä���.
  (setq out nil i 0)
  (while (< i 4)
    (setq a (nth i primary))
    (setq b (nth i fallback))
    (if (= (car a) 1)
      (setq out (append out (list a)))
      (setq out (append out (list b)))
    )
    (setq i (1+ i))
  )
  out
)

(defun pcg-detect-corner (boxes length height / A B C D b w h left right bot top key)
  (setq A (list 0 50 50) B (list 0 50 50) C (list 0 50 50) D (list 0 50 50))
  (foreach b boxes
    (setq w (fix (+ 0.5 (pcg-box-w b))) h (fix (+ 0.5 (pcg-box-h b))))
    (if (and (> w 0) (> h 0))
      (progn
        (setq left (<= (nth 0 b) 1.0) right (>= (nth 2 b) (- length 1.0)) bot (<= (nth 1 b) 1.0) top (>= (nth 3 b) (- height 1.0)))
        (cond
          ((and left top) (setq A (list 1 w h)))
          ((and right top) (setq B (list 1 w h)))
          ((and left bot) (setq C (list 1 w h)))
          ((and right bot) (setq D (list 1 w h)))
        )
      )
    )
  )
  (list A B C D)
)

(defun pcg-corner-cut-box-p (b length height / tol left right bot top)
  ;; A/B/C/D �ڳ� Ȩ�� �Ϲ� ���̵忡�� �����Ѵ�.
  (setq tol 1.0)
  (setq left (<= (nth 0 b) tol)
        right (>= (nth 2 b) (- length tol))
        bot (<= (nth 1 b) tol)
        top (>= (nth 3 b) (- height tol)))
  (or (and left top) (and right top) (and left bot) (and right bot))
)

(defun pcg-detect-void1 (boxes length height / candidates b)
  ;; �Ŵ� ���̵� ���� ����
  ;; 1) �Ŵ��� ��ü ���簢������ ���� �� A/B/C/D �ڳ� Ȩ�� �����ϰ� �Ŀ� �ִ� Ȩ
  ;; 2) ������ ������ ���̾�/�������� �� �簢�� ������ �Ǵ� ���� �����갡 �Ŵ� ���ο� �ִ� ���
  ;; boxes���� �ܰ��� �� ����, ������ ���̾� ��ü, ���� ���� �������� �ĺ��� ��� ���´�.
  (setq candidates nil)
  (foreach b boxes
    (if (and
          (> (pcg-box-w b) 5.0)
          (> (pcg-box-h b) 5.0)
          (not (pcg-corner-cut-box-p b length height))
          ;; ������ �ܺη� �������� �ڽ� ����
          (>= (nth 0 b) -1.0)
          (>= (nth 1 b) -1.0)
          (<= (nth 2 b) (+ length 1.0))
          (<= (nth 3 b) (+ height 1.0))
        )
      (setq candidates (cons b candidates))
    )
  )
  ;; ���� �켱, ���� X�̸� ���� �켱
  (setq candidates
    (vl-sort candidates
      '(lambda (a b)
        (if (= (nth 0 a) (nth 0 b))
          (> (nth 3 a) (nth 3 b))
          (< (nth 0 a) (nth 0 b))
        )
      )
    )
  )
  (if candidates
    (progn
      (setq b (car candidates))
      ;; X/Y�� ���� ��� ����: X = ���� �Ÿ�, Y = ��ܿ��� ������ �Ÿ�
      (list
        1
        (fix (+ 0.5 (max 0.0 (nth 0 b))))
        (fix (+ 0.5 (max 0.0 (- height (nth 3 b)))))
        (fix (+ 0.5 (pcg-box-w b)))
        (fix (+ 0.5 (pcg-box-h b)))
      )
    )
    (list 0 50 50 50 50)
  )
)

(defun pcg-detect-ledges (pts length height / inside-cells A B C D c x1 x2 y1 y2 w h side vertical key len sideStepL sideStepR step)
  ;; �����(ledge) ������ ���� ��ũ��Ʈ�� ������ ���� �����Ѵ�.
  ;; ���� ���� ���� ����(sideStep)�� ���� ã��, ��/�ϴ� ���� ���� ���� ���̿��� �� ���� ���� ���ش�.
  (setq A (list 0 50) B (list 0 50) C (list 0 50) D (list 0 50))
  (setq sideStepL 0.0 sideStepR 0.0)
  (setq inside-cells (pcg-grid-cells pts length height t))

  ;; �¿� ������ ���� ���� ���� �� ���
  (foreach c inside-cells
    (setq x1 (nth 2 c) x2 (nth 3 c) y1 (nth 4 c) y2 (nth 5 c))
    (setq w (- x2 x1) h (- y2 y1))
    (if (and (> h 120.0) (<= w 120.0))
      (progn
        (if (<= x1 120.0) (setq sideStepL (max sideStepL w)))
        (if (>= x2 (- length 120.0)) (setq sideStepR (max sideStepR w)))
      )
    )
  )

  ;; ��/�ϴ� ���� ���� ����� ����
  (foreach c inside-cells
    (setq x1 (nth 2 c) x2 (nth 3 c) y1 (nth 4 c) y2 (nth 5 c))
    (setq w (- x2 x1) h (- y2 y1))
    (if (and (>= h 45.0) (<= h 85.0) (> w h) (<= w (min 1000.0 (* length 0.3))))
      (progn
        (setq side (cond ((<= x1 1.0) "L") ((>= x2 (- length 1.0)) "R") (t nil)))
        (setq vertical (cond ((<= y1 90.0) "B") ((>= y2 (- height 90.0)) "T") (t nil)))
        (if (and side vertical)
          (progn
            (setq key
              (cond
                ((and (= side "L") (= vertical "T")) "A")
                ((and (= side "R") (= vertical "T")) "B")
                ((and (= side "L") (= vertical "B")) "C")
                (t "D")
              )
            )
            (setq step (if (= side "L") sideStepL sideStepR))
            (setq len (fix (+ 0.5 (- w step))))
            (if (<= len 0) (setq len (fix (+ 0.5 w))))
            (cond
              ((= key "A") (if (or (= (car A) 0) (> len (cadr A))) (setq A (list 1 len))))
              ((= key "B") (if (or (= (car B) 0) (> len (cadr B))) (setq B (list 1 len))))
              ((= key "C") (if (or (= (car C) 0) (> len (cadr C))) (setq C (list 1 len))))
              ((= key "D") (if (or (= (car D) 0) (> len (cadr D))) (setq D (list 1 len))))
            )
          )
        )
      )
    )
  )
  (list A B C D)
)

(defun pcg-visible-any-p (slots / res)
  (setq res nil)
  (foreach s slots (if (= (car s) 1) (setq res t)))
  res
)

(defun pcg-row-to-values (row has-corner has-void has-ledge / vals corner void ledge)
  (setq vals (list (nth 0 row) (nth 1 row) (nth 2 row) (nth 3 row) (nth 4 row)))
  (setq corner (nth 5 row) void (nth 6 row) ledge (nth 7 row))
  (if has-corner
    (setq vals
      (append vals
        (list
          (car (nth 0 corner)) (car (nth 1 corner)) (car (nth 2 corner)) (car (nth 3 corner))
          (cadr (nth 0 corner)) (caddr (nth 0 corner))
          (cadr (nth 1 corner)) (caddr (nth 1 corner))
          (cadr (nth 2 corner)) (caddr (nth 2 corner))
          (cadr (nth 3 corner)) (caddr (nth 3 corner))
        )
      )
    )
  )
  (if has-void
    (setq vals (append vals void))
  )
  (if has-ledge
    (setq vals
      (append vals
        (list
          (car (nth 0 ledge)) (car (nth 1 ledge)) (car (nth 2 ledge)) (car (nth 3 ledge))
          (cadr (nth 0 ledge)) (cadr (nth 1 ledge)) (cadr (nth 2 ledge)) (cadr (nth 3 ledge))
        )
      )
    )
  )
  vals
)

(defun pcg-write-girder-csv (path rows has-corner has-void has-ledge / f headers)
  (setq headers (list "" "LOT##NUMBER##GENERAL" "L##length##millimeters" "H##length##millimeters" "B##length##millimeters"))
  (if has-corner
    (setq headers
      (append headers
        (list
          "A_visible##length##millimeters" "B_visible##length##millimeters" "C_visible##length##millimeters" "D_visible##length##millimeters"
          "A_b##length##millimeters" "A_h##length##millimeters" "B_b##length##millimeters" "B_h##length##millimeters"
          "C_b##length##millimeters" "C_h##length##millimeters" "D_b##length##millimeters" "D_h##length##millimeters"
        )
      )
    )
  )
  (if has-void
    (setq headers
      (append headers
        (list "void1_visible##length##millimeters" "void1_x##length##millimeters" "void1_y##length##millimeters" "void1_w##length##millimeters" "void1_h##length##millimeters")
      )
    )
  )
  (if has-ledge
    (setq headers
      (append headers
        (list
          "ledge_A_visible##length##millimeters" "ledge_B_visible##length##millimeters" "ledge_C_visible##length##millimeters" "ledge_D_visible##length##millimeters"
          "ledge_A_length##length##millimeters" "ledge_B_length##length##millimeters" "ledge_C_length##length##millimeters" "ledge_D_length##length##millimeters"
        )
      )
    )
  )
  (setq f (open path "w"))
  (write-line (pcg-join headers ",") f)
  (foreach r rows
    (write-line (pcg-join (pcg-row-to-values r has-corner has-void has-ledge) ",") f)
  )
  (close f)
)

(defun Compile_Girder_PureLisp_To_Csv (out / frames texts con-objs op-objs closed-objs rows has-corner has-void has-ledge idx total frame frame-box candidates ps plan side plan-box side-box plan-pts norm-pts length height width lot empty-cells boxes corner corner-grid corner-prof void1 ledge err status)
  (Load_Mode_Config "GIRDER")
  (setq frames (pcg-frame-nodes))
  (setq texts (pcg-collect-texts))
  (setq con-objs (pcg-collect-con-polys))
  (setq op-objs (pcg-collect-op-objects))
  (setq closed-objs (pcg-collect-all-closed-polys))
  (setq rows nil has-corner nil has-void nil has-ledge nil idx 1 total (pcg-list-length frames))
  (foreach frame frames
    (setq frame-box (cadr frame))
    (princ (strcat "\n[���� ��Ȳ] " (itoa idx) " / " (itoa total) " �Ŵ� ���� ���� ��..."))
    (setq lot (pcg-lot-from-frame frame-box (caddr frame) texts))
    (setq candidates (pcg-candidates-in-frame frame-box con-objs))
    (setq ps (pcg-pick-plan-side frame-box candidates))
    (setq plan (car ps) side (cadr ps))
    (setq status "����" err "")
    (if (not (Is_Lot_Number_Format lot)) (setq status "����" err "��Ʈ��ȣ ���� ����"))
    (if (not plan)
      (progn
        (setq status "����" err (if (= err "") "�Ŵ� ��ũ��Ʈ �̰���" (strcat err ", �Ŵ� ��ũ��Ʈ �̰���")))
        (setq length 0 height 0 width 0 corner (list (list 0 50 50) (list 0 50 50) (list 0 50 50) (list 0 50 50)) void1 (list 0 50 50 50 50) ledge (list (list 0 50) (list 0 50) (list 0 50) (list 0 50)))
      )
      (progn
        (setq plan-box (nth 2 plan))
        (setq plan-pts (nth 1 plan))
        (setq length (fix (+ 0.5 (pcg-box-w plan-box))))
        (setq height (fix (+ 0.5 (pcg-box-h plan-box))))
        (if side
          (progn
            (setq side-box (nth 2 side))
            (setq width (fix (+ 0.5 (min (pcg-box-w side-box) (pcg-box-h side-box)))))
          )
          (setq width 0)
        )
        (setq norm-pts (pcg-normalize-pts plan-pts))
        (setq boxes nil)
        (if (and norm-pts (> length 0) (> height 0))
          (progn
            (setq empty-cells (pcg-grid-cells norm-pts length height nil))
            (foreach comp (pcg-components empty-cells)
              (setq boxes (cons (pcg-cells-bounds comp) boxes))
            )
            ;; ���̵� ���� 1: �Ŵ��� ���簢������ ���� �� A/B/C/D�� �����ϰ� �Ŀ� �ִ� Ȩ
            ;; ���̵� ���� 2: ������ ������ ���̾�/������ �簢�� ������ �Ǵ� ���� ������
            ;; ���̵� ���� 2: ����ڰ� ������ ������ ���̾�/������ �簢�� ������ �Ǵ� ���� ������
            (setq boxes (append boxes (pcg-opening-boxes-in-plan plan-box op-objs)))
            ;; A/B/C/D�� grid ��� ���� + �ܰ��� ������ ���� ������ �����Ѵ�.
            (setq corner-grid (pcg-detect-corner boxes length height))
            (setq corner-prof (pcg-detect-corner-from-profile norm-pts length height))
            (setq corner (pcg-merge-corner-slots corner-prof corner-grid))
            (setq void1 (pcg-detect-void1 boxes length height))
            (setq ledge (pcg-detect-ledges norm-pts length height))
          )
          (progn
            (setq corner (list (list 0 50 50) (list 0 50 50) (list 0 50 50) (list 0 50 50)))
            (setq void1 (list 0 50 50 50 50))
            (setq ledge (list (list 0 50) (list 0 50) (list 0 50) (list 0 50)))
          )
        )
      )
    )
    (if (pcg-visible-any-p corner) (setq has-corner t))
    (if (= (car void1) 1) (setq has-void t))
    (if (pcg-visible-any-p ledge) (setq has-ledge t))
    (setq rows (append rows (list (list lot (pcg-clean-lot-lsp lot) length width height corner void1 ledge status err))))
    (setq idx (1+ idx))
  )
  (pcg-write-girder-csv out rows has-corner has-void has-ledge)
  out
)

(defun Run_Girder_Process (open-excel / out)
  (Load_Mode_Config "GIRDER")
  (cond
    ((or (not (boundp 'g_girder_frame_handle)) (= g_girder_frame_handle "") (not (handent g_girder_frame_handle)))
      (alert "[����] ������ �������� �ʾҽ��ϴ�.\n���� â���� [���� Ŭ��..]�� ���� �����ϼ���.")
    )
    ((or (not g_con_list) (= (pcg-list-length g_con_list) 0))
      (alert "[����] �Ŵ� ��ũ��Ʈ ���̾ �������� �ʾҽ��ϴ�.\n[����(�Ŵ�)]���� ��ũ��Ʈ ���̾� ����� �߰��ϼ���.")
    )
    (t
      (setq out (strcat (getenv "TEMP") "\\PC_Girder_PureLisp.csv"))
      (if (findfile out) (vl-file-delete out))
      (Compile_Girder_PureLisp_To_Csv out)
      (if (findfile out)
        (progn
          (setq g_girder_csv_path out)
          (Load_Girder_Summary_From_Csv out)
          (if open-excel
            (progn
              (pcg-open-excel out)
              (if (findfile out) (vl-file-delete out))
              (setq g_girder_csv_path "")
              (alert "�Ŵ� ���� ������ �Ϸ�Ǿ����ϴ�.")
              (princ "\n[�˸�] �Ŵ� ���� ������ �Ϸ�Ǿ����ϴ�.")
            )
            (progn
              (alert "�Ŵ� ���� ���� ���谡 �Ϸ�Ǿ����ϴ�.")
              (princ "\n[�˸�] �Ŵ� ���� ���� ���谡 �Ϸ�Ǿ����ϴ�.")
            )
          )
        )
        (alert "[����] �Ŵ� CSV ������ �����߽��ϴ�.")
      )
    )
  )
)

(defun Run_Girder_Summary_From_PCC ()
  (Run_Girder_Process nil)
)

(defun Export_Girder_To_Excel_From_PCC ()
  (if (and (boundp 'g_girder_csv_path) g_girder_csv_path (/= g_girder_csv_path "") (findfile g_girder_csv_path))
    (progn
      (princ "\n[���� ��Ȳ] �Ŵ� ���� â �ۼ� ��...")
      (pcg-open-excel g_girder_csv_path)
      (if (findfile g_girder_csv_path) (vl-file-delete g_girder_csv_path))
      (setq g_girder_csv_path "")
      (alert "�Ŵ� ���� ������ �Ϸ�Ǿ����ϴ�.")
      (princ "\n[�˸�] �Ŵ� ���� ������ �Ϸ�Ǿ����ϴ�.")
    )
    (alert "[����] ���� [���� ���� ����]�� �����ϼ���.")
  )
)

(defun Run_PCG_From_PCC ()
  (Run_Girder_Summary_From_PCC)
)
(defun Get_Entity_Bounds_MinPoint (ent / obj minpt maxpt mn ed p res)
  (vl-load-com)
  (setq res
    (vl-catch-all-apply
      '(lambda ()
        (setq obj (vlax-ename->vla-object ent))
        (vla-getboundingbox obj 'minpt 'maxpt)
        (setq mn (vlax-safearray->list minpt))
        (list (car mn) (cadr mn) 0.0)
      )
    )
  )
  (if (vl-catch-all-error-p res)
    (progn
      (setq ed (entget ent))
      (setq p (cdr (assoc 10 ed)))
      (if p p (list 0.0 0.0 0.0))
    )
    res
  )
)
(defun c:PCC ( / dcl-id dcl-status ent tmp-file f loop-flag cur-lay 
                     p1 p2 pts sample-ss sample-dxf sample-ent sample-name summary-item
                     total_dwg_cnt normal_member_cnt error_member_cnt name-part op-cnt-part slv-cnt-part m16-cnt-part check-part err-reason-part
                     name-len pad-len1 pad-str1 op-str slv-str op-len pad-len-op pad-str-op slv-len pad-len-slv pad-str-slv check-str check-len pad-len4 pad-str4
                     idx old-osmode old-err current-mode)
  
  (setq old-osmode (getvar "OSMODE"))
  (setq old-err *error* *error* PC_OP_ERR)

  (Load_Global_Settings)
  (setq g_summary_data nil)

  (setq tmp-file (strcat (getvar "ROAMABLEROOTPREFIX") "Support\\pc_op_tmp.dcl"))
  (setq f (open tmp-file "w"))
  
  (write-line "pc_op_main : dialog { label = \"PC ���� ������/������/M16 ����_DG\";" f)
  (write-line "  : column {" f)
  (write-line "    : row {" f)
  (write-line "      : boxed_column { label = \"���� ���\"; width = 85; children_alignment = top;" f)
  (write-line "        : list_box { key = \"list_summary\"; height = 30; width = 83; }" f)
  (write-line "      }" f)
  (write-line "      : column { width = 58;" f)
  (write-line "        : boxed_row { label = \"���� ��� ���� ����\";" f)
  (write-line "          : text { key = \"lbl_txt_dwg\"; width = 20; value = \"\"; is_bold = true; }" f)
  (write-line "          : button { label = \"���� Ŭ��..\"; key = \"btn_pick_dwg\"; width = 12; }" f)
  (write-line "        }" f)
  (write-line "        : boxed_row { label = \"��Ʈ��ȣ ��ġ ����\";" f)
  (write-line "          : text { key = \"lbl_txt_status\"; width = 20; value = \"��ġ ������\"; is_bold = true; }" f)
  (write-line "          : button { label = \"���� ����..\"; key = \"btn_pick_txt\"; width = 12; }" f)
  (write-line "        }" f)
  (write-line "        : boxed_column { label = \"�۾� ��� ����\";" f)
  (write-line "          : radio_row { key = \"rad_mode\";" f)
  (write-line "            : radio_button { key = \"opt_slab\"; label = \"������ / �ָ����\"; }" f)
  (write-line "            : radio_button { key = \"opt_double\"; label = \"������\"; }" f)
  (write-line "            : radio_button { key = \"opt_girder\"; label = \"�Ŵ�\"; }" f)
  (write-line "          }" f)
  (write-line "          : row {" f)
  (write-line "            : button { label = \"����(������ / �ָ����)\"; key = \"btn_set_slab\"; }" f)
  (write-line "            : button { label = \"����(������)\"; key = \"btn_set_double\"; }" f)
  (write-line "            : button { label = \"����(�Ŵ�)\"; key = \"btn_set_girder\"; }" f)
  (write-line "          }" f)
  (write-line "        }" f)
  (write-line "        : spacer { height = 1; }" f)
  (write-line "        : button { label = \"���� ���� ����\"; key = \"btn_run_summary\"; height = 1.6; is_bold = true; }" f)
  (write-line "        : button { label = \"���� â���� ��������\"; key = \"accept\"; height = 1.8; is_bold = true; is_default = true; }" f)
  (write-line "        : button { label = \"�� ��\"; key = \"cancel\"; height = 1.3; is_cancel = true; }" f)
  (write-line "      }" f)
  (write-line "    }" f)
  (write-line "    : boxed_row { label = \"���\"; " f)
  (write-line "      : text { key = \"lbl_total_dwg\"; title = \"�հ� : 0 ��\"; width = 22; is_bold = true; }" f)
  (write-line "      : spacer { width = 3; }" f)
  (write-line "      : text { key = \"lbl_has_op\"; title = \"���� : 0 ��\"; width = 28; is_bold = true; }" f)
  (write-line "      : spacer { width = 3; }" f)
  (write-line "      : text { key = \"lbl_no_op\"; title = \"���� : 0 ��\"; width = 28; is_bold = true; }" f)
  (write-line "    }" f)
  (write-line "  }" f)
  (write-line "}" f)
  (close f)

  (setq loop-flag t)
  (while loop-flag
    (setq dcl-id (load_dialog tmp-file))
    (if (not (new_dialog "pc_op_main" dcl-id)) (setq loop-flag nil))
    
    (set_tile "lbl_txt_dwg" g_sample_name)
    (set_tile "lbl_txt_status" (if (/= g_x1_off 0.0) "���� ����" "��ġ ������"))
    
    (cond ((= g_active_mode "SLAB") (set_tile "opt_slab" "1")) ((= g_active_mode "DOUBLE") (set_tile "opt_double" "1")) ((= g_active_mode "GIRDER") (set_tile "opt_girder" "1")) (t (set_tile "opt_slab" "1")))

    (start_list "list_summary")
    (add_list "  [ ��Ʈ��ȣ ]                [ ������ ]   [ ������ ]     [ ���� ]    [ ���� ���� ]")
    (add_list "-----------------------------------------------------------------------------------------")
    
    (setq total_dwg_cnt 0 normal_member_cnt 0 error_member_cnt 0)
    (if g_summary_data
      (progn
        (setq total_dwg_cnt (pcg-list-length g_summary_data))
        (foreach item g_summary_data 
          (setq name-part (nth 0 item) op-cnt-part (nth 1 item) slv-cnt-part (nth 2 item) m16-cnt-part (nth 3 item) check-part (nth 4 item) err-reason-part (nth 8 item))
          (if (= check-part "����") (setq error_member_cnt (1+ error_member_cnt)) (setq normal_member_cnt (1+ normal_member_cnt)))
          
          (setq name-len (strlen name-part))
          (setq pad-len1 (- 26 name-len)) (if (< pad-len1 1) (setq pad-len1 1))
          (setq pad-str1 "") (repeat pad-len1 (setq pad-str1 (strcat pad-str1 " ")))
          
          (setq op-str (strcat op-cnt-part " ��")) (setq op-len (strlen op-str))
          (setq pad-len-op (- 12 op-len)) (if (< pad-len-op 1) (setq pad-len-op 1))
          (setq pad-str-op "") (repeat pad-len-op (setq pad-str-op (strcat pad-str-op " ")))

          (setq slv-str (strcat slv-cnt-part " ��")) (setq slv-len (strlen slv-str))
          (setq pad-len-slv (- 14 slv-len)) (if (< pad-len-slv 1) (setq pad-len-slv 1))
          (setq pad-str-slv "") (repeat pad-len-slv (setq pad-str-slv (strcat pad-str-slv " ")))

          (setq check-str check-part) (setq check-len (strlen check-str))
          (setq pad-len4 (- 12 check-len)) (if (< pad-len4 1) (setq pad-len4 1))
          (setq pad-str4 "") (repeat pad-len4 (setq pad-str4 (strcat pad-str4 " ")))

          (add_list (strcat "  " name-part pad-str1 "  " op-str pad-str-op slv-str pad-str-slv check-str pad-str4 err-reason-part))
        )
      )
    )
    (end_list)
    
    (set_tile "lbl_total_dwg" (strcat "�հ� : " (itoa total_dwg_cnt) " ��"))
    (set_tile "lbl_has_op" (strcat "���� : " (itoa normal_member_cnt) " ��"))
    (set_tile "lbl_no_op" (strcat "���� : " (itoa error_member_cnt) " ��"))

    (action_tile "rad_mode" "(setq g_active_mode (cond ((= $value \"opt_slab\") \"SLAB\") ((= $value \"opt_double\") \"DOUBLE\") ((= $value \"opt_girder\") \"GIRDER\") (t \"SLAB\"))) (Save_Global_Settings) (done_dialog 55)")

    (action_tile "btn_pick_dwg" "(done_dialog 2)") (action_tile "btn_pick_txt" "(done_dialog 6)")
    (action_tile "btn_set_slab" "(done_dialog 10)") (action_tile "btn_set_double" "(done_dialog 11)") (action_tile "btn_set_girder" "(done_dialog 12)")
    
    (action_tile "btn_run_summary" "(if (= g_active_mode \"GIRDER\") (done_dialog 80) (done_dialog 8))") (action_tile "accept" "(if (= g_active_mode \"GIRDER\") (done_dialog 81) (done_dialog 1))") (action_tile "cancel" "(done_dialog 0)")
    
    (setq dcl-status (start_dialog))
    (unload_dialog dcl-id)
    
    (cond
      ((= dcl-status 0) (setq loop-flag nil))
      ((= dcl-status 55) (setq loop-flag t)) 
      ((= dcl-status 1) (if (not g_summary_data) (progn (alert "����� �����Ͱ� �����ϴ�.") (setq loop-flag t)) (setq loop-flag nil)))
      ((= dcl-status 2)
        (if (= g_active_mode "GIRDER")
          (progn
            (setq ent (car (entsel "\n���� ��ü�� �����ϼ���: ")))
            (if ent
              (progn
                (setq sample-dxf (entget ent))
                (setq g_girder_frame_handle (cdr (assoc 5 sample-dxf)))
                (if (= (cdr (assoc 0 sample-dxf)) "INSERT")
                  (setq g_dwg_bl (cdr (assoc 10 sample-dxf)))
                  (setq g_dwg_bl (Get_Entity_Bounds_MinPoint ent))
                )
                (setq g_girder_frame_label (strcat "����: " g_girder_frame_handle))
                (setq g_sample_name g_girder_frame_label)
                (Save_Global_Settings)
              )
            )
          )
          (progn
            (setq sample-ent (car (entsel "\n���� ��ü�� �����ϼ���: ")))
            (if sample-ent
              (progn
                (setq sample-dxf (entget sample-ent))
                (if (= (cdr (assoc 0 sample-dxf)) "INSERT")
                  (progn
                    (setq g_sample_name (cdr (assoc 2 sample-dxf)))
                    (setq g_dwg_bl (cdr (assoc 10 sample-dxf)))
                  )
                  (progn
                    (setq g_sample_name (strcat "������ü:" (cdr (assoc 5 sample-dxf))))
                    (setq g_dwg_bl (Get_Entity_Bounds_MinPoint sample-ent))
                  )
                )
                (Save_Global_Settings)
              )
            )
          )
        )
      )
      ((= dcl-status 6)
        (if (or (not g_dwg_bl) (= g_sample_name "���õ��� ����"))
          (alert "���� ������ ���� Ŭ���� �ּ���.")
          (progn
            (setq p1 (getpoint "\n��Ʈ��ȣ ������ ù ��° ���� ����: "))
            (if p1
              (progn
                (setq p2 (getcorner p1 "\n�ݴ��� ���� ����: "))
                (if p2
                  (progn
                    (setq g_x1_off (- (min (car p1) (car p2)) (car g_dwg_bl))
                          g_y1_off (- (min (cadr p1) (cadr p2)) (cadr g_dwg_bl))
                          g_x2_off (- (max (car p1) (car p2)) (car g_dwg_bl))
                          g_y2_off (- (max (cadr p1) (cadr p2)) (cadr g_dwg_bl)))
                    (Save_Global_Settings)
                  )
                )
              )
            )
          )
        )
      )
      ((= dcl-status 10) (Run_Settings_Dialog "SLAB"))
      ((= dcl-status 11) (Run_Settings_Dialog "DOUBLE"))
      ((= dcl-status 12) (Run_Girder_Settings_Dialog))
      ((= dcl-status 80) (Run_Girder_Summary_From_PCC) (setq loop-flag t))
      ((= dcl-status 81) (Export_Girder_To_Excel_From_PCC) (setq loop-flag t))
      ((= dcl-status 8)
        (if (or (= g_sample_name "���õ��� ����") (= g_x1_off 0.0))
          (alert "���� �� �ؽ�Ʈ ���� ������ �Ϸ��� �ּ���.")
          (progn
            (Load_Mode_Config g_active_mode)
            (setvar "OSMODE" 0) 
            (setq g_summary_data (Compile_Drawings_PureDxf g_sample_name g_op_list))
            (setvar "OSMODE" old-osmode) 
          )
        )
      )
    )
  )
  (vl-file-delete tmp-file)
  
  (if (= dcl-status 1)
    (progn
      (Load_Mode_Config g_active_mode)
      (Export_Data_To_Live_Excel g_summary_data 
        (list g_hdr_op_pref g_hdr_w g_hdr_h g_hdr_x g_hdr_y 
              g_hdr_slv_pref g_hdr_dia g_hdr_sx g_hdr_sy 
              g_hdr_con_pref g_hdr_con_w g_hdr_con_h
              g_hdr_sep g_hdr_suffix g_hdr_op_ox g_hdr_slv_ox g_hdr_lot_nm g_hdr_blank
              g_hdr_m16_pref g_hdr_m16_ox g_hdr_m16_x g_hdr_m16_y g_hdr_out_prefix g_hdr_in_prefix) g_tg_m16 g_active_mode)
      (alert "���� ������ �Ϸ�Ǿ����ϴ�.")
      (princ "\n[�˸�] ���� ������ �Ϸ�Ǿ����ϴ�.")
    )
  )
  
  (setvar "OSMODE" old-osmode)
  (setq *error* old-err)
  (princ)
)

(defun In_Box_P (pt x1 y1 x2 y2)
  (and (>= (car pt) x1) (<= (car pt) x2) (>= (cadr pt) y1) (<= (cadr pt) y2))
)

;; ���̾� �� ����(Color) ���� ��ĵ ��Ī ���� (SLAB�� ���� ����)
(defun Check_Layer_Color_Match (ent lay_col_list check_color / ed lay col match item target_lay target_col pos)
  (setq ed (entget ent) lay (cdr (assoc 8 ed)) col (cdr (assoc 62 ed)) match nil)
  (if (not col) (setq col 256))
  (foreach item lay_col_list
    (if (setq pos (vl-string-search ":" item))
      (progn
        (setq target_lay (substr item 1 pos))
        (setq target_col (atoi (substr item (+ pos 2))))
      )
      (progn
        (setq target_lay item)
        (setq target_col 256)
      )
    )
    (if (= (strcase lay) (strcase target_lay))
      (if (and check_color pos)
        (if (= col target_col) (setq match t))
        (setq match t)
      )
    )
  )
  match
)

(defun Count_Openings_In_Box (box op-objs / cnt o typ pts x1 y1 x2 y2 cen cx cy)
  (setq cnt 0)
  (foreach o op-objs
    (setq typ (car o) cx nil cy nil)
    (cond
      ((= typ "RECT")
       (setq pts (cadr o))
       (if pts
         (progn
           (setq x1 (apply 'min (mapcar 'car pts))
                 y1 (apply 'min (mapcar 'cadr pts))
                 x2 (apply 'max (mapcar 'car pts))
                 y2 (apply 'max (mapcar 'cadr pts)))
           (setq cx (/ (+ x1 x2) 2.0) cy (/ (+ y1 y2) 2.0))
         )
       )
      )
      ((= typ "CIRCLE")
       (setq cen (cadr o))
       (if cen (setq cx (car cen) cy (cadr cen)))
      )
    )
    (if (and cx cy (In_Box_P (list cx cy) (nth 0 box) (nth 1 box) (nth 2 box) (nth 3 box)))
      (setq cnt (1+ cnt))
    )
  )
  cnt
)
(defun GetBlockBoundsOffsets (blkName / ent ed minX minY maxX maxY px py typ)
  (setq ent (tblobjname "BLOCK" blkName)
        minX 1e99 minY 1e99 maxX -1e99 maxY -1e99)
  (while (setq ent (entnext ent))
    (setq ed (entget ent) typ (cdr (assoc 0 ed)))
    (cond
      ((= typ "LINE")
       (setq px (car (cdr (assoc 10 ed))) py (cadr (cdr (assoc 10 ed))))
       (setq minX (min minX px) minY (min minY py) maxX (max maxX px) maxY (max maxY py))
       (setq px (car (cdr (assoc 11 ed))) py (cadr (cdr (assoc 11 ed))))
       (setq minX (min minX px) minY (min minY py) maxX (max maxX px) maxY (max maxY py))
      )
      ((= typ "LWPOLYLINE")
       (foreach itm ed
         (if (= (car itm) 10)
           (progn
             (setq px (cadr itm) py (caddr itm))
             (setq minX (min minX px) minY (min minY py) maxX (max maxX px) maxY (max maxY py))
           )
         )
       )
      )
    )
  )
  (if (= minX 1e99) (setq minX 0.0 minY 0.0 maxX 841.0 maxY 594.0))
  (list minX minY maxX maxY)
)

;; ���� ���� ����
(defun Compile_Drawings_PureDxf (target-block-name op-list-lay /
                                 master-ss total-cnt k dwg-ent dxf-data dwg-bl
                                 sorted-list dwg-info-list tolerance pts 
                                 d-x1 d-y1 d-x2 d-y2 compiled-res offsets
                                 min-tx max-tx min-ty max-ty txt-str found-61
                                 all-texts all-op-objects all-con-objects all-m16-objects current-idx m-node m-vis
                                 c-minx c-miny c-maxx c-maxy cx cy has-con con-tl err-reason
                                 con-w con-h temp-ops temp-slvs temp-m16s final-ops final-slvs final-op-details final-slv-details final-m16-details
                                 has-out-con has-in-con out-c-minx out-c-miny out-c-maxx out-c-maxy out-con-tl out-con-w out-con-h
                                 in-c-minx in-c-miny in-c-maxx in-c-maxy in-con-tl in-con-w in-con-h x_over_limit_error w_over_limit_error best-out-box best-in-box best-slab-box best-out-area best-in-area best-slab-area barea wall-candidates)
  
  (setq master-ss (ssget "X" (list '(0 . "INSERT") (cons 2 target-block-name))))
  (if (or (not master-ss) (= (sslength master-ss) 0)) (progn (alert "���� ������ ã�� �� �����ϴ�.") (exit)))
  (setq total-cnt (sslength master-ss))

  (setq offsets (GetBlockBoundsOffsets target-block-name))

  (setq dwg-info-list nil k 0)
  (repeat total-cnt
    (setq dwg-ent (ssname master-ss k))
    (setq dxf-data (entget dwg-ent))
    (setq dwg-bl (cdr (assoc 10 dxf-data)))
    
    (setq x-scale (cdr (assoc 41 dxf-data)))
    (setq y-scale (cdr (assoc 42 dxf-data)))
    (if (not x-scale) (setq x-scale 1.0))
    (if (not y-scale) (setq y-scale 1.0))
    
    (setq d-x1 (+ (car dwg-bl) (* (nth 0 offsets) (abs x-scale))) 
          d-y1 (+ (cadr dwg-bl) (* (nth 1 offsets) (abs y-scale)))
          d-x2 (+ (car dwg-bl) (* (nth 2 offsets) (abs x-scale))) 
          d-y2 (+ (cadr dwg-bl) (* (nth 3 offsets) (abs y-scale))))

    (setq dwg-info-list (cons (list dwg-ent dwg-bl (list (min d-x1 d-x2) (min d-y1 d-y2) (max d-x1 d-x2) (max d-y1 d-y2)) x-scale y-scale) dwg-info-list))
    (setq k (1+ k))
  )

  (setq tolerance 1000.0) 
  (setq sorted-list (vl-sort dwg-info-list 
    '(lambda (a b)
       (setq a-y (cadddr (nth 2 a)) b-y (cadddr (nth 2 b))) 
       (setq a-x (car (nth 2 a)) b-x (car (nth 2 b)))       
       (if (< (abs (- a-y b-y)) tolerance) (< a-x b-x) (> a-y b-y))
    )
  ))

  (setq all-texts nil all-op-objects nil all-con-objects nil all-m16-objects nil)
  
  (setq ent-txt (ssget "X" '((0 . "TEXT,MTEXT"))))
  (if ent-txt
    (progn (setq m 0)
      (repeat (sslength ent-txt)
        (setq dxf (entget (ssname ent-txt m)) typ (cdr (assoc 0 dxf)) txt (cdr (assoc 1 dxf)) txt-height (if (cdr (assoc 40 dxf)) (cdr (assoc 40 dxf)) 0.0))
        (if (= typ "TEXT")
          (if (and (= (cdr (assoc 72 dxf)) 0) (= (cdr (assoc 73 dxf)) 0))
            (setq pt (cdr (assoc 10 dxf)))
            (setq pt (cdr (assoc 11 dxf))) 
          )
          (setq pt (cdr (assoc 10 dxf)))
        )
        (setq all-texts (cons (list pt txt txt-height) all-texts))
        (setq m (1+ m))
      )
    )
  )

  (setq ent-op (ssget "X" '((0 . "LWPOLYLINE,CIRCLE"))))
  (if ent-op
    (progn (setq m 0)
      (repeat (sslength ent-op)
        (setq dxf (entget (ssname ent-op m)) typ (cdr (assoc 0 dxf)))
        (if (Check_Layer_Color_Match (ssname ent-op m) op-list-lay t)
          (cond
            ((= typ "LWPOLYLINE") 
             (setq pts (mapcar 'cdr (vl-remove-if-not '(lambda (x) (= (car x) 10)) dxf)))
             (if (and pts (> (pcg-list-length pts) 2)) (setq all-op-objects (cons (list "RECT" pts (ssname ent-op m)) all-op-objects)))
            )
            ((= typ "CIRCLE") 
             (setq all-op-objects (cons (list "CIRCLE" (cdr (assoc 10 dxf)) (cdr (assoc 40 dxf)) (ssname ent-op m)) all-op-objects))
            )
          )
        )
        (setq m (1+ m))
      )
    )
  )

  ;; ��ũ��Ʈ �������� ����(�ٰ���)�� ��ĵ�ϵ��� �Ϻ� �и� ����
  (setq ent-con (ssget "X" '((0 . "LWPOLYLINE"))))
  (if ent-con
    (progn (setq m 0)
      (repeat (sslength ent-con)
        (setq b-ent (ssname ent-con m) dxf (entget b-ent) typ (cdr (assoc 0 dxf)))
        (setq pts (mapcar 'cdr (vl-remove-if-not '(lambda (x) (= (car x) 10)) dxf)))
        (if (and pts (> (pcg-list-length pts) 2))
          (setq all-con-objects (cons (list b-ent pts) all-con-objects))
        )
        (setq m (1+ m))
      )
    )
  )

  (if (and (= g_tg_m16 "1") g_m16_blk (/= g_m16_blk "���þȵ�") (/= g_m16_blk ""))
    (progn
      (setq ent-m16 (ssget "X" '((0 . "INSERT"))))
      (if ent-m16
        (progn (setq m 0)
          (repeat (sslength ent-m16)
            (setq b-ent (ssname ent-m16 m))
            (setq b-dxf (entget b-ent))
            (if (= (strcase (Get-Effective-Name b-ent)) (strcase g_m16_blk))
              (setq all-m16-objects
                (cons
                  (list (cdr (assoc 10 b-dxf)) (if (= (Get-Dynamic-Visibility b-ent) "") "M16" (Get-Dynamic-Visibility b-ent)))
                  all-m16-objects
                )
              )
            )
            (setq m (1+ m))
          )
        )
      )
    )
  )

  (setq compiled-res nil current-idx 1)

  (foreach dwg-node sorted-list
    (setq dwg-ent (car dwg-node) dwg-bl (cadr dwg-node) bounds (nth 2 dwg-node))
    (setq d-x1 (nth 0 bounds) d-y1 (nth 1 bounds) 
          d-x2 (nth 2 bounds) d-y2 (nth 3 bounds))

    (princ (strcat "\n[���� ��Ȳ] " (itoa current-idx) " / " (itoa total-cnt) " ���� ���� ��..."))

    (setq txt-str "��Ʈ��ȣ_�̰���" has-61 "����" found-61 nil err-reason "" x_over_limit_error nil w_over_limit_error nil lot-text-count 0)
    (setq temp-ops nil temp-slvs nil temp-m16s nil final-ops nil final-slvs nil final-op-details nil final-slv-details nil final-m16-details nil)
    (setq out-con-tl nil out-con-w "0" out-con-h "0" in-con-tl nil in-con-w "0" in-con-h "0" con-tl nil con-w "0" con-h "0")

    (setq tx1 (+ (car dwg-bl) g_x1_off) ty1 (+ (cadr dwg-bl) g_y1_off)
          tx2 (+ (car dwg-bl) g_x2_off) ty2 (+ (cadr dwg-bl) g_y2_off))
    
    (setq min-tx (- (min tx1 tx2) 100.0) max-tx (+ (max tx1 tx2) 100.0)
          min-ty (- (min ty1 ty2) 100.0) max-ty (+ (max ty1 ty2) 100.0))

    (setq best-lot-height -1.0)
    (if all-texts
      (foreach t-node all-texts
        (if (and (In_Box_P (car t-node) min-tx min-ty max-tx max-ty) (Is_Lot_Number_Format (cadr t-node)))
          (progn
            (setq lot-text-count (1+ lot-text-count))
            (if (> (caddr t-node) best-lot-height)
              (setq txt-str (vl-string-trim " \t\n\r" (cadr t-node)) best-lot-height (caddr t-node))
            )
          )
        )
      )
    )

    ;; ��ũ��Ʈ ũ�� ���� ����ȭ
    ;; ���� ����� ���� ���̾��� ���� ���������� ��� ���� �ϳ��� ū �ڽ��� ������� ������,
    ;; ���� ���ο� ������/�ٸ� ������ ������ ����/���� ũ�Ⱑ ���� ������ �� �־���.
    ;; ���� ����� �� �Ǻ��� ������ ���� ū ��ǥ ���� �������� 1���� �����ϰ�,
    ;; �� ��ǥ �ڽ��� ��ũ��Ʈ ũ��� ��ü ���� ������ ����Ѵ�.
    (setq out-con-boxes nil in-con-boxes nil slab-con-boxes nil)
    (setq best-out-box nil best-in-box nil best-slab-box nil)
    (setq best-out-area -1.0 best-in-area -1.0 best-slab-area -1.0)
    (setq wall-candidates nil)
    
    (if (= g_active_mode "DOUBLE")
      (progn
        (setq has-out-con nil has-in-con nil)
        
        ;; ������ ��ũ��Ʈ �Ǻ�
        ;; 1��: ������ ����/���� ���̾�+�������� ��ǥ ���������� ã�´�.
        ;; 2��: ����/���� ������ ���ų� ���� ������ ���� �ʾ� ���ʸ� ������ ���,
        ;;      ���� ���� ��ũ��Ʈ �ĺ� 2���� X��ǥ �������� �����Ͽ� ����=����, ������=�������� �ڵ� �����Ѵ�.
        (foreach c-obj all-con-objects
          (setq c-ent (car c-obj) c-pts (cadr c-obj))
          (setq bminx (apply 'min (mapcar 'car c-pts))
                bminy (apply 'min (mapcar 'cadr c-pts))
                bmaxx (apply 'max (mapcar 'car c-pts))
                bmaxy (apply 'max (mapcar 'cadr c-pts)))
          (setq cx (/ (+ bminx bmaxx) 2.0)
                cy (/ (+ bminy bmaxy) 2.0)
                barea (* (abs (- bmaxx bminx)) (abs (- bmaxy bminy))))
          
          (if (In_Box_P (list cx cy) d-x1 d-y1 d-x2 d-y2)
            (progn
              (if (or (Check_Layer_Color_Match c-ent g_out_con_list t)
                      (Check_Layer_Color_Match c-ent g_in_con_list t))
                (setq wall-candidates
                  (cons (list cx barea (list bminx bminy bmaxx bmaxy) (Count_Openings_In_Box (list bminx bminy bmaxx bmaxy) all-op-objects)) wall-candidates)
                )
              )
              (cond
                ((Check_Layer_Color_Match c-ent g_out_con_list t)
                 (if (> barea best-out-area)
                   (setq best-out-area barea
                         best-out-box (list bminx bminy bmaxx bmaxy))
                 )
                )
                ((Check_Layer_Color_Match c-ent g_in_con_list t)
                 (if (> barea best-in-area)
                   (setq best-in-area barea
                         best-in-box (list bminx bminy bmaxx bmaxy))
                 )
                )
              )
            )
          )
        )
        
        ;; ����/���� ���̾� �Ǵ� ������ ������ ��� ����:
        ;; �ĺ� �� ������ ū 2���� ���� ��, X �߽��� ���� ���� OUT, ū ���� IN���� ����Ѵ�.
        (if (and wall-candidates
                 (>= (pcg-list-length wall-candidates) 2)
                 (or (not best-out-box)
                     (not best-in-box)
                     (equal best-out-box best-in-box 0.001)))
          (progn
            (setq wall-candidates
              (vl-sort wall-candidates
                '(lambda (a b)
                  (if (= (cadddr a) (cadddr b))
                    (> (cadr a) (cadr b))
                    (> (cadddr a) (cadddr b))
                  )
                )
              )
            )
            (setq wall-candidates (list (nth 0 wall-candidates) (nth 1 wall-candidates)))
            (setq wall-candidates
              (vl-sort wall-candidates
                '(lambda (a b) (< (car a) (car b)))
              )
            )
            (setq best-out-box (caddr (nth 0 wall-candidates)))
            (setq best-in-box  (caddr (nth 1 wall-candidates)))
          )
        )
        
        (if best-out-box
          (progn
            (setq has-out-con t
                  out-c-minx (nth 0 best-out-box)
                  out-c-miny (nth 1 best-out-box)
                  out-c-maxx (nth 2 best-out-box)
                  out-c-maxy (nth 3 best-out-box)
                  out-con-boxes (list best-out-box)
                  out-con-tl (list out-c-minx out-c-maxy)
                  out-con-w (rtos (abs (- out-c-maxx out-c-minx)) 2 0)
                  out-con-h (rtos (abs (- out-c-maxy out-c-miny)) 2 0))
          )
        )
        
        (if best-in-box
          (progn
            (setq has-in-con t
                  in-c-minx (nth 0 best-in-box)
                  in-c-miny (nth 1 best-in-box)
                  in-c-maxx (nth 2 best-in-box)
                  in-c-maxy (nth 3 best-in-box)
                  in-con-boxes (list best-in-box)
                  in-con-tl (list in-c-minx in-c-maxy)
                  in-con-w (rtos (abs (- in-c-maxx in-c-minx)) 2 0)
                  in-con-h (rtos (abs (- in-c-maxy in-c-miny)) 2 0))
          )
        )
        
        (if (or (and has-out-con (> (abs (- out-c-maxx out-c-minx)) 10000.0))
                (and has-in-con (> (abs (- in-c-maxx in-c-minx)) 10000.0)))
          (setq w_over_limit_error t)
        )
      )
      (progn
        (setq has-con nil)
        
        (foreach c-obj all-con-objects
          (setq c-ent (car c-obj) c-pts (cadr c-obj))
          (setq bminx (apply 'min (mapcar 'car c-pts))
                bminy (apply 'min (mapcar 'cadr c-pts))
                bmaxx (apply 'max (mapcar 'car c-pts))
                bmaxy (apply 'max (mapcar 'cadr c-pts)))
          (setq cx (/ (+ bminx bmaxx) 2.0)
                cy (/ (+ bminy bmaxy) 2.0)
                barea (* (abs (- bmaxx bminx)) (abs (- bmaxy bminy))))
          
          (if (and (In_Box_P (list cx cy) d-x1 d-y1 d-x2 d-y2)
                   (Check_Layer_Color_Match c-ent g_con_list nil))
            (if (> barea best-slab-area)
              (setq best-slab-area barea
                    best-slab-box (list bminx bminy bmaxx bmaxy))
            )
          )
        )
        
        (if best-slab-box
          (progn
            (setq has-con t
                  c-minx (nth 0 best-slab-box)
                  c-miny (nth 1 best-slab-box)
                  c-maxx (nth 2 best-slab-box)
                  c-maxy (nth 3 best-slab-box)
                  slab-con-boxes (list best-slab-box)
                  con-tl (list c-minx c-maxy)
                  con-w (rtos (abs (- c-maxx c-minx)) 2 0)
                  con-h (rtos (abs (- c-maxy c-miny)) 2 0))
          )
        )
        
        (if (and has-con (> (abs (- c-maxx c-minx)) 10000.0))
          (setq w_over_limit_error t)
        )
      )
    )

    (if all-op-objects
      (foreach o-obj all-op-objects
        (if (= (car o-obj) "RECT")
          (progn
            (setq o-pts (cadr o-obj))
            (setq op-x1 (apply 'min (mapcar 'car o-pts)) op-y1 (apply 'min (mapcar 'cadr o-pts))
                  op-x2 (apply 'max (mapcar 'car o-pts)) op-y2 (apply 'max (mapcar 'cadr o-pts)))
            (setq op-center (list (/ (+ op-x1 op-x2) 2.0) (/ (+ op-y1 op-y2) 2.0)))
            
            (if (In_Box_P op-center d-x1 d-y1 d-x2 d-y2)
              (if (= g_active_mode "DOUBLE")
                (progn
                  (setq is-out nil is-in nil)
                  (foreach cb out-con-boxes (if (In_Box_P op-center (nth 0 cb) (nth 1 cb) (nth 2 cb) (nth 3 cb)) (setq is-out t)))
                  (foreach cb in-con-boxes (if (In_Box_P op-center (nth 0 cb) (nth 1 cb) (nth 2 cb) (nth 3 cb)) (setq is-in t)))
                  
                  (if (and is-out has-out-con)
                    (progn
                      (setq dist-x (abs (- op-x1 (car out-con-tl))) dist-y (abs (- (cadr out-con-tl) op-y2)))
                      (if (> dist-x 3000.0) (setq x_over_limit_error t))
                      (setq temp-ops (cons (list (abs (- op-x2 op-x1)) (abs (- op-y2 op-y1)) op-center dist-x dist-y op-x1 op-y1 op-x2 op-y2 "OUT") temp-ops))
                    )
                  )
                  (if (and is-in has-in-con)
                    (progn
                      (setq dist-x (abs (- op-x1 (car in-con-tl))) dist-y (abs (- (cadr in-con-tl) op-y2)))
                      (if (> dist-x 3000.0) (setq x_over_limit_error t))
                      (setq temp-ops (cons (list (abs (- op-x2 op-x1)) (abs (- op-y2 op-y1)) op-center dist-x dist-y op-x1 op-y1 op-x2 op-y2 "IN") temp-ops))
                    )
                  )
                )
                (progn
                  (setq is-slab nil)
                  (foreach cb slab-con-boxes (if (In_Box_P op-center (nth 0 cb) (nth 1 cb) (nth 2 cb) (nth 3 cb)) (setq is-slab t)))
                  (if (and is-slab has-con)
                    (progn
                      (setq dist-x (abs (- op-x1 (car con-tl))) dist-y (abs (- (cadr con-tl) op-y2)))
                      (setq temp-ops (cons (list (abs (- op-x2 op-x1)) (abs (- op-y2 op-y1)) op-center dist-x dist-y op-x1 op-y1 op-x2 op-y2 "SLAB") temp-ops))
                    )
                  )
                )
              )
            )
          )
          (progn
            (setq slv-center (cadr o-obj) slv-dia (* (caddr o-obj) 2.0))
            (if (In_Box_P slv-center d-x1 d-y1 d-x2 d-y2)
              (if (= g_active_mode "DOUBLE")
                (progn
                  (setq is-out nil is-in nil)
                  (foreach cb out-con-boxes (if (In_Box_P slv-center (nth 0 cb) (nth 1 cb) (nth 2 cb) (nth 3 cb)) (setq is-out t)))
                  (foreach cb in-con-boxes (if (In_Box_P slv-center (nth 0 cb) (nth 1 cb) (nth 2 cb) (nth 3 cb)) (setq is-in t)))
                  
                  (if (and is-out has-out-con)
                    (progn
                      (setq dist-x (abs (- (car slv-center) (car out-con-tl))) dist-y (abs (- (cadr out-con-tl) (cadr slv-center))))
                      (if (> dist-x 3000.0) (setq x_over_limit_error t))
                      (setq temp-slvs (cons (list slv-dia slv-center dist-x dist-y "OUT") temp-slvs))
                    )
                  )
                  (if (and is-in has-in-con)
                    (progn
                      (setq dist-x (abs (- (car slv-center) (car in-con-tl))) dist-y (abs (- (cadr in-con-tl) (cadr slv-center))))
                      (if (> dist-x 3000.0) (setq x_over_limit_error t))
                      (setq temp-slvs (cons (list slv-dia slv-center dist-x dist-y "IN") temp-slvs))
                    )
                  )
                )
                (progn
                  (setq is-slab nil)
                  (foreach cb slab-con-boxes (if (In_Box_P slv-center (nth 0 cb) (nth 1 cb) (nth 2 cb) (nth 3 cb)) (setq is-slab t)))
                  (if (and is-slab has-con)
                    (progn
                      (setq dist-x (abs (- (car slv-center) (car con-tl))) dist-y (abs (- (cadr con-tl) (cadr slv-center))))
                      (setq temp-slvs (cons (list slv-dia slv-center dist-x dist-y "SLAB") temp-slvs))
                    )
                  )
                )
              )
            )
          )
        )
      )
    )

    (if all-m16-objects
      (foreach m-node all-m16-objects
        (setq m-pt (car m-node))
        (setq m-vis (cadr m-node))
        (if (In_Box_P m-pt d-x1 d-y1 d-x2 d-y2)
          (if (= g_active_mode "DOUBLE")
            (progn
              (setq is-out nil is-in nil)
              (foreach cb out-con-boxes (if (In_Box_P m-pt (nth 0 cb) (nth 1 cb) (nth 2 cb) (nth 3 cb)) (setq is-out t)))
              (foreach cb in-con-boxes (if (In_Box_P m-pt (nth 0 cb) (nth 1 cb) (nth 2 cb) (nth 3 cb)) (setq is-in t)))
              
              (if (and is-out has-out-con)
                (progn
                  (setq dist-x (abs (- (car m-pt) (car out-con-tl))) dist-y (abs (- (cadr out-con-tl) (cadr m-pt))))
                  (if (> dist-x 3000.0) (setq x_over_limit_error t))
                  (setq temp-m16s (cons (list m-pt dist-x dist-y "OUT" m-vis) temp-m16s))
                )
              )
              (if (and is-in has-in-con)
                (progn
                  (setq dist-x (abs (- (car m-pt) (car in-con-tl))) dist-y (abs (- (cadr in-con-tl) (cadr m-pt))))
                  (if (> dist-x 3000.0) (setq x_over_limit_error t))
                  (setq temp-m16s (cons (list m-pt dist-x dist-y "IN" m-vis) temp-m16s))
                )
              )
            )
            (progn
              (setq is-slab nil)
              (foreach cb slab-con-boxes (if (In_Box_P m-pt (nth 0 cb) (nth 1 cb) (nth 2 cb) (nth 3 cb)) (setq is-slab t)))
              (if (and is-slab has-con)
                (progn
                  (setq dist-x (abs (- (car m-pt) (car con-tl))) dist-y (abs (- (cadr con-tl) (cadr m-pt))))
                  (setq temp-m16s (cons (list m-pt dist-x dist-y "SLAB" m-vis) temp-m16s))
                )
              )
            )
          )
        )
      )
    )

    (if temp-ops
      (foreach op temp-ops
        (setq dup nil)
        (foreach f-op final-ops
          (if (and (= (nth 9 op) (nth 9 f-op)) (< (distance (list (car (nth 2 op)) (cadr (nth 2 op))) (list (car (nth 2 f-op)) (cadr (nth 2 f-op)))) 150.0))
            (progn (setq dup t) (if (> (* (nth 0 op) (nth 1 op)) (* (nth 0 f-op) (nth 1 f-op))) (setq final-ops (subst op f-op final-ops))))
          )
        )
        (if (not dup) (setq final-ops (cons op final-ops)))
      )
    )

    (if temp-slvs
      (foreach slv temp-slvs
        (setq slv-center (nth 1 slv) slv-dia (nth 0 slv) skip nil)
        (foreach f-op final-ops
          (if (and (= (nth 4 slv) (nth 9 f-op)) (In_Box_P slv-center (nth 5 f-op) (nth 6 f-op) (nth 7 f-op) (nth 8 f-op)))
            (if (< (distance (list (car slv-center) (cadr slv-center)) (list (car (nth 2 f-op)) (cadr (nth 2 f-op)))) 50.0) (setq skip t))
          )
        )
        (if (not skip)
          (foreach f-slv final-slvs
            (if (and (= (nth 4 slv) (nth 4 f-slv)) (< (distance (list (car slv-center) (cadr slv-center)) (list (car (nth 1 f-slv)) (cadr (nth 1 f-slv)))) 150.0))
              (progn (setq skip t) (if (> slv-dia (nth 0 f-slv)) (setq final-slvs (subst slv f-slv final-slvs))))
            )
          )
        )
        (if (not skip) (setq final-slvs (cons slv final-slvs)))
      )
    )

    (setq op-cnt-check (pcg-list-length final-ops))
    (setq slv-cnt-check (pcg-list-length final-slvs))
    (setq m16-cnt-check (pcg-list-length temp-m16s))
    
    (setq o_out nil o_in nil s_out nil s_in nil m_out nil m_in nil)
    (foreach op final-ops
      (if (or (= g_active_mode "SLAB") (= (nth 9 op) "OUT"))
        (setq o_out (append o_out (list (rtos (nth 0 op) 2 0) (rtos (nth 1 op) 2 0) (rtos (nth 3 op) 2 0) (rtos (nth 4 op) 2 0))))
        (setq o_in (append o_in (list (rtos (nth 0 op) 2 0) (rtos (nth 1 op) 2 0) (rtos (nth 3 op) 2 0) (rtos (nth 4 op) 2 0))))
      )
    )
    (foreach slv final-slvs
      (if (or (= g_active_mode "SLAB") (= (nth 4 slv) "OUT"))
        (setq s_out (append s_out (list (rtos (nth 0 slv) 2 0) (rtos (nth 2 slv) 2 0) (rtos (nth 3 slv) 2 0))))
        (setq s_in (append s_in (list (rtos (nth 0 slv) 2 0) (rtos (nth 2 slv) 2 0) (rtos (nth 3 slv) 2 0))))
      )
    )
    (foreach m16 temp-m16s
      (if (or (= g_active_mode "SLAB") (= (nth 3 m16) "OUT"))
        (setq m_out (append m_out (list (nth 4 m16) (rtos (nth 1 m16) 2 0) (rtos (nth 2 m16) 2 0))))
        (setq m_in (append m_in (list (nth 4 m16) (rtos (nth 1 m16) 2 0) (rtos (nth 2 m16) 2 0))))
      )
    )

    (if (= g_active_mode "SLAB")
      (setq final-op-details o_out final-slv-details s_out final-m16-details m_out)
      (setq final-op-details (list o_out o_in) final-slv-details (list s_out s_in) final-m16-details (list m_out m_in))
    )

    (if all-texts
      (foreach t-node all-texts
        (if (In_Box_P (car t-node) d-x1 d-y1 d-x2 d-y2)
          (if (= (vl-string-trim " \t\n\r" (cadr t-node)) g_rebar_no) (setq found-61 t))
        )
      )
    )
    
    (setq sub-ent (entnext dwg-ent))
    (while (and sub-ent (/= (cdr (assoc 0 (entget sub-ent))) "SEQEND"))
      (setq sub-dxf (entget sub-ent))
      (if (and (= (cdr (assoc 0 sub-dxf)) "ATTRIB") (= (vl-string-trim " \t\n\r" (cdr (assoc 1 sub-dxf))) g_rebar_no)) (setq found-61 t))
      (setq sub-ent (entnext sub-ent))
    )

    (cond
      ((= txt-str "��Ʈ��ȣ_�̰���")
       (setq has-61 "����" err-reason "��Ʈ��ȣ �̰���"))
      ((if (= g_active_mode "DOUBLE") (not (and has-out-con has-in-con)) (not has-con))
       (setq has-61 "����" err-reason "��ũ��Ʈ ����"))
      (w_over_limit_error
       (setq has-61 "����" err-reason "���α��� 10000 �ʰ� ����"))
      ((and (= g_active_mode "DOUBLE") x_over_limit_error)
       (setq has-61 "����" err-reason "X��ǥ 3000 �ʰ� ����"))
      ((and (= g_tg_m16 "1") (= m16-cnt-check 0))
       (setq has-61 "����" err-reason "M16 ���� ����"))
      ((and found-61 (= op-cnt-check 0) (= slv-cnt-check 0))
       (setq has-61 "����" err-reason "������/������ ����"))
      ((and (not found-61) (or (> op-cnt-check 0) (> slv-cnt-check 0)))
       (setq has-61 "����" err-reason (strcat g_rebar_no "�� ��ȣ ����")))
      (t
       (setq has-61 "����" err-reason ""))
    )

    (if (= g_active_mode "DOUBLE")
      (setq target-node (list txt-str (itoa op-cnt-check) (itoa slv-cnt-check) (itoa m16-cnt-check) has-61 final-op-details final-slv-details final-m16-details err-reason out-con-w out-con-h in-con-w in-con-h))
      (setq target-node (list txt-str (itoa op-cnt-check) (itoa slv-cnt-check) (itoa m16-cnt-check) has-61 final-op-details final-slv-details final-m16-details err-reason con-w con-h "0" "0"))
    )
    (setq compiled-res (cons target-node compiled-res))
    (setq current-idx (1+ current-idx))
  )
  (reverse compiled-res)
)

;; ���� ���� �� O/X �и� ��� ����
(defun Export_Data_To_Live_Excel (summary-data headers m16-flag mode_string / xl-app xl-books xl-book xl-sheet row-idx col-idx node name-v op-cnt-v slv-cnt-v m16-cnt-v check-v op-det slv-det m16-det item
                                                local-col-letter write-empty-dims max-ops max-slvs max-m16s i cell-d op-pref slv-pref con-pref m16-pref con-w-val con-h-val lot-val
                                                sep suffix op-ox slv-ox m16-ox lot-nm blank-val cur-col out-pref in-pref
                                                o_out s_out m_out o_in s_in m_in b w h x y d cnt_o_out cnt_o_in cnt_s_out cnt_s_in cnt_m_out cnt_m_in tmp-col start-det-col max-col cur-cell)
  
  (defun local-col-letter (col / letter)
    (setq letter "")
    (while (> col 0)
      (setq letter (strcat (chr (+ 65 (rem (1- col) 26))) letter))
      (setq col (/ (1- col) 26))
    )
    letter
  )

  (defun write-empty-dims (count c r blank sht / k cell)
    (setq k 0)
    (while (< k count)
      (setq cell (vlax-get-property sht 'Range (strcat (local-col-letter c) (itoa r))))
      (vlax-put-property cell 'Value2 (if (= blank "") "" blank))
      (if (/= blank "") (vlax-put-property (vlax-get-property cell 'Font) 'Color 16777215))
      (setq c (1+ c) k (1+ k))
    )
    c
  )

  (setq xl-app (vlax-get-or-create-object "Excel.Application"))
  (vla-put-visible xl-app :vlax-true)
  (setq xl-books (vlax-get-property xl-app 'Workbooks))
  (setq xl-book (vlax-invoke-method xl-books 'Add))
  (setq xl-sheet (vlax-get-property xl-book 'ActiveSheet))

  (setq max-ops 0 max-slvs 0 max-m16s 0)
  (foreach node summary-data
    (if (= mode_string "DOUBLE")
      (progn
        (setq o_out (/ (pcg-list-length (car (nth 5 node))) 4) o_in (/ (pcg-list-length (cadr (nth 5 node))) 4))
        (setq s_out (/ (pcg-list-length (car (nth 6 node))) 3) s_in (/ (pcg-list-length (cadr (nth 6 node))) 3))
        (setq m_out (/ (pcg-list-length (car (nth 7 node))) 3) m_in (/ (pcg-list-length (cadr (nth 7 node))) 3))
        (if (> o_out max-ops) (setq max-ops o_out)) (if (> o_in max-ops) (setq max-ops o_in))
        (if (> s_out max-slvs) (setq max-slvs s_out)) (if (> s_in max-slvs) (setq max-slvs s_in))
        (if (> m_out max-m16s) (setq max-m16s m_out)) (if (> m_in max-m16s) (setq max-m16s m_in))
      )
      (progn
        (if (> (atoi (nth 1 node)) max-ops) (setq max-ops (atoi (nth 1 node))))
        (if (> (atoi (nth 2 node)) max-slvs) (setq max-slvs (atoi (nth 2 node))))
        (if (> (atoi (nth 3 node)) max-m16s) (setq max-m16s (atoi (nth 3 node))))
      )
    )
  )
  
  (if (/= m16-flag "1") (setq max-m16s 0))

  (setq cur-col 1)
  (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 "��Ʈ��ȣ") (setq cur-col (1+ cur-col))
  
  (if (= mode_string "DOUBLE")
    (progn
      (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 "���� ������ ����") (setq cur-col (1+ cur-col))
      (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 "���� ������ ����") (setq cur-col (1+ cur-col))
      (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 "���� ������ ����") (setq cur-col (1+ cur-col))
      (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 "���� ������ ����") (setq cur-col (1+ cur-col))
      (if (= m16-flag "1")
        (progn
          (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 "���� M16 ����") (setq cur-col (1+ cur-col))
          (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 "���� M16 ����") (setq cur-col (1+ cur-col))
        )
      )
    )
    (progn
      (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 "������ ����") (setq cur-col (1+ cur-col))
      (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 "������ ����") (setq cur-col (1+ cur-col))
      (if (= m16-flag "1") (progn (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 "M16 ����") (setq cur-col (1+ cur-col))))
    )
  )

  (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 "����") (setq cur-col (1+ cur-col))

  (setq op-pref (nth 0 headers) slv-pref (nth 5 headers) con-pref (nth 9 headers))
  (setq sep (nth 12 headers) suffix (nth 13 headers))
  (setq op-ox (nth 14 headers) slv-ox (nth 15 headers))
  (setq lot-nm (nth 16 headers) blank-val (nth 17 headers))
  (setq m16-pref (nth 18 headers) m16-ox (nth 19 headers))
  (setq out-pref (nth 22 headers) in-pref (nth 23 headers))

  (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat lot-nm suffix)) (setq cur-col (1+ cur-col))
  
  (if (= mode_string "DOUBLE")
    (progn
      (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat out-pref con-pref (nth 10 headers) suffix)) (setq cur-col (1+ cur-col))
      (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat out-pref con-pref (nth 11 headers) suffix)) (setq cur-col (1+ cur-col))
      (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat in-pref con-pref (nth 10 headers) suffix)) (setq cur-col (1+ cur-col))
      (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat in-pref con-pref (nth 11 headers) suffix)) (setq cur-col (1+ cur-col))
      
      (setq i 1) (repeat max-ops (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat out-pref op-ox sep (itoa i) suffix)) (setq cur-col (1+ cur-col) i (1+ i)))
      (setq i 1) (repeat max-ops (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat in-pref op-ox sep (itoa i) suffix)) (setq cur-col (1+ cur-col) i (1+ i)))
      
      (setq i 1) (repeat max-slvs (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat out-pref slv-ox sep (itoa i) suffix)) (setq cur-col (1+ cur-col) i (1+ i)))
      (setq i 1) (repeat max-slvs (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat in-pref slv-ox sep (itoa i) suffix)) (setq cur-col (1+ cur-col) i (1+ i)))
      
      (if (= m16-flag "1")
        (progn
          (setq i 1) (repeat max-m16s (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat out-pref m16-ox sep (itoa i) suffix)) (setq cur-col (1+ cur-col) i (1+ i)))
          (setq i 1) (repeat max-m16s (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat in-pref m16-ox sep (itoa i) suffix)) (setq cur-col (1+ cur-col) i (1+ i)))
        )
      )

      (setq i 1)
      (repeat max-ops
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat out-pref op-pref (nth 1 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat out-pref op-pref (nth 2 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat out-pref op-pref (nth 3 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat out-pref op-pref (nth 4 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (setq i (1+ i))
      )
      (setq i 1)
      (repeat max-ops
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat in-pref op-pref (nth 1 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat in-pref op-pref (nth 2 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat in-pref op-pref (nth 3 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat in-pref op-pref (nth 4 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (setq i (1+ i))
      )
      
      (setq i 1)
      (repeat max-slvs
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat out-pref slv-pref (nth 6 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat out-pref slv-pref (nth 7 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat out-pref slv-pref (nth 8 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (setq i (1+ i))
      )
      (setq i 1)
      (repeat max-slvs
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat in-pref slv-pref (nth 6 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat in-pref slv-pref (nth 7 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat in-pref slv-pref (nth 8 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (setq i (1+ i))
      )
      
      (if (= m16-flag "1")
        (progn
          (setq i 1)
          (repeat max-m16s
            (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat out-pref m16-pref "����" sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
            (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat out-pref m16-pref (nth 20 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
            (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat out-pref m16-pref (nth 21 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
            (setq i (1+ i))
          )
          (setq i 1)
          (repeat max-m16s
            (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat in-pref m16-pref "����" sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
            (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat in-pref m16-pref (nth 20 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
            (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat in-pref m16-pref (nth 21 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
            (setq i (1+ i))
          )
        )
      )
    )
    (progn
      (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat con-pref (nth 10 headers) suffix)) (setq cur-col (1+ cur-col))
      (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat con-pref (nth 11 headers) suffix)) (setq cur-col (1+ cur-col))
      
      (setq i 1) (repeat max-ops (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat op-ox sep (itoa i) suffix)) (setq cur-col (1+ cur-col) i (1+ i)))
      (setq i 1) (repeat max-slvs (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat slv-ox sep (itoa i) suffix)) (setq cur-col (1+ cur-col) i (1+ i)))
      (if (= m16-flag "1") (progn (setq i 1) (repeat max-m16s (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat m16-ox sep (itoa i) suffix)) (setq cur-col (1+ cur-col) i (1+ i)))))

      (setq i 1)
      (repeat max-ops
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat op-pref (nth 1 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat op-pref (nth 2 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat op-pref (nth 3 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat op-pref (nth 4 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (setq i (1+ i))
      )
      (setq i 1)
      (repeat max-slvs
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat slv-pref (nth 6 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat slv-pref (nth 7 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat slv-pref (nth 8 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
        (setq i (1+ i))
      )
      (if (= m16-flag "1")
        (progn
          (setq i 1)
          (repeat max-m16s
            (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat m16-pref "����" sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
            (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat m16-pref (nth 20 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
            (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) "1")) 'Value2 (strcat m16-pref (nth 21 headers) sep (itoa i) suffix)) (setq cur-col (1+ cur-col))
            (setq i (1+ i))
          )
        )
      )
    )
  )

  (setq row-idx 2)
  (foreach node summary-data
    (setq name-v    (nth 0 node) 
          op-cnt-v  (nth 1 node)
          slv-cnt-v (nth 2 node)
          m16-cnt-v (nth 3 node) 
          check-v   (nth 4 node)
          op-det    (nth 5 node)
          slv-det   (nth 6 node)
          m16-det   (nth 7 node)
          out-w-val (nth 9 node)  out-h-val (nth 10 node)
          in-w-val  (nth 11 node) in-h-val  (nth 12 node))
    
    (setq cur-col 1)
    (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (vl-princ-to-string name-v)) (setq cur-col (1+ cur-col))
    
    (if (= mode_string "DOUBLE")
      (progn
        (setq o_out (car op-det) o_in (cadr op-det))
        (setq s_out (car slv-det) s_in (cadr slv-det))
        (setq m_out (car m16-det) m_in (cadr m16-det))
        (setq cnt_o_out (/ (pcg-list-length o_out) 4) cnt_o_in (/ (pcg-list-length o_in) 4))
        (setq cnt_s_out (/ (pcg-list-length s_out) 3) cnt_s_in (/ (pcg-list-length s_in) 3))
        (setq cnt_m_out (/ (pcg-list-length m_out) 3) cnt_m_in (/ (pcg-list-length m_in) 3))
        
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 cnt_o_out) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 cnt_o_in) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 cnt_s_out) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 cnt_s_in) (setq cur-col (1+ cur-col))
        
        (if (= m16-flag "1")
          (progn
            (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 cnt_m_out) (setq cur-col (1+ cur-col))
            (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 cnt_m_in) (setq cur-col (1+ cur-col))
          )
        )
      )
      (progn
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (atoi (vl-princ-to-string op-cnt-v))) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (atoi (vl-princ-to-string slv-cnt-v))) (setq cur-col (1+ cur-col))
        (if (= m16-flag "1")
          (progn (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (atoi (vl-princ-to-string m16-cnt-v))) (setq cur-col (1+ cur-col)))
        )
      )
    )
    
    (setq cell-d (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))))
    (vlax-put-property cell-d 'Value2 (vl-princ-to-string check-v))
    (if (= check-v "����")
      (vlax-put-property (vlax-get-property cell-d 'Interior) 'Color 255)
    )
    (setq cur-col (1+ cur-col))
    
    (setq lot-val (Parse_Lot_Number (vl-princ-to-string name-v)))
    (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 lot-val) (setq cur-col (1+ cur-col))
    
    (if (= mode_string "DOUBLE")
      (progn
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (atof out-w-val)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (atof out-h-val)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (atof in-w-val)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (atof in-h-val)) (setq cur-col (1+ cur-col))
        
        (setq i 1) (repeat max-ops (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (if (<= i cnt_o_out) "1" "0")) (setq cur-col (1+ cur-col) i (1+ i)))
        (setq i 1) (repeat max-ops (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (if (<= i cnt_o_in) "1" "0")) (setq cur-col (1+ cur-col) i (1+ i)))
        (setq i 1) (repeat max-slvs (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (if (<= i cnt_s_out) "1" "0")) (setq cur-col (1+ cur-col) i (1+ i)))
        (setq i 1) (repeat max-slvs (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (if (<= i cnt_s_in) "1" "0")) (setq cur-col (1+ cur-col) i (1+ i)))
        
        (if (= m16-flag "1")
          (progn
            (setq i 1) (repeat max-m16s (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (if (<= i cnt_m_out) "1" "0")) (setq cur-col (1+ cur-col) i (1+ i)))
            (setq i 1) (repeat max-m16s (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (if (<= i cnt_m_in) "1" "0")) (setq cur-col (1+ cur-col) i (1+ i)))
          )
        )

        (setq i 0)
        (repeat max-ops
          (if (< i cnt_o_out)
            (progn
              (setq b (* i 4))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth b o_out)) (setq cur-col (1+ cur-col))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 1) o_out)) (setq cur-col (1+ cur-col))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 2) o_out)) (setq cur-col (1+ cur-col))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 3) o_out)) (setq cur-col (1+ cur-col))
            )
            (setq cur-col (write-empty-dims 4 cur-col row-idx blank-val xl-sheet))
          )
          (setq i (1+ i))
        )
        (setq i 0)
        (repeat max-ops
          (if (< i cnt_o_in)
            (progn
              (setq b (* i 4))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth b o_in)) (setq cur-col (1+ cur-col))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 1) o_in)) (setq cur-col (1+ cur-col))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 2) o_in)) (setq cur-col (1+ cur-col))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 3) o_in)) (setq cur-col (1+ cur-col))
            )
            (setq cur-col (write-empty-dims 4 cur-col row-idx blank-val xl-sheet))
          )
          (setq i (1+ i))
        )

        (setq i 0)
        (repeat max-slvs
          (if (< i cnt_s_out)
            (progn
              (setq b (* i 3))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth b s_out)) (setq cur-col (1+ cur-col))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 1) s_out)) (setq cur-col (1+ cur-col))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 2) s_out)) (setq cur-col (1+ cur-col))
            )
            (setq cur-col (write-empty-dims 3 cur-col row-idx blank-val xl-sheet))
          )
          (setq i (1+ i))
        )
        (setq i 0)
        (repeat max-slvs
          (if (< i cnt_s_in)
            (progn
              (setq b (* i 3))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth b s_in)) (setq cur-col (1+ cur-col))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 1) s_in)) (setq cur-col (1+ cur-col))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 2) s_in)) (setq cur-col (1+ cur-col))
            )
            (setq cur-col (write-empty-dims 3 cur-col row-idx blank-val xl-sheet))
          )
          (setq i (1+ i))
        )

        (if (= m16-flag "1")
          (progn 
            (setq i 0)
            (repeat max-m16s
              (if (< i cnt_m_out)
                (progn
                  (setq b (* i 3))
                  (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth b m_out)) (setq cur-col (1+ cur-col))
                  (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 1) m_out)) (setq cur-col (1+ cur-col))
                  (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 2) m_out)) (setq cur-col (1+ cur-col))
                )
                (setq cur-col (write-empty-dims 3 cur-col row-idx blank-val xl-sheet))
              )
              (setq i (1+ i))
            )
            (setq i 0)
            (repeat max-m16s
              (if (< i cnt_m_in)
                (progn
                  (setq b (* i 3))
                  (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth b m_in)) (setq cur-col (1+ cur-col))
                  (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 1) m_in)) (setq cur-col (1+ cur-col))
                  (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 2) m_in)) (setq cur-col (1+ cur-col))
                )
                (setq cur-col (write-empty-dims 3 cur-col row-idx blank-val xl-sheet))
              )
              (setq i (1+ i))
            )
          )
        )
      )
      (progn
        (setq o_in op-det s_in slv-det m_in m16-det)
        (setq cnt_o_in (/ (pcg-list-length o_in) 4) cnt_s_in (/ (pcg-list-length s_in) 3) cnt_m_in (/ (pcg-list-length m_in) 3))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (atof out-w-val)) (setq cur-col (1+ cur-col))
        (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (atof out-h-val)) (setq cur-col (1+ cur-col))
        
        (setq i 1) (repeat max-ops (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (if (<= i cnt_o_in) "1" "0")) (setq cur-col (1+ cur-col) i (1+ i)))
        (setq i 1) (repeat max-slvs (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (if (<= i cnt_s_in) "1" "0")) (setq cur-col (1+ cur-col) i (1+ i)))
        (if (= m16-flag "1") (progn (setq i 1) (repeat max-m16s (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (if (<= i cnt_m_in) "1" "0")) (setq cur-col (1+ cur-col) i (1+ i)))))

        (setq i 0)
        (repeat max-ops
          (if (< i cnt_o_in)
            (progn
              (setq b (* i 4))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth b o_in)) (setq cur-col (1+ cur-col))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 1) o_in)) (setq cur-col (1+ cur-col))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 2) o_in)) (setq cur-col (1+ cur-col))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 3) o_in)) (setq cur-col (1+ cur-col))
            )
            (setq cur-col (write-empty-dims 4 cur-col row-idx blank-val xl-sheet))
          )
          (setq i (1+ i))
        )
        (setq i 0)
        (repeat max-slvs
          (if (< i cnt_s_in)
            (progn
              (setq b (* i 3))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth b s_in)) (setq cur-col (1+ cur-col))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 1) s_in)) (setq cur-col (1+ cur-col))
              (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 2) s_in)) (setq cur-col (1+ cur-col))
            )
            (setq cur-col (write-empty-dims 3 cur-col row-idx blank-val xl-sheet))
          )
          (setq i (1+ i))
        )
        (if (= m16-flag "1")
          (progn (setq i 0)
            (repeat max-m16s
              (if (< i cnt_m_in)
                (progn
                  (setq b (* i 3))
                  (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth b m_in)) (setq cur-col (1+ cur-col))
                  (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 1) m_in)) (setq cur-col (1+ cur-col))
                  (vlax-put-property (vlax-get-property xl-sheet 'Range (strcat (local-col-letter cur-col) (itoa row-idx))) 'Value2 (nth (+ b 2) m_in)) (setq cur-col (1+ cur-col))
                )
                (setq cur-col (write-empty-dims 3 cur-col row-idx blank-val xl-sheet))
              )
              (setq i (1+ i))
            )
          )
        )
      )
    )
    (setq row-idx (1+ row-idx))
  )

  (vlax-release-object xl-sheet) (vlax-release-object xl-books) (vlax-release-object xl-book) (vlax-release-object xl-app)
  (princ)
)


























;; -----------------------------------------------------------------------------
;; v8 override - �Ŵ� ���̵� / ����� ���� ����
;; ����:
;; 1) �Ŵ��� ���簢������ ���� �� A/B/C/D �ڳ� Ȩ�� ������ Ȩ�� void1 �ĺ�
;; 2) ����ڰ� ������ ������ ���̾�+������ �簢��/�� ��ü�� ��鵵 ���ο� ������ void1 �ĺ�
;; 3) ����δ� ���� ��ũ��Ʈ ���ó�� ��/�� ���� ���� ������ ���� ���� �����Ͽ� �������� ����
;; -----------------------------------------------------------------------------

(defun pcg-box-center-in-box-p (b outer tol / cx cy)
  (setq cx (pcg-box-cx b)
        cy (pcg-box-cy b))
  (and
    (>= cx (- (nth 0 outer) tol))
    (<= cx (+ (nth 2 outer) tol))
    (>= cy (- (nth 1 outer) tol))
    (<= cy (+ (nth 3 outer) tol))
  )
)

(defun pcg-clip-box-to-box (b outer / x1 y1 x2 y2)
  (setq x1 (max (nth 0 b) (nth 0 outer))
        y1 (max (nth 1 b) (nth 1 outer))
        x2 (min (nth 2 b) (nth 2 outer))
        y2 (min (nth 3 b) (nth 3 outer)))
  (if (and (> x2 x1) (> y2 y1))
    (list x1 y1 x2 y2)
    nil
  )
)

(defun pcg-world-box-to-plan-rel (b plan-box / clipped)
  (setq clipped (pcg-clip-box-to-box b plan-box))
  (if clipped
    (pcg-box-rel-to-plan clipped plan-box)
    nil
  )
)

(defun pcg-opening-boxes-in-plan (plan-box op-objs / out line-boxes line-comps o b rel)
  ;; ������ ������ �ڽ� ��ü�� ��鵵 �ڽ� �ȿ� ���;� �߱� ������,
  ;; ��¦ ��ġ�ų� LINE �������� �׸� ���̵尡 ������ �� �־���.
  ;; ����: �ڽ� �߽��� ��鵵 �ȿ� ������ �ĺ��� ����, ��鵵 �ڽ��� ��ġ�� �κи� ����Ѵ�.
  (setq out nil)
  (setq line-boxes nil)
  (foreach o op-objs
    (setq b (nth 2 o))
    (if (and b (pcg-box-center-in-box-p b plan-box 5.0))
      (progn
        (if (= (car o) "LINE")
          (setq line-boxes (cons b line-boxes))
          (progn
            (setq rel (pcg-world-box-to-plan-rel b plan-box))
            (if (and rel (> (pcg-box-w rel) 5.0) (> (pcg-box-h rel) 5.0))
              (setq out (cons rel out))
            )
          )
        )
      )
    )
  )
  (if line-boxes
    (progn
      (setq line-comps (pcg-line-box-components line-boxes))
      (foreach b line-comps
        (setq rel (pcg-world-box-to-plan-rel b plan-box))
        (if (and rel (> (pcg-box-w rel) 5.0) (> (pcg-box-h rel) 5.0))
          (setq out (cons rel out))
        )
      )
    )
  )
  out
)

(defun pcg-touch-side-count (b girder-len girder-h / tol cnt)
  (setq tol 1.0 cnt 0)
  (if (<= (nth 0 b) tol) (setq cnt (1+ cnt)))
  (if (>= (nth 2 b) (- girder-len tol)) (setq cnt (1+ cnt)))
  (if (<= (nth 1 b) tol) (setq cnt (1+ cnt)))
  (if (>= (nth 3 b) (- girder-h tol)) (setq cnt (1+ cnt)))
  cnt
)

(defun pcg-void-candidate-p (b girder-len girder-h / w h touch)
  (setq w (pcg-box-w b)
        h (pcg-box-h b)
        touch (pcg-touch-side-count b girder-len girder-h))
  (and
    (> w 5.0)
    (> h 5.0)
    (not (pcg-corner-cut-box-p b girder-len girder-h))
    (>= (nth 0 b) -1.0)
    (>= (nth 1 b) -1.0)
    (<= (nth 2 b) (+ girder-len 1.0))
    (<= (nth 3 b) (+ girder-h 1.0))
    ;; ����� ������ ����� �ܰ� ������ void1�� ������ ���� ����
    (not (and (> w (* girder-len 0.85)) (> h 5.0)))
    (not (and (> h (* girder-h 0.85)) (> w 5.0)))
    ;; ���� 1: ���� ���̵� �Ǵ� ���� �鿡�� ���� Ȩ. ���� 2: ������ ���̾� ��ü�� �밳 ���� �ڽ��� ����Ѵ�.
    (<= touch 1)
  )
)

(defun pcg-detect-void1 (boxes girder-len girder-h / candidates b)
  ;; �Ŵ� ���̵� ���� ����
  ;; - A/B/C/D �ڳ� Ȩ ����
  ;; - ���� �簢��/���� ������ ����
  ;; - ���� �鿡�� ���� Ȩ ����
  ;; - ����η� ���� ���� �� �ܰ� ������ ����
  (setq candidates nil)
  (foreach b boxes
    (if (pcg-void-candidate-p b girder-len girder-h)
      (setq candidates (cons b candidates))
    )
  )
  (setq candidates
    (vl-sort candidates
      '(lambda (a b)
        (if (= (nth 0 a) (nth 0 b))
          (> (nth 3 a) (nth 3 b))
          (< (nth 0 a) (nth 0 b))
        )
      )
    )
  )
  (if candidates
    (progn
      (setq b (car candidates))
      ;; X/Y�� ���� ��� ����: X = ���� �Ÿ�, Y = ��ܿ��� ������ �Ÿ�
      (list
        1
        (fix (+ 0.5 (max 0.0 (nth 0 b))))
        (fix (+ 0.5 (max 0.0 (- girder-h (nth 3 b)))))
        (fix (+ 0.5 (pcg-box-w b)))
        (fix (+ 0.5 (pcg-box-h b)))
      )
    )
    (list 0 50 50 50 50)
  )
)

(defun pcg-detect-ledges (pts girder-len girder-h / inside-cells A B C D c x1 x2 y1 y2 w h side vertical key len sideStepL sideStepR step)
  ;; ���� ��ũ��Ʈ�� detectLedges ������ �������� �ϵ�,
  ;; ��/�� ���� ���� ����(sideStep)�� Ȯ�ε� ���� ����η� �����Ѵ�.
  ;; �̷��� �ؾ� �Ϲ� ���̵�/�ڳ�Ȩ �ֺ��� ���� ���� ledge�� ������Ǵ� ���� ���� �� �ִ�.
  (setq A (list 0 50) B (list 0 50) C (list 0 50) D (list 0 50))
  (setq sideStepL 0.0 sideStepR 0.0)
  (setq inside-cells (pcg-grid-cells pts girder-len girder-h t))

  ;; �¿� ������ ���� ���� ���� �� ���
  (foreach c inside-cells
    (setq x1 (nth 2 c) x2 (nth 3 c) y1 (nth 4 c) y2 (nth 5 c))
    (setq w (- x2 x1) h (- y2 y1))
    (if (and (> h 120.0) (<= w 120.0))
      (progn
        (if (<= x1 120.0) (setq sideStepL (max sideStepL w)))
        (if (>= x2 (- girder-len 120.0)) (setq sideStepR (max sideStepR w)))
      )
    )
  )

  ;; ��/�ϴ� ���� ���� ����� ����
  (foreach c inside-cells
    (setq x1 (nth 2 c) x2 (nth 3 c) y1 (nth 4 c) y2 (nth 5 c))
    (setq w (- x2 x1) h (- y2 y1))
    (if (and
          (>= h 45.0)
          (<= h 85.0)
          (> w h)
          (<= w (min 1000.0 (* girder-len 0.3)))
        )
      (progn
        (setq side (cond ((<= x1 1.0) "L") ((>= x2 (- girder-len 1.0)) "R") (t nil)))
        (setq vertical (cond ((<= y1 90.0) "B") ((>= y2 (- girder-h 90.0)) "T") (t nil)))
        (if (and side vertical)
          (progn
            (setq step (if (= side "L") sideStepL sideStepR))
            ;; sideStep�� ������ ���� �������� �������� ���� ���Ƿ� ����η� ���� �ʴ´�.
            (if (> step 1.0)
              (progn
                (setq key
                  (cond
                    ((and (= side "L") (= vertical "T")) "A")
                    ((and (= side "R") (= vertical "T")) "B")
                    ((and (= side "L") (= vertical "B")) "C")
                    (t "D")
                  )
                )
                (setq len (fix (+ 0.5 (- w step))))
                (if (and (> len 0) (<= len 1000))
                  (cond
                    ((= key "A") (if (or (= (car A) 0) (> len (cadr A))) (setq A (list 1 len))))
                    ((= key "B") (if (or (= (car B) 0) (> len (cadr B))) (setq B (list 1 len))))
                    ((= key "C") (if (or (= (car C) 0) (> len (cadr C))) (setq C (list 1 len))))
                    ((= key "D") (if (or (= (car D) 0) (> len (cadr D))) (setq D (list 1 len))))
                  )
                )
              )
            )
          )
        )
      )
    )
  )
  (list A B C D)
)





;; -----------------------------------------------------------------------------
;; v9 override - �Ŵ� ���̵� / ����� ���� ����
;; ��� ����:
;; 1) ���̵�: �Ŵ��� ���簢������ ���� �� A/B/C/D �ڳ� Ȩ�� �����ϰ� �Ŀ� �ִ� Ȩ
;; 2) ���̵�: ������ ������ ���̾�+������ �簢�� ������ / ���� �����갡 �Ŵ� ���ο� �ִ� ���
;; 3) �����(ledge): ������ ��/�� ���ϴ� ���� ����θ� ���� ���� ��� �Ǵ�
;; 4) ledge_A/B/C/D ����� ���̴� ����ΰ� ��� Excel�� �׻� ���
;; -----------------------------------------------------------------------------

(defun pcg-box-overlap-p (a b tol)
  (not
    (or
      (> (nth 0 a) (+ (nth 2 b) tol))
      (> (nth 0 b) (+ (nth 2 a) tol))
      (> (nth 1 a) (+ (nth 3 b) tol))
      (> (nth 1 b) (+ (nth 3 a) tol))
    )
  )
)

(defun pcg-safe-ent-type (ent / ed)
  (if ent
    (progn
      (setq ed (entget ent))
      (if ed (cdr (assoc 0 ed)) "")
    )
    ""
  )
)

(defun pcg-collect-op-objects (/ ss i ent ed typ pts b cen rad out)
  ;; ������ ���̾�+���� �ִ� ��ü�� ���̵�/������ �ĺ��� �����Ѵ�.
  ;; LWPOLYLINE, POLYLINE, CIRCLE, LINE�� �ƴ϶� ����/��ġ�� �ٿ�� �ڽ��� ��� �����Ѵ�.
  (setq out nil)
  (setq ss (ssget "X" '((0 . "LWPOLYLINE,POLYLINE,CIRCLE,LINE,INSERT,HATCH,ELLIPSE,ARC"))))
  (if ss
    (progn
      (setq i 0)
      (repeat (sslength ss)
        (setq ent (ssname ss i))
        (if (Check_Layer_Color_Match ent g_op_list t)
          (progn
            (setq ed (entget ent))
            (setq typ (cdr (assoc 0 ed)))
            (cond
              ((= typ "LWPOLYLINE")
                (setq pts (pcg-lwpoly-pts ent))
                (setq b (pcg-pts-bounds pts))
                (if (and pts b (> (pcg-list-length pts) 1))
                  (setq out (cons (list "RECT" ent b) out))
                )
              )
              ((= typ "POLYLINE")
                (setq b (pcg-ent-bounds ent))
                (if b (setq out (cons (list "RECT" ent b) out)))
              )
              ((= typ "CIRCLE")
                (setq cen (cdr (assoc 10 ed)))
                (setq rad (cdr (assoc 40 ed)))
                (if (and cen rad)
                  (progn
                    (setq b (list (- (car cen) rad) (- (cadr cen) rad) (+ (car cen) rad) (+ (cadr cen) rad)))
                    (setq out (cons (list "CIRCLE" ent b) out))
                  )
                )
              )
              ((= typ "LINE")
                (setq b (pcg-ent-bounds ent))
                (if b (setq out (cons (list "LINE" ent b) out)))
              )
              (t
                (setq b (pcg-ent-bounds ent))
                (if b (setq out (cons (list typ ent b) out)))
              )
            )
          )
        )
        (setq i (1+ i))
      )
    )
  )
  out
)

(defun pcg-opening-boxes-in-plan (plan-box op-objs / out line-boxes line-comps o b rel clipped)
  ;; ������ ������ ���̾�+���� ��ü�� ��鵵 �ڽ��� ��ġ�� �ĺ��� ����.
  ;; ���� center-only ������ ���� ���� �� ��ü�� ������ �� �־ overlap �������� ��ȭ�Ѵ�.
  (setq out nil)
  (setq line-boxes nil)
  (foreach o op-objs
    (setq b (nth 2 o))
    (if (and b (pcg-box-overlap-p b plan-box 10.0))
      (progn
        (if (= (car o) "LINE")
          (setq line-boxes (cons b line-boxes))
          (progn
            (setq clipped (pcg-clip-box-to-box b plan-box))
            (if clipped
              (progn
                (setq rel (pcg-box-rel-to-plan clipped plan-box))
                (if (and rel (> (pcg-box-w rel) 3.0) (> (pcg-box-h rel) 3.0))
                  (setq out (cons rel out))
                )
              )
            )
          )
        )
      )
    )
  )
  (if line-boxes
    (progn
      (setq line-comps (pcg-line-box-components line-boxes))
      (foreach b line-comps
        (setq clipped (pcg-clip-box-to-box b plan-box))
        (if clipped
          (progn
            (setq rel (pcg-box-rel-to-plan clipped plan-box))
            (if (and rel (> (pcg-box-w rel) 3.0) (> (pcg-box-h rel) 3.0))
              (setq out (cons rel out))
            )
          )
        )
      )
    )
  )
  out
)

(defun pcg-explicit-void-candidate-p (b girder-len girder-h / w h)
  ;; ������ ���̾� ��ü�� �ڳʿ� ������� ���� ������/�������� �� �����Ƿ�
  ;; A/B/C/D �ڳ�Ȩ ���� ������ �������� �ʴ´�.
  (setq w (pcg-box-w b) h (pcg-box-h b))
  (and
    (> w 3.0)
    (> h 3.0)
    (>= (nth 0 b) -10.0)
    (>= (nth 1 b) -10.0)
    (<= (nth 2 b) (+ girder-len 10.0))
    (<= (nth 3 b) (+ girder-h 10.0))
    ;; ġ����/�� �������� ������ �� ����
    (not (and (> w (* girder-len 0.70)) (< h 20.0)))
    (not (and (> h (* girder-h 0.70)) (< w 20.0)))
  )
)

(defun pcg-shape-void-candidate-p (b girder-len girder-h / w h touch)
  ;; ���簢�� ���ؿ��� ���� Ȩ. A/B/C/D �ڳ�Ȩ�� �����Ѵ�.
  (setq w (pcg-box-w b)
        h (pcg-box-h b)
        touch (pcg-touch-side-count b girder-len girder-h))
  (and
    (> w 5.0)
    (> h 5.0)
    (not (pcg-corner-cut-box-p b girder-len girder-h))
    (>= (nth 0 b) -1.0)
    (>= (nth 1 b) -1.0)
    (<= (nth 2 b) (+ girder-len 1.0))
    (<= (nth 3 b) (+ girder-h 1.0))
    (not (and (> w (* girder-len 0.85)) (> h 5.0)))
    (not (and (> h (* girder-h 0.85)) (> w 5.0)))
    ;; ���� ���̵�(touch 0) �Ǵ� ���� �鿡�� ���� Ȩ(touch 1)�� ���
    (<= touch 1)
  )
)

(defun pcg-sort-void-boxes (boxes)
  (vl-sort boxes
    '(lambda (a b)
      (if (= (nth 0 a) (nth 0 b))
        (> (nth 3 a) (nth 3 b))
        (< (nth 0 a) (nth 0 b))
      )
    )
  )
)

(defun pcg-void-box-to-values (b girder-h)
  ;; X/Y�� ������ ���� ��� ����
  (list
    1
    (fix (+ 0.5 (max 0.0 (nth 0 b))))
    (fix (+ 0.5 (max 0.0 (- girder-h (nth 3 b)))))
    (fix (+ 0.5 (pcg-box-w b)))
    (fix (+ 0.5 (pcg-box-h b)))
  )
)

(defun pcg-detect-void1-v9 (shape-boxes opening-boxes girder-len girder-h / candidates b)
  ;; �켱���� 1: ����ڰ� ������ ������ ���̾�+���� ��ü
  ;; �켱���� 2: �Ŵ� ���簢�� ���ؿ��� A/B/C/D�� ������ Ȩ
  (setq candidates nil)
  (foreach b opening-boxes
    (if (pcg-explicit-void-candidate-p b girder-len girder-h)
      (setq candidates (cons b candidates))
    )
  )
  (if candidates
    (pcg-void-box-to-values (car (pcg-sort-void-boxes candidates)) girder-h)
    (progn
      (setq candidates nil)
      (foreach b shape-boxes
        (if (pcg-shape-void-candidate-p b girder-len girder-h)
          (setq candidates (cons b candidates))
        )
      )
      (if candidates
        (pcg-void-box-to-values (car (pcg-sort-void-boxes candidates)) girder-h)
        (list 0 50 50 50 50)
      )
    )
  )
)

(defun pcg-ledge-put-slot (slot len A B C D / ilen)
  (setq ilen (fix (+ 0.5 len)))
  (if (< ilen 0) (setq ilen 0))
  (cond
    ((= slot "A") (if (or (= (car A) 0) (> ilen (cadr A))) (setq A (list 1 ilen))))
    ((= slot "B") (if (or (= (car B) 0) (> ilen (cadr B))) (setq B (list 1 ilen))))
    ((= slot "C") (if (or (= (car C) 0) (> ilen (cadr C))) (setq C (list 1 ilen))))
    ((= slot "D") (if (or (= (car D) 0) (> ilen (cadr D))) (setq D (list 1 ilen))))
  )
  (list A B C D)
)

(defun pcg-detect-ledges (pts girder-len girder-h / cells A B C D c x1 x2 y1 y2 w h side vertical slot len step sideStepL sideStepR res minH maxH maxLen)
  ;; ����� ���� ������:
  ;; ����ó�� ��/�� ���ܿ��� ��� �Ǵ� �ϴܿ� ���� ���� ���� �츦 ledge�� �Ǵ��Ѵ�.
  ;; ���� v8ó�� sideStep�� ���ٰ� ������ �ʰ�, ������ ���̿��� ���� ������ ��ü ���̸� ����Ѵ�.
  (setq A (list 0 50) B (list 0 50) C (list 0 50) D (list 0 50))
  (setq sideStepL 0.0 sideStepR 0.0)
  (setq minH 20.0 maxH 260.0 maxLen (min 1200.0 (* girder-len 0.35)))
  (setq cells (pcg-grid-cells pts girder-len girder-h t))

  ;; ��/�� ���� ���� ��. ������ ledge ���̿��� �����Ѵ�.
  (foreach c cells
    (setq x1 (nth 2 c) x2 (nth 3 c) y1 (nth 4 c) y2 (nth 5 c))
    (setq w (- x2 x1) h (- y2 y1))
    (if (and (> h 80.0) (<= w 260.0))
      (progn
        (if (<= x1 260.0) (setq sideStepL (max sideStepL w)))
        (if (>= x2 (- girder-len 260.0)) (setq sideStepR (max sideStepR w)))
      )
    )
  )

  (foreach c cells
    (setq x1 (nth 2 c) x2 (nth 3 c) y1 (nth 4 c) y2 (nth 5 c))
    (setq w (- x2 x1) h (- y2 y1))
    (if (and
          (>= h minH)
          (<= h maxH)
          (> w h)
          (>= w 30.0)
          (<= w maxLen)
        )
      (progn
        (setq side (cond ((<= x1 2.0) "L") ((>= x2 (- girder-len 2.0)) "R") (t nil)))
        (setq vertical (cond ((>= y2 (- girder-h 2.0)) "T") ((<= y1 2.0) "B") (t nil)))
        (if (and side vertical)
          (progn
            (setq slot
              (cond
                ((and (= side "L") (= vertical "T")) "A")
                ((and (= side "R") (= vertical "T")) "B")
                ((and (= side "L") (= vertical "B")) "C")
                (t "D")
              )
            )
            (setq step (if (= side "L") sideStepL sideStepR))
            (setq len (if (> step 1.0) (- w step) w))
            (if (and (> len 0.0) (<= len maxLen))
              (progn
                (setq res (pcg-ledge-put-slot slot len A B C D))
                (setq A (nth 0 res) B (nth 1 res) C (nth 2 res) D (nth 3 res))
              )
            )
          )
        )
      )
    )
  )
  (list A B C D)
)

(defun pcg-write-girder-csv (path rows has-corner has-void has-ledge / f headers)
  ;; ledge_A/B/C/D�� ���� ��� �׻� ����� ����Ѵ�.
  (setq has-ledge t)
  (setq headers (list "" "LOT##NUMBER##GENERAL" "L##length##millimeters" "H##length##millimeters" "B##length##millimeters"))
  (if has-corner
    (setq headers
      (append headers
        (list
          "A_visible##length##millimeters" "B_visible##length##millimeters" "C_visible##length##millimeters" "D_visible##length##millimeters"
          "A_b##length##millimeters" "A_h##length##millimeters" "B_b##length##millimeters" "B_h##length##millimeters"
          "C_b##length##millimeters" "C_h##length##millimeters" "D_b##length##millimeters" "D_h##length##millimeters"
        )
      )
    )
  )
  (if has-void
    (setq headers
      (append headers
        (list "void1_visible##length##millimeters" "void1_x##length##millimeters" "void1_y##length##millimeters" "void1_w##length##millimeters" "void1_h##length##millimeters")
      )
    )
  )
  (setq headers
    (append headers
      (list
        "ledge_A_visible##length##millimeters" "ledge_B_visible##length##millimeters" "ledge_C_visible##length##millimeters" "ledge_D_visible##length##millimeters"
        "ledge_A_length##length##millimeters" "ledge_B_length##length##millimeters" "ledge_C_length##length##millimeters" "ledge_D_length##length##millimeters"
      )
    )
  )
  (setq f (open path "w"))
  (write-line (pcg-join headers ",") f)
  (foreach r rows
    (write-line (pcg-join (pcg-row-to-values r has-corner has-void t) ",") f)
  )
  (close f)
)

(defun Compile_Girder_PureLisp_To_Csv (out / frames texts con-objs op-objs rows has-corner has-void has-ledge idx total frame frame-box candidates ps plan side plan-box side-box plan-pts norm-pts girder-len girder-h girder-b lot empty-cells shape-boxes opening-boxes corner corner-grid corner-prof void1 ledge err status comp)
  (Load_Mode_Config "GIRDER")
  (setq frames (pcg-frame-nodes))
  (setq texts (pcg-collect-texts))
  (setq con-objs (pcg-collect-con-polys))
  (setq op-objs (pcg-collect-op-objects))
  (setq rows nil has-corner nil has-void nil has-ledge t idx 1 total (pcg-list-length frames))
  (foreach frame frames
    (setq frame-box (cadr frame))
    (princ (strcat "\n[���� ��Ȳ] " (itoa idx) " / " (itoa total) " �Ŵ� ���� ���� ��..."))
    (setq lot (pcg-lot-from-frame frame-box (caddr frame) texts))
    (setq candidates (pcg-candidates-in-frame frame-box con-objs))
    (setq ps (pcg-pick-plan-side frame-box candidates))
    (setq plan (car ps) side (cadr ps))
    (setq status "����" err "")
    (if (not (Is_Lot_Number_Format lot)) (setq status "����" err "��Ʈ��ȣ ���� ����"))
    (if (not plan)
      (progn
        (setq status "����" err (if (= err "") "�Ŵ� ��ũ��Ʈ �̰���" (strcat err ", �Ŵ� ��ũ��Ʈ �̰���")))
        (setq girder-len 0 girder-h 0 girder-b 0)
        (setq corner (list (list 0 50 50) (list 0 50 50) (list 0 50 50) (list 0 50 50)))
        (setq void1 (list 0 50 50 50 50))
        (setq ledge (list (list 0 50) (list 0 50) (list 0 50) (list 0 50)))
      )
      (progn
        (setq plan-box (nth 2 plan))
        (setq plan-pts (nth 1 plan))
        (setq girder-len (fix (+ 0.5 (pcg-box-w plan-box))))
        (setq girder-h (fix (+ 0.5 (pcg-box-h plan-box))))
        (if side
          (progn
            (setq side-box (nth 2 side))
            (setq girder-b (fix (+ 0.5 (min (pcg-box-w side-box) (pcg-box-h side-box)))))
          )
          (setq girder-b 0)
        )
        (setq norm-pts (pcg-normalize-pts plan-pts))
        (setq shape-boxes nil opening-boxes nil)
        (if (and norm-pts (> girder-len 0) (> girder-h 0))
          (progn
            ;; ���� ���� �� ����: A/B/C/D �� Ȩ �Ǵܿ�
            (setq empty-cells (pcg-grid-cells norm-pts girder-len girder-h nil))
            (foreach comp (pcg-components empty-cells)
              (setq shape-boxes (cons (pcg-cells-bounds comp) shape-boxes))
            )
            ;; ���� ������ ���̾� ����: �簢�� ������ / ���� ������ / ����/���� ����
            (setq opening-boxes (pcg-opening-boxes-in-plan plan-box op-objs))
            (setq corner-grid (pcg-detect-corner shape-boxes girder-len girder-h))
            (setq corner-prof (pcg-detect-corner-from-profile norm-pts girder-len girder-h))
            (setq corner (pcg-merge-corner-slots corner-prof corner-grid))
            (setq void1 (pcg-detect-void1-v9 shape-boxes opening-boxes girder-len girder-h))
            (setq ledge (pcg-detect-ledges norm-pts girder-len girder-h))
          )
          (progn
            (setq corner (list (list 0 50 50) (list 0 50 50) (list 0 50 50) (list 0 50 50)))
            (setq void1 (list 0 50 50 50 50))
            (setq ledge (list (list 0 50) (list 0 50) (list 0 50) (list 0 50)))
          )
        )
      )
    )
    (if (pcg-visible-any-p corner) (setq has-corner t))
    (if (= (car void1) 1) (setq has-void t))
    (setq rows (append rows (list (list lot (pcg-clean-lot-lsp lot) girder-len girder-b girder-h corner void1 ledge status err))))
    (setq idx (1+ idx))
  )
  (pcg-write-girder-csv out rows has-corner has-void t)
  out
)


;; -----------------------------------------------------------------------------
;; v10 override - �Ŵ� ���̵�/����� ������
;; - ���̵� ���� 1: ���簢�� ���� A/B/C/D ���� ����/���� Ȩ
;; - ���̵� ���� 2: ����ڰ� ������ ������ ���̾�+������ �簢��/��/���� ����
;; - �����: grid cell�� �ƴ϶� ��鵵 �ܰ� ���������� ��/�ϴ� ���� ���׸�Ʈ�� ���� ����
;; -----------------------------------------------------------------------------

(defun pcg-box-center (b)
  (list (/ (+ (nth 0 b) (nth 2 b)) 2.0) (/ (+ (nth 1 b) (nth 3 b)) 2.0))
)

(defun pcg-box-center-in-p (b ref tol / c)
  (setq c (pcg-box-center b))
  (and
    (>= (car c) (- (nth 0 ref) tol))
    (<= (car c) (+ (nth 2 ref) tol))
    (>= (cadr c) (- (nth 1 ref) tol))
    (<= (cadr c) (+ (nth 3 ref) tol))
  )
)

(defun pcg-box-near-p-v10 (a b tol)
  (not
    (or
      (> (nth 0 a) (+ (nth 2 b) tol))
      (> (nth 0 b) (+ (nth 2 a) tol))
      (> (nth 1 a) (+ (nth 3 b) tol))
      (> (nth 1 b) (+ (nth 3 a) tol))
    )
  )
)

(defun pcg-line-box-components (boxes / remaining comps seed comp changed b rest)
  ;; v10: �� ���� �簢���� ���� ������ �־ �ϳ��� ���´�.
  ;; ���� 5mm�� ����� ��/����/ġ���� ���� ������ ���� �������� �и��� �� �־� 35mm�� ��ȭ.
  (setq remaining boxes)
  (setq comps nil)
  (while remaining
    (setq seed (car remaining))
    (setq remaining (cdr remaining))
    (setq comp (list seed))
    (setq changed t)
    (while changed
      (setq changed nil)
      (setq rest nil)
      (foreach b remaining
        (if (vl-some '(lambda (c) (pcg-box-near-p-v10 b c 35.0)) comp)
          (progn
            (setq comp (cons b comp))
            (setq changed t)
          )
          (setq rest (cons b rest))
        )
      )
      (setq remaining rest)
    )
    (setq comps (cons (pcg-merge-box-list comp) comps))
  )
  comps
)

(defun pcg-opening-boxes-in-plan (plan-box op-objs / out line-boxes line-comps o b rel clipped bw bh)
  ;; v10: ������ ���̾� ��ü�� '���� ����'�� �ƴ϶� '�ڽ� ��ħ �Ǵ� �߽��� ����'���� ����.
  ;; ���� ���ܿ� ��ģ ������/�����갡 �����Ǵ� ������ �����Ѵ�.
  (setq out nil)
  (setq line-boxes nil)
  (foreach o op-objs
    (setq b (nth 2 o))
    (if (and b (or (pcg-box-overlap-p b plan-box 120.0) (pcg-box-center-in-p b plan-box 120.0)))
      (progn
        (if (= (car o) "LINE")
          (setq line-boxes (cons b line-boxes))
          (progn
            (setq clipped (pcg-clip-box-to-box b plan-box))
            ;; ��/���� ���� ��¦ �ۿ� �־� clipping �� �ʹ� �۾����� ���� �ڽ��� ��鵵 �������� ��ȯ�Ѵ�.
            (if clipped
              (setq rel (pcg-box-rel-to-plan clipped plan-box))
              (setq rel (pcg-box-rel-to-plan b plan-box))
            )
            (if rel
              (progn
                (setq bw (pcg-box-w rel) bh (pcg-box-h rel))
                (if (and (> bw 3.0) (> bh 3.0)
                         (not (and (> bw (* (pcg-box-w plan-box) 0.70)) (< bh 20.0)))
                         (not (and (> bh (* (pcg-box-h plan-box) 0.70)) (< bw 20.0))))
                  (setq out (cons rel out))
                )
              )
            )
          )
        )
      )
    )
  )
  (if line-boxes
    (progn
      (setq line-comps (pcg-line-box-components line-boxes))
      (foreach b line-comps
        (if (and b (or (pcg-box-overlap-p b plan-box 120.0) (pcg-box-center-in-p b plan-box 120.0)))
          (progn
            (setq clipped (pcg-clip-box-to-box b plan-box))
            (if clipped
              (setq rel (pcg-box-rel-to-plan clipped plan-box))
              (setq rel (pcg-box-rel-to-plan b plan-box))
            )
            (if rel
              (progn
                (setq bw (pcg-box-w rel) bh (pcg-box-h rel))
                (if (and (> bw 5.0) (> bh 5.0)
                         ;; �ʹ� �� ����/���� �������� ����
                         (not (and (> bw (* (pcg-box-w plan-box) 0.65)) (< bh 25.0)))
                         (not (and (> bh (* (pcg-box-h plan-box) 0.65)) (< bw 25.0))))
                  (setq out (cons rel out))
                )
              )
            )
          )
        )
      )
    )
  )
  out
)

(defun pcg-shape-void-candidate-p (b girder-len girder-h / w h touch cx cy sideTol topTol)
  ;; v10: �Ŵ� ���簢������ ���� Ȩ�� �� �а� �����Ѵ�.
  ;; ��, ������ A/B/C/D �ڳ� Ȩ�� �����Ѵ�.
  (setq w (pcg-box-w b)
        h (pcg-box-h b)
        touch (pcg-touch-side-count b girder-len girder-h)
        cx (/ (+ (nth 0 b) (nth 2 b)) 2.0)
        cy (/ (+ (nth 1 b) (nth 3 b)) 2.0)
        sideTol 1.0
        topTol 1.0)
  (and
    (> w 5.0)
    (> h 5.0)
    (>= (nth 0 b) -2.0)
    (>= (nth 1 b) -2.0)
    (<= (nth 2 b) (+ girder-len 2.0))
    (<= (nth 3 b) (+ girder-h 2.0))
    (not (pcg-corner-cut-box-p b girder-len girder-h))
    ;; ��ü �ܺ� ����/�� ��� ����
    (not (and (> w (* girder-len 0.80)) (> h 5.0)))
    (not (and (> h (* girder-h 0.80)) (> w 5.0)))
    ;; ���� ���̵� �Ǵ� �� ��/�� �鿡 ���� Ȩ���� ���. A/B/C/D�� ������ ���ܵ�.
    (<= touch 2)
  )
)

(defun pcg-detect-void1-v9 (shape-boxes opening-boxes girder-len girder-h / candidates b)
  ;; v10: ���� ������ ���̾� ��ü�� �ֿ켱, �� ���� ���� Ȩ.
  (setq candidates nil)
  (foreach b opening-boxes
    (if (pcg-explicit-void-candidate-p b girder-len girder-h)
      (setq candidates (cons b candidates))
    )
  )
  (if candidates
    (pcg-void-box-to-values (car (pcg-sort-void-boxes candidates)) girder-h)
    (progn
      (setq candidates nil)
      (foreach b shape-boxes
        (if (pcg-shape-void-candidate-p b girder-len girder-h)
          (setq candidates (cons b candidates))
        )
      )
      (if candidates
        (pcg-void-box-to-values (car (pcg-sort-void-boxes candidates)) girder-h)
        (list 0 50 50 50 50)
      )
    )
  )
)

(defun pcg-set-ledge-slot-v10 (slot val A B C D / ival)
  (setq ival (fix (+ 0.5 val)))
  (if (< ival 0) (setq ival 0))
  (if (> ival 0)
    (cond
      ((= slot "A") (if (or (= (car A) 0) (> ival (cadr A))) (setq A (list 1 ival))))
      ((= slot "B") (if (or (= (car B) 0) (> ival (cadr B))) (setq B (list 1 ival))))
      ((= slot "C") (if (or (= (car C) 0) (> ival (cadr C))) (setq C (list 1 ival))))
      ((= slot "D") (if (or (= (car D) 0) (> ival (cadr D))) (setq D (list 1 ival))))
    )
  )
  (list A B C D)
)

(defun pcg-detect-ledges (pts girder-len girder-h / A B C D pts2 n i p1 p2 x1 x2 y1 y2 w yv mid sideBand topBand botBand maxLen minLen slot res)
  ;; v10: ����δ� grid cell�� �ƴ϶� �ܰ� ���������� ���� ���׸�Ʈ�� ���� ��´�.
  ;; ������ ���� ǥ��ó�� ��/�� ���� ���/�ϴܿ� �ִ� ª�� ���� ���⼱�� A/B/C/D�� �����Ѵ�.
  (setq A (list 0 50) B (list 0 50) C (list 0 50) D (list 0 50))
  (setq minLen 25.0)
  (setq maxLen (min 2000.0 (* girder-len 0.35)))
  (setq sideBand (min 2200.0 (* girder-len 0.35)))
  (setq topBand (max 180.0 (* girder-h 0.38)))
  (setq botBand topBand)

  (setq pts2 pts)
  (if (and pts2 (not (and (equal (car pts2) (car (last pts2)) 1e-6))))
    (setq pts2 (append pts2 (list (car pts2))))
  )
  (setq n (pcg-list-length pts2))
  (setq i 0)
  (while (< i (1- n))
    (setq p1 (nth i pts2))
    (setq p2 (nth (1+ i) pts2))
    (setq x1 (car p1) y1 (cadr p1) x2 (car p2) y2 (cadr p2))
    (if (and (<= (abs (- y1 y2)) 2.0))
      (progn
        (setq w (abs (- x2 x1)))
        (setq yv (/ (+ y1 y2) 2.0))
        (setq mid (/ (+ x1 x2) 2.0))
        (if (and (>= w minLen) (<= w maxLen))
          (progn
            (setq slot nil)
            (cond
              ;; ���� ��� A
              ((and (<= mid sideBand) (>= yv (- girder-h topBand))) (setq slot "A"))
              ;; ���� ��� B
              ((and (>= mid (- girder-len sideBand)) (>= yv (- girder-h topBand))) (setq slot "B"))
              ;; ���� �ϴ� C
              ((and (<= mid sideBand) (<= yv botBand)) (setq slot "C"))
              ;; ���� �ϴ� D
              ((and (>= mid (- girder-len sideBand)) (<= yv botBand)) (setq slot "D"))
            )
            (if slot
              (progn
                (setq res (pcg-set-ledge-slot-v10 slot w A B C D))
                (setq A (nth 0 res) B (nth 1 res) C (nth 2 res) D (nth 3 res))
              )
            )
          )
        )
      )
    )
    (setq i (1+ i))
  )
  (list A B C D)
)



;; -----------------------------------------------------------------------------
;; v11 override - ���� ��ũ��Ʈ(PCGIRDEREXPORTALL_SHAPE �� ��ȯ ��ũ��Ʈ)�� ���� ������� ����
;; - ����� ledge�� ���� ��ũ��Ʈ�� grid cell + sideStep ��� ���
;; - v10�� �ܰ� ���׸�Ʈ ���� ������ ���� ���鿡�� �� �Ҿ����Ͽ� ��ȿȭ
;; - ���̵�� ����ڰ� ������ ������ ���̾�/���� ��ü�� �켱 ����ϰ�,
;;   �� ���� �Ŵ� ���簢�� ���ؿ��� A/B/C/D�� �ƴ� Ȩ�� ���
;; -----------------------------------------------------------------------------

(defun pcg-box-near-p-v11 (a b tol)
  (not
    (or
      (> (nth 0 a) (+ (nth 2 b) tol))
      (> (nth 0 b) (+ (nth 2 a) tol))
      (> (nth 1 a) (+ (nth 3 b) tol))
      (> (nth 1 b) (+ (nth 3 a) tol))
    )
  )
)

(defun pcg-line-box-components (boxes / remaining comps seed comp changed b rest)
  ;; ������ ���̾� LINE ���տ�. �ʹ� �ָ� ������ ġ����/���������� ������ �ʵ��� ��밪�� ����.
  (setq remaining boxes)
  (setq comps nil)
  (while remaining
    (setq seed (car remaining))
    (setq remaining (cdr remaining))
    (setq comp (list seed))
    (setq changed t)
    (while changed
      (setq changed nil)
      (setq rest nil)
      (foreach b remaining
        (if (vl-some '(lambda (c) (pcg-box-near-p-v11 b c 15.0)) comp)
          (progn
            (setq comp (cons b comp))
            (setq changed t)
          )
          (setq rest (cons b rest))
        )
      )
      (setq remaining rest)
    )
    (setq comps (cons (pcg-merge-box-list comp) comps))
  )
  comps
)

(defun pcg-opening-boxes-in-plan (plan-box op-objs / out line-boxes line-comps o typ b rel clipped bw bh cx cy)
  ;; ���� ������ ���̾� + ���� ��ü�� ���� ���̵�/������ �ĺ��� ���.
  ;; ���� ����ó�� �Ϻΰ� �Ŵ� �ڽ��� ��ģ ��ü�� overlap 30mm���� ����Ѵ�.
  (setq out nil)
  (setq line-boxes nil)
  (foreach o op-objs
    (setq typ (car o))
    (setq b (nth 2 o))
    (if (and b (pcg-box-overlap-p b plan-box 30.0))
      (progn
        (if (= typ "LINE")
          (setq line-boxes (cons b line-boxes))
          (progn
            (setq clipped (pcg-clip-box-to-box b plan-box))
            (if clipped
              (setq rel (pcg-box-rel-to-plan clipped plan-box))
              (setq rel nil)
            )
            (if rel
              (progn
                (setq bw (pcg-box-w rel) bh (pcg-box-h rel))
                ;; ġ����/�� ������ó�� �ش������� ��ų� �� �� ����
                (if (and (> bw 3.0) (> bh 3.0)
                         (not (and (> bw (* (pcg-box-w plan-box) 0.70)) (< bh 20.0)))
                         (not (and (> bh (* (pcg-box-h plan-box) 0.70)) (< bw 20.0))))
                  (setq out (cons rel out))
                )
              )
            )
          )
        )
      )
    )
  )
  (if line-boxes
    (progn
      (setq line-comps (pcg-line-box-components line-boxes))
      (foreach b line-comps
        (setq clipped (pcg-clip-box-to-box b plan-box))
        (if clipped
          (progn
            (setq rel (pcg-box-rel-to-plan clipped plan-box))
            (if rel
              (progn
                (setq bw (pcg-box-w rel) bh (pcg-box-h rel))
                (if (and (> bw 5.0) (> bh 5.0)
                         (not (and (> bw (* (pcg-box-w plan-box) 0.70)) (< bh 20.0)))
                         (not (and (> bh (* (pcg-box-h plan-box) 0.70)) (< bw 20.0))))
                  (setq out (cons rel out))
                )
              )
            )
          )
        )
      )
    )
  )
  out
)

(defun pcg-shape-void-candidate-p (b girder-len girder-h / w h touch)
  ;; �Ŵ��� ���簢������ ���� �� ���� Ȩ.
  ;; A/B/C/D �ڳ� Ȩ�� �����ϰ�, ���� �Ǵ� �� �鿡 ���� Ȩ�� void1�� ����Ѵ�.
  (setq w (pcg-box-w b)
        h (pcg-box-h b)
        touch (pcg-touch-side-count b girder-len girder-h))
  (and
    (> w 5.0)
    (> h 5.0)
    (not (pcg-corner-cut-box-p b girder-len girder-h))
    (>= (nth 0 b) -1.0)
    (>= (nth 1 b) -1.0)
    (<= (nth 2 b) (+ girder-len 1.0))
    (<= (nth 3 b) (+ girder-h 1.0))
    (not (and (> w (* girder-len 0.85)) (> h 5.0)))
    (not (and (> h (* girder-h 0.85)) (> w 5.0)))
    (<= touch 1)
  )
)

(defun pcg-detect-void1-v9 (shape-boxes opening-boxes girder-len girder-h / candidates b)
  ;; 1����: ���� ������ ���̾�+���� ��ü
  ;; 2����: ���簢�� ���ؿ��� A/B/C/D�� �ƴ� Ȩ
  (setq candidates nil)
  (foreach b opening-boxes
    (if (pcg-explicit-void-candidate-p b girder-len girder-h)
      (setq candidates (cons b candidates))
    )
  )
  (if candidates
    (pcg-void-box-to-values (car (pcg-sort-void-boxes candidates)) girder-h)
    (progn
      (setq candidates nil)
      (foreach b shape-boxes
        (if (pcg-shape-void-candidate-p b girder-len girder-h)
          (setq candidates (cons b candidates))
        )
      )
      (if candidates
        (pcg-void-box-to-values (car (pcg-sort-void-boxes candidates)) girder-h)
        (list 0 50 50 50 50)
      )
    )
  )
)

(defun pcg-detect-ledges (pts girder-len girder-h / cells A B C D c x1 x2 y1 y2 w h side vertical slot len sideStepL sideStepR step res maxLen)
  ;; ���� ��ũ��Ʈ�� detectLedges ��Ŀ� ����.
  ;; 1) ���� cell �� ���� 45~85, ���� ���̺��� ũ��, ���̰� ��ü ������ 30% ������ ���� ���� ������ �ĺ��� ��
  ;; 2) ��/�� ���ܿ� ���� �ĺ��� A/B/C/D�� ����
  ;; 3) �¿� ���� ����(sideStep)�� ������ �ĺ� ���̿��� ����, ������ ��ü ���� ���
  (setq A (list 0 50) B (list 0 50) C (list 0 50) D (list 0 50))
  (setq sideStepL 0.0 sideStepR 0.0)
  (setq maxLen (min 1000.0 (* girder-len 0.3)))
  (setq cells (pcg-grid-cells pts girder-len girder-h t))

  ;; sideStep ���: ���ܿ� �ִ� ���� ���� ��
  (foreach c cells
    (setq x1 (nth 2 c) x2 (nth 3 c) y1 (nth 4 c) y2 (nth 5 c))
    (setq w (- x2 x1) h (- y2 y1))
    (if (and (> h 120.0) (<= w 120.0))
      (progn
        (if (<= x1 120.0) (setq sideStepL (max sideStepL w)))
        (if (>= x2 (- girder-len 120.0)) (setq sideStepR (max sideStepR w)))
      )
    )
  )

  ;; ���� ���� �ĺ��� A/B/C/D�� ����
  (foreach c cells
    (setq x1 (nth 2 c) x2 (nth 3 c) y1 (nth 4 c) y2 (nth 5 c))
    (setq w (- x2 x1) h (- y2 y1))
    (if (and (>= h 45.0) (<= h 85.0) (> w h) (<= w maxLen))
      (progn
        (setq side (cond ((<= x1 1.0) "L") ((>= x2 (- girder-len 1.0)) "R") (t nil)))
        (setq vertical (cond ((<= y1 90.0) "B") ((>= y2 (- girder-h 90.0)) "T") (t nil)))
        (if (and side vertical)
          (progn
            (setq slot
              (cond
                ((and (= side "L") (= vertical "T")) "A")
                ((and (= side "R") (= vertical "T")) "B")
                ((and (= side "L") (= vertical "B")) "C")
                (t "D")
              )
            )
            (setq step (if (= side "L") sideStepL sideStepR))
            (setq len (- w step))
            (if (<= len 0.0) (setq len w))
            (setq res (pcg-set-ledge-slot-v10 slot len A B C D))
            (setq A (nth 0 res) B (nth 1 res) C (nth 2 res) D (nth 3 res))
          )
        )
      )
    )
  )
  (list A B C D)
)
