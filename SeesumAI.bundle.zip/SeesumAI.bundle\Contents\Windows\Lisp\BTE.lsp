(defun c:BTE ( / xlApp xlBooks xlBook xlSheet cells save_path ref_pnt p1 p2 ss i ename data pnt name rel_x rel_y ang row sheet_cnt )
  (vl-load-com)

  ;; 1. 저장 경로 선택 (.xlsx)
  (setq save_path (getfiled "엑셀 파일 저장 (.xlsx)" "" "xlsx" 1))
  
  (if (and save_path)
    (progn
      ;; 2. 엑셀 객체 생성 및 초기화
      (setq xlApp (vlax-get-or-create-object "Excel.Application"))
      (setq xlBooks (vlax-get-property xlApp "Workbooks"))
      (setq xlBook (vlax-invoke-method xlBooks "Add"))
      (setq xlSheet (vlax-get-property xlBook "ActiveSheet"))
      
      ;; ★ 시트 이름을 "1"로 변경
      (vlax-put-property xlSheet "Name" "1")
      (setq cells (vlax-get-property xlSheet "Cells"))
      
      ;; 헤더 작성
      (vlax-put-property cells "Item" 1 1 "Block_Name")
      (vlax-put-property cells "Item" 1 2 "Relative_X")
      (vlax-put-property cells "Item" 1 3 "Relative_Y")
      (vlax-put-property cells "Item" 1 4 "Rotation")
      
      (setq row 2)
      (setq sheet_cnt 1)

      ;; 3. 데이터 추출 루프
      (while (setq ref_pnt (getpoint (strcat "\n[" (itoa sheet_cnt) "번 도곽] 기준점 클릭 (종료는 Enter): ")))
        (setq p1 (getpoint "\n범위 첫 번째 점 클릭: "))
        (setq p2 (getcorner p1 "\n범위 반대쪽 점 클릭: "))
        
        (if (and p1 p2)
          (progn
            (setq ss (ssget "W" p1 p2 '((0 . "INSERT"))))
            (if ss
              (progn
                (setq i 0)
                (repeat (sslength ss)
                  (setq ename (ssname ss i))
                  (setq data (entget ename))
                  (setq name (cdr (assoc 2 data)))

                  ;; 08, 10, 11, 12 필터링
                  (if (wcmatch (strcase name) "08-*,10-*,11-*,12-*")
                    (progn
                      (setq pnt (cdr (assoc 10 data)))
                      (setq rel_x (- (car pnt) (car ref_pnt)))
                      (setq rel_y (- (cadr pnt) (cadr ref_pnt)))
                      (setq ang (/ (* (cdr (assoc 50 data)) 180.0) pi))

                      (vlax-put-property cells "Item" row 1 name)
                      (vlax-put-property cells "Item" row 2 rel_x)
                      (vlax-put-property cells "Item" row 3 rel_y)
                      (vlax-put-property cells "Item" row 4 ang)
                      (setq row (1+ row))
                    )
                  )
                  (setq i (1+ i))
                )
                (princ (strcat "\n" (itoa sheet_cnt) "번 도곽 완료."))
                (setq sheet_cnt (1+ sheet_cnt))
              )
              (princ "\n선택 범위에 블록이 없습니다.")
            )
          )
        )
      ) ; while 끝

      ;; 4. 저장 및 종료 (인자 오류 없는 SaveCopyAs 방식)
      (vlax-put-property xlApp "DisplayAlerts" :vlax-false)
      (vlax-invoke-method xlBook "SaveCopyAs" save_path) ; 인자 1개만 사용
      (vlax-invoke-method xlBook "Close" :vlax-false)
      (vlax-invoke-method xlApp "Quit")
      
      (vlax-release-object cells)
      (vlax-release-object xlSheet)
      (vlax-release-object xlBook)
      (vlax-release-object xlBooks)
      (vlax-release-object xlApp)
      
      (princ (strcat "\n성공! '1' 시트명으로 저장 완료: " save_path))
    )
    (princ "\n파일 저장이 취소되었습니다.")
  )
  (princ)
)
