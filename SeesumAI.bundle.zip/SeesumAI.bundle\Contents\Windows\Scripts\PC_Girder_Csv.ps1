param(
  [Parameter(Mandatory=$true)]
  [string]$JsonPath,

  [Parameter(Mandatory=$true)]
  [string]$OutPath
)

$ErrorActionPreference = 'Stop'

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$converter = Join-Path $scriptDir 'pc-girder-json-to-csv.js'
$node = 'C:\Users\Donggeon\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'

if (-not (Test-Path -LiteralPath $node)) {
  $node = 'node'
}

if (-not (Test-Path -LiteralPath $converter)) {
  throw "CSV converter not found: $converter"
}

& $node $converter $JsonPath $OutPath
if ($LASTEXITCODE -ne 0) {
  throw "CSV converter failed with exit code $LASTEXITCODE"
}

Write-Host "PC_Girder.csv created: $OutPath"
